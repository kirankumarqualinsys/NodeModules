module.exports = {
  name: "crm",
  exposes: {
    "./Module": "apps/crm/src/app/app.module.ts",
  },
};
