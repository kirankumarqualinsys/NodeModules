import { Selector } from '@ngxs/store';
import {
  CustomerStateModel,
  CustomerState,
} from './customer.state';

export class CustomersStateSelectors {
  @Selector([CustomerState])
  static customersList(state: CustomerStateModel) {
    return state.customersList;
  }
  @Selector([CustomerState])
  static pageSize(state: CustomerStateModel) {
    return state.paginationCustomers.size;
  }
  @Selector([CustomerState])
  static total(state: CustomerStateModel) {
    return state.total;
  }
  @Selector([CustomerState])
  static pageIndex(state: CustomerStateModel) {
    return state.paginationCustomers.page;
  }
  @Selector([CustomerState])
  static loading(state: CustomerStateModel) {
    return state.loading;
  }
  @Selector([CustomerState])
  static customerDetails(state: CustomerStateModel) {
    return state.customerDetails;
  }
}