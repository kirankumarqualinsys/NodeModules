import { Component, OnInit, TrackByFunction } from '@angular/core';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { Select, Store } from '@ngxs/store';
import {
  AddCustomerGroup,
  ChangeCustomerGroupsPage,
  DeleteCustomerGroup,
  EditCustomerGroup,
  GetCustomerGroupsList,
  UpdateCustomerGroupsStatus,
} from '../../state/customergroups.action';
import { Observable } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'commerceq-admin-ui-customer-groups',
  templateUrl: './customer-groups.component.html',
  styleUrls: ['./customer-groups.component.less'],
})
export class CustomerGroupsComponent implements OnInit {
  constructor(
    private store: Store,
    private readonly fb: FormBuilder,
    private modal: NzModalService
  ) { }
  tabs = ['All', 'Active', 'Disabled'];
  activetabIndex = 0;
  tabStatus: any = 'skip';
  customerGroupsList: any = [];
  public paginationLimit = [10, 20, 50, 100];
  visible = false;
  isEdit = false;
  selectedCustomerGroup: any;
  @Select((state: any) => state.customerGroups.customerGroupsList)
  customerGroupsList$: Observable<any>;
  @Select((state: any) => state.customerGroups.paginationCustomerGroups.size)
  pageSize$: Observable<any>;
  @Select((state: any) => state.customerGroups.total)
  total$: Observable<any>;
  @Select((state: any) => state.customerGroups.paginationCustomerGroups.page)
  pageIndex$: Observable<any>;
  @Select((state: any) => state.customerGroups.loading)
  loading$: Observable<boolean>;
  customerGroupForm: FormGroup = this.fb.group({
    name: [null, [Validators.required]],
    notes: [null, [Validators.required]],
    active: [null, [Validators.required]],
  });
  async ngOnInit() {
    this.store.dispatch(new GetCustomerGroupsList('skip'));
  }
  onSelectTab(event: number) {
    this.activetabIndex = event;

    switch (this.activetabIndex) {
      case 0:
        this.tabStatus = 'skip';
        this.store.dispatch([
          new ChangeCustomerGroupsPage(1),
          new GetCustomerGroupsList('skip'),
        ]);
        break;
      case 1:
        this.tabStatus = true;
        this.store.dispatch([
          new ChangeCustomerGroupsPage(1),
          new GetCustomerGroupsList(true),
        ]);
        break;
      case 2:
        this.tabStatus = false;
        this.store.dispatch([
          new ChangeCustomerGroupsPage(1),
          new GetCustomerGroupsList(false),
        ]);
        break;
    }
  }
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  onChangePage(page: number): void {
    this.store.dispatch([
      new ChangeCustomerGroupsPage(page),
      new GetCustomerGroupsList(this.tabStatus),
    ]);
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateCustomerGroupsStatus(id, event)]);
  }
  deleteGroup(id: number): void {
    const modal: NzModalRef = this.modal.confirm({
      nzTitle: 'Do you Want to delete these group?',
      nzContent: 'When clicked on OK button, this group will be deleted ',
      nzOnOk: () => {
        this.store.dispatch([
          new DeleteCustomerGroup(id),
          new GetCustomerGroupsList(this.tabStatus),
        ]);
      },
      nzOnCancel: () => modal.destroy(),
    });
  }
  addModal(): void {
    this.visible = true;
  }

  handleAdd(): void {
    if (this.customerGroupForm.valid) {
      if (this.isEdit) {
        const payload = {
          ...this.selectedCustomerGroup,
          ...this.customerGroupForm.value,
        };
        this.store.dispatch(new EditCustomerGroup(payload));
      } else {
        this.store.dispatch(new AddCustomerGroup(this.customerGroupForm.value));
      }
      this.store.dispatch([
        new ChangeCustomerGroupsPage(1),
        new GetCustomerGroupsList(this.tabStatus),
      ]);
      console.log(this.customerGroupForm.value);
      this.visible = false;
    } else {
      Object.values(this.customerGroupForm.controls).forEach((control) => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }

  editModal(group: any) {
    this.visible = true;
    this.isEdit = true;
    this.selectedCustomerGroup = group;
    this.customerGroupForm.patchValue(group);
  }
  cancel() {
    this.visible = false;
    this.customerGroupForm.reset();
  }
}
