

export class GetCustomerGroupsList {
    static readonly type = '[CustomerGroups] Get CustomerGroups';
    constructor(public status: any) { }
}

export class ChangeCustomerGroupsPage {
    static readonly type = '[CustomerGroups] Change CustomerGroups Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdateCustomerGroupsStatus {
    static readonly type = '[CustomerGroups] Update CustomerGroups Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeleteCustomerGroup {
    static readonly type = '[CustomerGroups] Delete Customer Group';
    constructor(public readonly id: number) { }
}

export class AddCustomerGroup {
    static readonly type = '[CustomerGroups] Add Customer Group';
    constructor(public readonly payload: any) { }
}
export class EditCustomerGroup {
    static readonly type = '[CustomerGroups] Edit Customer Group';
    constructor(public readonly payload: any) { }
}