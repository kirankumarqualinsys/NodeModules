import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CrmHomeComponent } from './crm-home.component';

import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { RouterModule, Routes } from '@angular/router';



const routes: Routes = [
  {
    path: '',
    component: CrmHomeComponent,
    children: [
      {
        path: '',
        redirectTo: 'customers',
        pathMatch: 'full'
      },
      {
        path: 'customers',
        loadChildren: () =>
          import('../customers/customers.module').then(m => m.CustomersModule)
      },
      {
        path: 'customer-groups',
        loadChildren: () =>
          import('../customer-groups/customer-groups.module').then(m => m.CustomerGroupsModule)
      }
    ]
  }
];
@NgModule({
  declarations: [CrmHomeComponent],
  imports: [CommonModule,
    RouterModule.forChild(routes),

    NzLayoutModule,
    NzSliderModule,
    NzMenuModule,
    NzDividerModule
  ],
  exports: [RouterModule]
})
export class CrmHomeModule { }
