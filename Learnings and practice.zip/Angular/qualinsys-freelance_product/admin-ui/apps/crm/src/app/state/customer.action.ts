

export class GetCustomersList {
  static readonly type = '[Customers] Get Customers';
  constructor(public status: any) { }
}

export class ChangeCustomersPage {
  static readonly type = '[Customers] Change Customer Page';
  constructor(public readonly paylaod: number) { }
}

export class UpdateCustomerStatus {
  static readonly type = '[Customers] Update Customer Status';
  constructor(public readonly id: number, public readonly status: boolean) { }
}

export class GetCustomersWithFilters {
  static readonly type = '[Customers] Get Customers With Filters';
  constructor(public readonly paylaod: any) { }
}
export class GetCustomerDetails {
  static readonly type = '[Customers] Get Customer Details';
  constructor(public readonly id: any) { }
}