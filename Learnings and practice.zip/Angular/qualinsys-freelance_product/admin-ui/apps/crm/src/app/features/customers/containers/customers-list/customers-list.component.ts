import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  TrackByFunction,
} from '@angular/core';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import {
  ChangeCustomersPage,
  GetCustomersList,
  UpdateCustomerStatus,
} from '../../../../state/customer.action';
import { CustomersStateSelectors } from '../../../../state/customer.selectors';
export interface Data {
  id: number;
  fullName: string;
  email: string;
  address: null;
}
@Component({
  selector: 'commerceq-admin-ui-customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CustomersListComponent implements OnInit {
  @Input() tabStatus: any;
  public paginationLimit = [10, 20, 50, 100];
  @Select(CustomersStateSelectors.customersList)
  customerList$: Observable<any> | undefined;
  @Select((state: any) => state.customer.paginationCustomers.size)
  pageSize$: Observable<any>;
  @Select((state: any) => state.customer.total)
  total$: Observable<any>;
  @Select((state: any) => state.customer.paginationCustomers.page)
  pageIndex$: Observable<any>;
  @Select((state: any) => state.customer.loading)
  loading$: Observable<boolean>;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  constructor(private store: Store) { }
  async ngOnInit() {
    console.log(123);
  }
  onChangePage(page: number): void {
    this.store.dispatch([
      new ChangeCustomersPage(page),
      new GetCustomersList(this.tabStatus),
    ]);
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateCustomerStatus(id, event)]);
  }
}
