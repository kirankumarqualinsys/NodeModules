import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../state/customer.state';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

  getCustomers(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customers`;
    let params = new HttpParams();
    if (pagination) {
      params = params.append('page', pagination.page - 1);
    }
    if (pagination?.size) {
      params = params.append('size', pagination.size.toString());
    }
    if (status !== "skip") {
      params = params.append('active', status);
    }
    return this.http.get(url, { params })
  }
  updateCustomerStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/user/api/customers/${id}/${status}`;
    return this.http.patch(url, {})
  }



  getCustomerGroups(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customer/groups`;
    let params = new HttpParams();
    if (pagination) {
      params = params.append('page', pagination.page - 1);
    }
    if (pagination?.size) {
      params = params.append('size', pagination.size.toString());
    }
    if (status !== "skip") {
      params = params.append('active', status);
    }
    return this.http.get(url, { params })
  }
  updateCustomerGroupsStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/user/api/customer/groups/${id}/${status}`;
    return this.http.put(url, {})
  }

  getCustomersWithFilters(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customers/97932177/search`;
    const data: any = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }

    return this.http.post(url, data)
  }
  getCustomerDetails(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customers/${id}`;
    return this.http.get(url)
  }
  deleteCustomerGroup(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customer/groups/${id}`;
    return this.http.delete(url)
  }
  addCustomerGroup(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customer/groups`;
    return this.http.post(url, payload)
  }
  editCustomerGroup(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/user/api/customer/groups/${payload.id}`;
    return this.http.put(url, payload)
  }
}
