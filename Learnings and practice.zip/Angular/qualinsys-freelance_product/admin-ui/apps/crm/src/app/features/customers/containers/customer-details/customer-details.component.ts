import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { GetCustomerDetails } from 'apps/crm/src/app/state/customer.action';
import { CustomersStateSelectors } from 'apps/crm/src/app/state/customer.selectors';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.less'],
})
export class CustomerDetailsComponent implements OnInit {
  tabs = ['Customer Details'];
  activetabIndex = 0;
  @Select(CustomersStateSelectors.customerDetails)
  customerDetails$: Observable<any> | undefined;
  showModal = false;
  constructor(private readonly route: ActivatedRoute, private store: Store) { }
  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.store.dispatch(new GetCustomerDetails(id));
    }
  }
  formSubmit($event: any) {
    console.log($event);
  }
}
