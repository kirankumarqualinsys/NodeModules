import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';

@Component({
  selector: 'commerceq-admin-ui-crm-home',
  templateUrl: './crm-home.component.html',
  styleUrls: ['./crm-home.component.less'],
})
export class CrmHomeComponent implements OnInit {
  menuConfig: any;
  constructor() { }
  async ngOnInit() {
    this.setMenuItems();
  }
  async setMenuItems() {
    this.menuConfig = {
      items: [
        {
          key: 'customers',
          value: 'Customers'
        },
        {
          key: 'customer-groups',
          value: 'Customer Groups'
        }
      ]
    }
  }
}
