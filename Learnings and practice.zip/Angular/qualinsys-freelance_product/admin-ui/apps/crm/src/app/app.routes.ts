import { Route } from "@angular/router";

export const appRoutes: Route[] = [
  {
    path: '',
    loadChildren: () =>
      import('./features/crm-home/crm-home.module').then(m => m.CrmHomeModule)
  }
];
