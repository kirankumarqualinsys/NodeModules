import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import {
  ChangeCustomersPage,
  GetCustomersList,
  GetCustomersWithFilters,
} from '../../state/customer.action';

@Component({
  selector: 'commerceq-admin-ui-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.less'],
})
export class CustomersComponent implements OnInit {
  tabs = ['All', 'Active', 'Disabled'];
  activetabIndex = 0;
  tabStatus: any = 'skip';
  customersFilterFields = {
    customerName: {
      type: 'text',
      value: '',
      label: 'Customer Name',
      span: '6',
    },
    email: {
      type: 'text',
      value: '',
      label: 'Email',
      span: '6',
    },
    mobile: {
      type: 'text',
      value: '',
      label: 'Mobile',
      span: '4',
    },
    group: {
      type: 'text',
      value: '',
      label: 'Group',
      span: '4',
    },
    createdDate: {
      type: 'date',
      value: '',
      label: 'Created Date',
      span: '4',
    },
  };
  constructor(private store: Store) { }
  async ngOnInit() {
    this.store.dispatch(new GetCustomersList('skip'));
  }
  onSelectTab(event: number) {
    this.activetabIndex = event;
    switch (this.activetabIndex) {
      case 0:
        this.tabStatus = 'skip';
        this.store.dispatch([
          new ChangeCustomersPage(1),
          new GetCustomersList('skip'),
        ]);
        break;
      case 1:
        this.tabStatus = true;
        this.store.dispatch([
          new ChangeCustomersPage(1),
          new GetCustomersList(true),
        ]);
        break;
      case 2:
        this.tabStatus = false;
        this.store.dispatch([
          new ChangeCustomersPage(1),
          new GetCustomersList(false),
        ]);
        break;
    }
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }
  filtersFormSubmit($event: any) {
    console.log($event, 'event');
    this.store.dispatch(new GetCustomersWithFilters($event));
  }
}
