import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomersComponent } from './customers.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';

import { CustomersListComponent } from './containers/customers-list/customers-list.component';
import { CustomerService } from '../../services/customer.service';
import { FiltersDynamicFormModule } from '../../../../../../libs/shared/src/lib/components/common/filters-dynamic-form/filters-dynamic-form.module';
import { CustomerDetailsComponent } from './containers/customer-details/customer-details.component';

import { AddAddressModalModule } from '../../../../../../libs/shared/src/lib/modals/add-address-modal/add-address-modal.module';
@NgModule({
  declarations: [
    CustomersComponent,
    CustomersListComponent,
    CustomerDetailsComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      { path: '', component: CustomersComponent },
      { path: 'details/:id', component: CustomerDetailsComponent }
    ]),

    NzDividerModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzDatePickerModule,
    NzButtonModule,
    NzInputModule,
    NzDropDownModule,
    NzModalModule,
    FiltersDynamicFormModule,
    AddAddressModalModule
  ],
  exports: [CustomersListComponent, RouterModule],
  providers: [CustomerService],
})
export class CustomersModule { }
