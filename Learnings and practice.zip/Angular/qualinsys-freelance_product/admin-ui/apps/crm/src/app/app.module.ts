import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { appRoutes } from './app.routes';

import { CustomerGroupsState } from "./state/customergroups.state"
import { NgxsModule } from '@ngxs/store';



@NgModule({
  declarations: [AppComponent],
  imports: [RouterModule.forChild(appRoutes),
  NgxsModule.forFeature(
    [
      CustomerGroupsState
    ],
  ),
  ],
  providers: [],
  bootstrap: [AppComponent]

})
export class AppModule { }
