import { Selector } from '@ngxs/store';
import {
    CustomerGroupsStateModel,
    CustomerGroupsState,
} from './customergroups.state';


export class CustomerGroupsStateSelectors {
    @Selector([CustomerGroupsState])
    static customerGroupsList(state: CustomerGroupsStateModel) {
        return state['customerGroupsList'];
    }
    static pageSize(state: CustomerGroupsStateModel) {
        return state.paginationCustomerGroups.size;
    }
    static total(state: CustomerGroupsStateModel) {
        return state.total;
    }
    static pageIndex(state: CustomerGroupsStateModel) {
        return state.paginationCustomerGroups.page;
    }
    static loading(state: CustomerGroupsStateModel) {
        return state.loading;
    }
}