import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { ChangeCustomersPage, GetCustomerDetails, GetCustomersList, GetCustomersWithFilters, UpdateCustomerStatus } from './customer.action';
import { CustomerService } from '../services/customer.service';

export interface IPage {
  size: number;
  page: number;
  filter?: string;
  filterParams?: { value: string[], key: string }[];
  sort?: { key: string, value: string }
}
export interface CustomerStateModel {
  customersList: [];
  paginationCustomers: IPage;
  total: number;
  loading: boolean;
  customerDetails: any
}
@State<CustomerStateModel>({
  name: 'customer',
  defaults: {
    customersList: [],
    paginationCustomers: { page: 1, size: 5 },
    total: 0,
    loading: false,
    customerDetails: undefined,
  }
})
@Injectable()
export class CustomerState implements NgxsOnInit {


  constructor(private customerService: CustomerService, private readonly store: Store) { }
  async ngxsOnInit() {
  }
  @Action(GetCustomersList)
  getCustomersList({ getState, patchState }: StateContext<CustomerStateModel>, action: GetCustomersList) {
    const { paginationCustomers } = getState();
    patchState({ loading: true })
    return this.customerService.getCustomers(action.status, paginationCustomers).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const customersList = result.content;
          const total = result.totalElements;
          patchState({
            customersList,
            total,
            loading: false
          });
        }
      })
    );
  }
  @Action(ChangeCustomersPage)
  changeCustomersPage({ patchState, getState }: StateContext<CustomerStateModel>, action: ChangeCustomersPage) {
    patchState({ paginationCustomers: { ...getState().paginationCustomers, page: action.paylaod } })
  }
  @Action(UpdateCustomerStatus)
  updateCustomerStatus({ patchState }: StateContext<CustomerStateModel>, action: UpdateCustomerStatus) {
    patchState({ loading: true })
    return this.customerService.updateCustomerStatus(action.id, action.status).pipe(
      take(1),
      tap((result: any) => {
        patchState({
          loading: false
        });
      })
    );
  }
  @Action(GetCustomersWithFilters)
  getCustomersWithFilters({ getState, patchState }: StateContext<CustomerStateModel>, action: GetCustomersWithFilters) {
    const { paginationCustomers } = getState();
    patchState({ loading: true })
    return this.customerService.getCustomersWithFilters(action.paylaod, paginationCustomers).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const customersList = result.content;
          const total = result.totalElements;
          patchState({
            customersList,
            total,
            loading: false
          });
        }
      })
    );
  }
  @Action(GetCustomerDetails)
  getCustomerDetails({ patchState }: StateContext<CustomerStateModel>, action: GetCustomerDetails) {
    patchState({ loading: true })
    return this.customerService.getCustomerDetails(action.id).pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          const customerDetails = result;
          patchState({
            customerDetails,
            loading: false
          });
        }
      })
    );
  }
}