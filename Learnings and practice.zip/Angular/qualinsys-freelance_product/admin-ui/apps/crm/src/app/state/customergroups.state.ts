import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddCustomerGroup, ChangeCustomerGroupsPage, DeleteCustomerGroup, EditCustomerGroup, GetCustomerGroupsList, UpdateCustomerGroupsStatus } from './customergroups.action';
import { CustomerService } from '../services/customer.service';

export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface CustomerGroupsStateModel {
    [x: string]: any;
    customerGroupsList: [];
    paginationCustomerGroups: IPage;
    total: number;
    loading: boolean;
}
@State<CustomerGroupsStateModel>({
    name: 'customerGroups',
    defaults: {
        customerGroupsList: [],
        paginationCustomerGroups: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class CustomerGroupsState implements NgxsOnInit {


    constructor(private customerService: CustomerService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetCustomerGroupsList)
    getCustomerGroupsList({ getState, patchState }: StateContext<CustomerGroupsStateModel>, action: GetCustomerGroupsList) {
        const { paginationCustomerGroups } = getState();
        patchState({ loading: true })
        return this.customerService.getCustomerGroups(action.status, paginationCustomerGroups).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    const customerGroupsList = result;
                    const total = result.length;
                    patchState({
                        customerGroupsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeCustomerGroupsPage)
    changeCustomerGroupsPage({ patchState, getState }: StateContext<CustomerGroupsStateModel>, action: ChangeCustomerGroupsPage) {
        patchState({ paginationCustomerGroups: { ...getState().paginationCustomerGroups, page: action.paylaod } })
    }
    @Action(UpdateCustomerGroupsStatus)
    updateCustomerStatus({ patchState }: StateContext<CustomerGroupsStateModel>, action: UpdateCustomerGroupsStatus) {
        patchState({ loading: true })
        return this.customerService.updateCustomerGroupsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(DeleteCustomerGroup)
    deleteCustomerGroup({ patchState }: StateContext<CustomerGroupsStateModel>, action: DeleteCustomerGroup) {
        patchState({ loading: true })
        return this.customerService.deleteCustomerGroup(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddCustomerGroup)
    addCustomerGroup({ patchState }: StateContext<CustomerGroupsStateModel>, action: AddCustomerGroup) {
        patchState({ loading: true })
        return this.customerService.addCustomerGroup(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(EditCustomerGroup)
    editCustomerGroup({ patchState }: StateContext<CustomerGroupsStateModel>, action: EditCustomerGroup) {
        patchState({ loading: true })
        return this.customerService.editCustomerGroup(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
}