import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddShippingMethods, ChangeShippingMethodsPage, DeleteShippingMethods, EditShippingMethods, GetShippingMethodsList, UpdateShippingMethodsStatus } from './shipping-methods.action';
import { ShippingMethodsService } from '../service/shipping-methods.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface ShippingMethodsStateModel {
    [x: string]: any;
    ShippingMethodsList: [];
    paginationShippingMethods: IPage;
    total: number;
    loading: boolean;
}
@State<ShippingMethodsStateModel>({
    name: 'ShippingMethods',
    defaults: {
        ShippingMethodsList: [],
        paginationShippingMethods: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class ShippingMethodsState implements NgxsOnInit {
    constructor(private ShippingMethodsService: ShippingMethodsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetShippingMethodsList)
    getShippingMethodsList({ getState, patchState }: StateContext<ShippingMethodsStateModel>, action: GetShippingMethodsList) {
        const { paginationShippingMethods } = getState();
        patchState({ loading: true })
        return this.ShippingMethodsService.getShippingMethods(action.status, paginationShippingMethods).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const ShippingMethodsList = result;
                    const total = result.length;
                    patchState({
                        ShippingMethodsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeShippingMethodsPage)
    changeShippingMethodsPage({ patchState, getState }: StateContext<ShippingMethodsStateModel>, action: ChangeShippingMethodsPage) {
        patchState({ paginationShippingMethods: { ...getState().paginationShippingMethods, page: action.paylaod } })
    }
    @Action(UpdateShippingMethodsStatus)
    updateShippingMethodsStatus({ patchState }: StateContext<ShippingMethodsStateModel>, action: UpdateShippingMethodsStatus) {
        patchState({ loading: true })
        return this.ShippingMethodsService.updateShippingMethodsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeleteShippingMethods)
    deleteShippingMethods({ patchState }: StateContext<ShippingMethodsStateModel>, action: DeleteShippingMethods) {
        patchState({ loading: true })
        return this.ShippingMethodsService.deleteShippingMethods(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddShippingMethods)
    addShippingMethods({ patchState }: StateContext<ShippingMethodsStateModel>, action: AddShippingMethods) {
        patchState({ loading: true })
        return this.ShippingMethodsService.addShippingMethods(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
   
}