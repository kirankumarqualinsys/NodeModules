import { TestBed } from '@angular/core/testing';

import { PickupLocationService } from './pickup-location.service';

describe('PickupLocationService', () => {
  let service: PickupLocationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PickupLocationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
