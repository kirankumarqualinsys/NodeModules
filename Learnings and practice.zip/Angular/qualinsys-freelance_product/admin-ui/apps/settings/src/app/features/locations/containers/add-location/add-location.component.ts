import { Location } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Store } from '@ngxs/store';
import { LocationsService } from 'apps/settings/src/app/service/locations.service';
import { AddLocation, EditLocation } from 'apps/settings/src/app/state/locations.action';

@Component({
  selector: 'commerceq-admin-ui-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.less'],
})
export class AddLocationComponent implements OnInit {
  size: any = 'large';
  locationForm!: any;
  locationFormGroup!: any;
  selectedTabIndex = 0;
  tabLabel = 'Add Location';
  

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private store:Store,
    private loacationService:LocationsService,
    private location:Location
  ) {
    console.log(route.snapshot.params,'edit');
    
    if (route.snapshot.params['location_id']) this.tabLabel = 'Edit Location';

  
    this.locationForm = this.fb.group({
      locationName: [null, [Validators.required]],
      enableFulfilment:[],
      enablePickup:[],
      enableOutlet:[],
      address: [null, [Validators.required]],
      landmark: [null],
      locality: [null, [Validators.required]],
      country: [null, [Validators.required]],
      state: [null, [Validators.required]],
      city: [null, [Validators.required]],
      postalCode: [null, [Validators.required]],
      contactMobile: [null, [Validators.required]],
    });

    if(this.loacationService.locationData  != null) {
      this.tabLabel = 'Edit Location';
      console.log(this.loacationService.locationData);
      this.locationForm.controls['locationName'].setValue(this.loacationService.locationData.locationName); 
      this.locationForm.controls['enableFulfilment'].setValue(this.loacationService.locationData.enableFulfilment); 
      this.locationForm.controls['enablePickup'].setValue(this.loacationService.locationData.enablePickup); 
      this.locationForm.controls['enableOutlet'].setValue(this.loacationService.locationData.enableOutlet); 
      this.locationForm.controls['address'].setValue(this.loacationService.locationData.address); 
      this.locationForm.controls['landmark'].setValue(this.loacationService.locationData.landmark); 
      this.locationForm.controls['locality'].setValue(this.loacationService.locationData.locality); 
      this.locationForm.controls['country'].setValue(this.loacationService.locationData.country); 
      this.locationForm.controls['city'].setValue(this.loacationService.locationData.city); 
      this.locationForm.controls['state'].setValue(this.loacationService.locationData.state); 
      this.locationForm.controls['postalCode'].setValue(this.loacationService.locationData.postalCode); 
      this.locationForm.controls['contactMobile'].setValue(this.loacationService.locationData.contactMobile); 
    };
  }

  ngOnInit(): void {
    console.log();
  }
  submitForm() {
    console.log(this.locationForm.value)
    let productObj={

      "locationName":this.locationForm.value.locationName,
      "enableFulfilment":this.locationForm.value.enableFulfilment,
      "enablePickup":this.locationForm.value.enablePickup,
      "enableOutlet":this.locationForm.value.enableOutlet,
      "address":this.locationForm.value.address,
      "landmark":this.locationForm.value.landmark,
      "locality":this.locationForm.value.locality,
      "country":this.locationForm.value.country,
      "state":this.locationForm.value.state,
      "city":this.locationForm.value.city,
      "postalCode":this.locationForm.value.postalCode,
      "contactMobile":this.locationForm.value.contactMobile

 }

 console.log(productObj);
 if (this.locationForm.valid) {
   console.log('valid');
   if(this.tabLabel = 'Edit Location'){
    let finalObj:any = productObj;
    finalObj.id = this.loacationService.locationData.id;
    this.store.dispatch([new EditLocation(finalObj)]);
    setTimeout(() => {
      this.location.back();
    }, 500);
    
   }else{
    this.store.dispatch([new AddLocation(productObj)]);
    setTimeout(() => {
      this.location.back();
    }, 500);
   }
   
  
 } 
 else {
   Object.values(this.locationForm.controls).forEach((control:any) => {
     if (control.invalid) {
       control.markAsDirty();
       control.updateValueAndValidity({ onlySelf: true });
     }
   });
 }
 this.loacationService.locationData = null;
 }
}
