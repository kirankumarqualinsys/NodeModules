import { Component } from '@angular/core';
import { ActivatedRoute, Event, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-store',
  templateUrl: './store.component.html',
  styleUrls: ['./store.component.less'],
})
export class StoreComponent {
  tabsConfig = {
    items: [
      {
        key: 'view',
        value: 'Store',
        index: 0,
      },
      {
        key: 'domain',
        value: 'Domain Settings',
        index: 1,
      },
      {
        key: 'messages',
        value: 'Store Messages',
        index: 2,
      },
    ],
  };
  activetabIndex = 0;
  size: any = 'large';

  constructor(private router: Router, private route: ActivatedRoute) {
    const item: any = this.tabsConfig.items.find((i) =>
      router.url.endsWith(i.key)
    );
    this.activetabIndex = item?.index || 0;

    router.events
      .pipe(
        filter(
          (e: Event | NavigationEnd): e is NavigationEnd =>
            e instanceof NavigationEnd
        )
      )
      .subscribe((e: NavigationEnd) => {
        //Do something with the NavigationEnd event object.
        const item: any = this.tabsConfig.items.find((i) =>
          e.url.endsWith(i.key)
        );
        this.activetabIndex = item?.index || 0;
      });
  }

  onSelectTab(event: any) {
    this.activetabIndex = event;
  }

  onClickTab(key: any) {
    this.router.navigate([key], { relativeTo: this.route });
  }
}
