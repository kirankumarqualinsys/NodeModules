import { Component } from '@angular/core';
import { ActivatedRoute, Event, NavigationEnd, Router } from '@angular/router';
import { filter } from 'rxjs';
import { NzModalService } from 'ng-zorro-antd/modal';
import { PickupLocationService } from '../../service/pickup-location.service';
import { ShippingMethodsService } from '../../service/shipping-methods.service';

@Component({
  selector: 'commerceq-admin-ui-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.less'],
})
export class ShippingComponent {
  tabsConfig = {
    items: [
      {
        key: 'view',
        value: 'Shipping Settings',
        index: 0
      },
      {
        key: 'da',
        value: 'Delivery Pincodes',
        index: 1
      },
      {
        key: 'pl',
        value: 'Pickup Locations',
        index: 2
      },
      {
        key: 'sm',
        value: 'Shipping Methods',
        index: 3
      }
    ],
  };
  activetabIndex = 0;
  size: any = 'large';

  constructor(private router: Router, private route: ActivatedRoute,
    private modal: NzModalService, private pickupLocationService: PickupLocationService,
    private smService:ShippingMethodsService) {
    const item: any = this.tabsConfig.items.find((i) =>
      router.url.endsWith(i.key)
    );
    this.activetabIndex = item?.index || 0;

    router.events
      .pipe(
        filter(
          (e: Event | NavigationEnd): e is NavigationEnd =>
            e instanceof NavigationEnd
        )
      )
      .subscribe((e: NavigationEnd) => {
        //Do something with the NavigationEnd event object.
        const item: any = this.tabsConfig.items.find((i) =>
          e.url.endsWith(i.key)
        );
        this.activetabIndex = item?.index || 0;
      });
    this.showButton = this.activetabIndex == 2 ? 'pl' : this.activetabIndex == 3 ? 'sm' : ''
  }


  onSelectTab(event: any) {
    this.activetabIndex = event;
  }

  showButton: string = '';
  onClickTab(key: any) {
    this.router.navigate([key], { relativeTo: this.route });
    this.showButton = key;
  }
  openLocationModal(): void {
    this.pickupLocationService.openLocationModal('add');
  }
  openShippingModal(): void {
    this.smService.opensmModal('add');
  }

}
