import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'commerceq-admin-ui-domain-settings',
  templateUrl: './domain-settings.component.html',
  styleUrls: ['./domain-settings.component.less'],
})
export class DomainSettingsComponent implements OnInit {
  domainForm!: any;
  constructor(private fb: FormBuilder) {
    this.domainForm = this.fb.group({
      newDomainName: ['store-dev-micro.commerceq.com '],
    });
  }
  ngOnInit(): void {
    console.log();
  }
  openStore() {}
  updateStore() {}
  cancelStore() {}
}
