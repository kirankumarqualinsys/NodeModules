import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LocationsComponent } from './locations.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { AddLocationComponent } from './containers/add-location/add-location.component';
@NgModule({
  declarations: [LocationsComponent, AddLocationComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        
        component: LocationsComponent,
      },
      {
        path: 'list',
        loadChildren: () =>
          import('../locations/locations.module').then(m => m.LocationsModule)
      },
      { path: 'add', component: AddLocationComponent },
      { path: ':location_id/edit', component: AddLocationComponent },
      
    ]),
    NzDividerModule,
    NzTabsModule,
    NzButtonModule,
    NzTableModule,
    NzSwitchModule,
    NzDropDownModule,
    NzFormModule,
    NzInputModule,
    NzModalModule,
    NzCheckboxModule,
    NzIconModule,
    NzAlertModule,
    NzSelectModule,
    NzRadioModule,
    NzPaginationModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class LocationsModule {}
