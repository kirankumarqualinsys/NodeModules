import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { StoreService } from '../../../service/store.service';


@Component({
  selector: 'commerceq-admin-ui-store-details',
  templateUrl: './store-details.component.html',
  styleUrls: ['./store-details.component.less'],
})
export class StoreDetailsComponent implements OnInit {
  storeForm!: any;
  // value?: string;
  radioValue = 'Yes';



  constructor(
    private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    public storeService: StoreService
  ) {
    this.storeForm = this.fb.group({
      storeName: ['', [Validators.required]],
      shortDescription: ['', [Validators.required]],
      contactEmail: ['', [Validators.required]],
      displayName: ['', [Validators.required]],
      templateName: [''],
      currency: [''],
      weightUnit: [''],
      dimensionUnit: [''],
      timeZone: [''],
      enableTrackingInventory: ['', [Validators.required]],
    });
  }

  enabledValues = [
    { key: true, name: 'Yes' },
    { key: false, name: 'No' }
  ]
  updateDomain() {
    this.router.navigate(['/settings/store/domain']);
  }

  ngOnInit(): void {
    this.getDimensionUnits();
    this.getWeightUnits();
    this.getCurrencies();
    this.getTimeZones();
    this.getCategories();
    this.getMasterTemplates();
    this.getMasterTemplateTheme();
    this.getStoreList();

  }
  masterTemplateThemeList:any=[];
  getMasterTemplateTheme() {
   this.storeService.getMasterTemplateTheme().subscribe((res:any)=>{
    this.masterTemplateThemeList=[];
    this.masterTemplateThemeList=res;
   })
  }

  masterTemplateList: any = [];
  getMasterTemplates() {
    this.storeService.getMasterTemplates().subscribe((res: any) => {
      this.masterTemplateList = [];
      this.masterTemplateList = res;
    })
  }

  categoryList: any = [];
  getCategories() {
    this.storeService.getCategories().subscribe((res: any) => {
      this.categoryList = [];
      this.categoryList = res;
    })
  }


  timeZoneList: any = [];
  getTimeZones() {
    this.storeService.getTimeZones().subscribe((res: any) => {
      this.timeZoneList = [];
      this.timeZoneList = res;
    })
  }


  currencyList: any = [];
  getCurrencies() {
    this.storeService.getCurrencies().subscribe((res: any) => {
      this.currencyList = [];
      this.currencyList = res;
    })
  }


  weightUnitList: any = [];
  getWeightUnits() {
    this.storeService.getWeightUnits().subscribe((res: any) => {
      this.weightUnitList = [];
      this.weightUnitList = res;
    })
  }

  dimensionUnitList: any = [];
  getDimensionUnits() {
    this.storeService.getDimensionUnits().subscribe((res: any) => {
      this.dimensionUnitList = [];
      this.dimensionUnitList = res;
    })
  }



  storeDetailsList: any = [];
  getStoreList(): void {
    this.storeService.getStoreDetailsList().subscribe((res: any) => {
      this.storeDetailsList = [];
      this.storeDetailsList = res;
      this.storeForm.controls['storeName'].setValue(this.storeDetailsList?.storeName);
      this.storeForm.controls['shortDescription'].setValue(this.storeDetailsList?.shortDescription);
      this.storeForm.controls['contactEmail'].setValue(this.storeDetailsList?.contactEmail);
      this.storeForm.controls['displayName'].setValue(this.storeDetailsList?.displayName);
      this.storeForm.controls['templateName'].setValue(this.storeDetailsList?.templateName);
      this.storeForm.controls['currency'].setValue(this.storeDetailsList?.currency);
      this.storeForm.controls['weightUnit'].setValue(this.storeDetailsList?.weightUnit);
      this.storeForm.controls['dimensionUnit'].setValue(this.storeDetailsList?.dimensionUnit);
      this.storeForm.controls['timeZone'].setValue(this.storeDetailsList?.timeZone);
      this.storeForm.controls['enableTrackingInventory'].setValue(this.storeDetailsList?.enableTrackingInventory);
      console.log('store',this.storeDetailsList);  
    })

  }

  updateStoreDetailsList():void{
    let storeDetailsListObj = { ...this.storeDetailsList }; 
    storeDetailsListObj.storeName.name=this.storeForm.value.storeName;
    storeDetailsListObj.shortDescription.name=this.storeForm.value.shortDescription;
    storeDetailsListObj.contactEmail=this.storeForm.value.contactEmail;
    storeDetailsListObj.displayName.name=this.storeForm.value.displayName;
    storeDetailsListObj.templateName.name=this.storeForm.value.templateName;
    storeDetailsListObj.currency=this.storeForm.value.currency;
    storeDetailsListObj.weightUnit=this.storeForm.value.weightUnit;
    storeDetailsListObj.dimensionUnit=this.storeForm.value.dimensionUnit;
    storeDetailsListObj.timeZone=this.storeForm.value.timeZone;
    storeDetailsListObj.enableTrackingInventory=this.storeForm.value.enableTrackingInventory;
    this.storeService.updateStoreDetailsList(storeDetailsListObj).subscribe((res:any)=>{
      console.log('service success',res);
      
    })
  }







}
function updateStoreDetailsList() {
  throw new Error('Function not implemented.');
}

