import { Injectable } from '@angular/core';

import { HttpClient, HttpParams } from '@angular/common/http';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
// import { IPage } from '../features/state/collections.state';


@Injectable({
  providedIn: 'root'
})
export class BusinessService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

  getBusinessDetailsList() {
    console.log('hiojjoijijio');
    const url = `${this.environment.apiUrl}/user/api/businesses/current`;
    return this.http.get(url)
  }

  getBusinessTypeDetailsList(){
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/business-types`;
    return this.http.get(url)
  }

  getCompanyList(){
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/company-id-types`;
    return this.http.get(url)
  }

  getTaxList(){
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/tax-id-types`;
    return this.http.get(url)
  }

  getCountrysList(){
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/countries/1`;
    return this.http.get(url)
  }

  getStatesList(){
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/states/2`;
    return this.http.get(url)
  }

  updateBusinessDetailsList(businessDetailsListObj:any) {
    const url = `${this.environment.apiUrl}/user/api/businesses`;
    return this.http.put(url, businessDetailsListObj)
  }

  updateLocationDetailsList(locaionListObj:any) {
    const url = `${this.environment.apiUrl}/user/api/businesses/3/location/10`;
    return this.http.put(url, locaionListObj)
  }

  // http://216.250.122.50:8765/user/api/businesses/3/location/10  

  // {"id":10,"countryId":1,"stateId":2,"city":"BHL","locality":"manikonda village1","postalCode":"500088","address":"business address line 21","landmark":"near Manikonda1"}



}
