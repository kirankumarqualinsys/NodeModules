import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoreComponent } from './store.component';
import { RouterModule } from '@angular/router';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { StoreMessagesComponent } from './store-messages/store-messages.component';
import { DomainSettingsComponent } from './domain-settings/domain-settings.component';
import { StoreDetailsComponent } from './store-details/store-details.component';
import { NzFormModule } from 'ng-zorro-antd/form';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzModalModule } from 'ng-zorro-antd/modal';


@NgModule({
  declarations: [
    StoreComponent,
    StoreDetailsComponent,
    DomainSettingsComponent,
    StoreMessagesComponent,
    
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '',
        component: StoreComponent,
        children: [
          {
            path: '',
            component: StoreDetailsComponent,
          },
          {
            path: 'view',
            component: StoreDetailsComponent,
          },
          {
            path: 'domain',
            component: DomainSettingsComponent,
          },
          {
            path: 'messages',
            component: StoreMessagesComponent,
          },
        ],
      },
    ]),
    NzTabsModule,
    NzButtonModule,
    NzFormModule,
    FormsModule,
    ReactiveFormsModule,
    NzDividerModule,
    NzSelectModule,
    NzRadioModule,
    NzInputModule,
    NzModalModule,
    
  ],
})
export class StoreModule {}
