import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SettingsHomeComponent } from './settings-home.component';

import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        component: SettingsHomeComponent,
        children: [
            {
                path: '',
                redirectTo: 'business',
                pathMatch: 'full'
            },
            {
                path: 'business',
                loadChildren: () =>
                    import('../business/business.module').then(m => m.BusinessModule)
            },

            {
                path: 'locations',
                loadChildren: () =>
                  import('../locations/locations.module').then(m => m.LocationsModule)
              },
            {
                path: 'sales-channels',
                loadChildren: () =>
                    import('../sales-channels/sales-channels.module').then(m => m.SalesChannelsModule)
            },
            {
                path: 'payment',
                loadChildren: () =>
                    import('../payment/payment.module').then(m => m.PaymentModule)
            },

            {
                path: 'store',
                loadChildren: () =>
                  import('../store/store.module').then((m) => m.StoreModule),
              },
              {
                path: 'shipping',
                loadChildren: () =>
                  import('../shipping/shipping.module').then((m) => m.ShippingModule),
              },
            

        ]
    }
];
@NgModule({
    declarations: [SettingsHomeComponent],
    imports: [CommonModule,
        RouterModule.forChild(routes),

        NzLayoutModule,
        NzSliderModule,
        NzMenuModule,
        NzDividerModule
    ],
    exports: [RouterModule]
})
export class SettingsHomeModule { }
