import { Selector } from '@ngxs/store';
import {
    ShippingMethodsStateModel,
    ShippingMethodsState,
} from './shipping-methods.state';


export class ShippingMethodsStateSelectors {
    @Selector([ShippingMethodsState])
    static ShippingMethodsList(state: ShippingMethodsStateModel) {
        return state['ShippingMethodsList'];
    }
    static pageSize(state: ShippingMethodsStateModel) {
        return state.paginationShippingMethods.size;
    }
    static total(state: ShippingMethodsStateModel) {
        return state.total;
    }
    static pageIndex(state: ShippingMethodsStateModel) {
        return state.paginationShippingMethods.page;
    }
    static loading(state: ShippingMethodsStateModel) {
        return state.loading;
    }
}