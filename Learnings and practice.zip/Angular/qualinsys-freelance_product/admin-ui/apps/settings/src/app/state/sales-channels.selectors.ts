import { Selector } from '@ngxs/store';
import {
    SaleschannelsStateModel,
    SaleschannelsState,
} from './sales-channels.state';


export class SaleschannelsStateSelectors {
    @Selector([SaleschannelsState])
    static saleschannelsList(state: SaleschannelsStateModel) {
        return state['saleschannelsList'];
    }
    static pageSize(state: SaleschannelsStateModel) {
        return state.paginationSaleschannels.size;
    }
    static total(state: SaleschannelsStateModel) {
        return state.total;
    }
    static pageIndex(state: SaleschannelsStateModel) {
        return state.paginationSaleschannels.page;
    }
    static loading(state: SaleschannelsStateModel) {
        return state.loading;
    }
}