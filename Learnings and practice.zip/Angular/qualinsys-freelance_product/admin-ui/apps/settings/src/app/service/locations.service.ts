import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../state/locations.state';
// import { LocationsState } from '../state/locations.state';

@Injectable({
  providedIn: 'root'
})
export class LocationsService {
  locationData:any=null;
  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  // getLocations(status: any, pagination: IPage): Observable<any> {
  //   const url = `${this.environment.apiUrl}/store/api/locations/search`;
  //   // let params = new HttpParams();
  //   // if (pagination) {
  //   //   params = params.append('page', pagination.page - 1);
  //   // }
  //   // if (pagination?.size) {
  //   //   params = params.append('size', pagination.size.toString());
  //   // }
  //   // if (status !== "skip") {
  //   //   params = params.append('active', status);
  //   // }

  //   const params = {   
  //     page: pagination.page - 1,
  //     size: pagination.size,
  //     pincode:''
  //   }

  //   return this.http.post(url,params)

  // }


  getLocations(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations/search`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size,
      pincode:''
    }
    return this.http.post(url, data)
  }



  updateLocationsStatus(id: number, status: boolean) {
    //locations/7/update-status/false
    const url = `${this.environment.apiUrl}/store/api/locations/${id}/update-status/${status}`;
    return this.http.patch(url, {})
  }
  deleteLocation(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations/${id}`;
    return this.http.delete(url)
  }
  addLocation(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations`;
    return this.http.post(url, payload)
  }
  editLocation(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations/${payload.id}`;
    return this.http.put(url, payload)
  }

  getLocationsList() {
    const url = `${this.environment.apiUrl}/store/api/locations?page=0&size=100`;
    return this.http.get(url, {});
  }
}

