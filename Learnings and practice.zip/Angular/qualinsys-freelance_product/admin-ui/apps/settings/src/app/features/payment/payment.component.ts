import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { AbstractControl, FormArray, FormControl, FormGroup, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { PaymentService } from '../../service/payment.service';
import { PaymentsStateSelectors } from '../../state/payment.selectors';
import { AddPayments, ChangePaymentsPage, DeletePayments, EditPayments, GetPaymentsList, UpdatePaymentsStatus } from '../../state/payment.action';


export interface Data {
  name: string;
  lastUpdatedOn: null;

}

@Component({
  selector: 'commerceq-admin-ui-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.less'],
})
export class PaymentComponent {
  size: NzButtonSize = 'large';
  tabs = ['Payment Methods'];
  activetabIndex = 0;
  tabStatus: any = true;
  data: any;

  paymentsList: any = [];
  showDeleteModal: boolean = false;
  selectedCategory: any = {};
  enabledValues = [
    { key: true, name: 'Active' },
    { key: false, name: 'Inactive' }
  ]
  public paginationLimit = [10, 20, 50, 100]

  deleteitempayment: any = [];


  @Select((state: any) => state.payments.paymentsList)
  paymentsList$!: Observable<any>;
  @Select((state: any) => state.payments.paginationPayments.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.payments.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.payments.paginationPayments.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.payments.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;


  paymentForm!: UntypedFormGroup;




  constructor(private store: Store, private fb: UntypedFormBuilder,
    private paymentService: PaymentService) {
    this.data = [
      {
        name: 'Online',
        type: 'Payment Gateways'
      },
      {
        name: 'COD2',
        type: 'Offline'
      },
      {
        name: 'COD3',
        type: 'Cash On Delivery'
      },
      {
        name: 'PayZapp',
        type: 'Payment Gateways'
      },
      {
        name: 'Home',
        type: 'Payment Gateways'
      },
      {
        name: 'CCC',
        type: 'Cash On Delivery'
      },
      {
        name: 'COD',
        type: 'Offline'
      }
    ]
  }
  paymentMethodsList: any = [];
  paymentGateWayList: any = [];
  paymentMethodRulesList: any = [];
  additionalChargeTypeList: any = [{
    name: 'Select Option', key: ''
  }, {
    name: 'Flat', key: 'FLAT'
  }, {
    name: 'Percentage', key: 'PERCENTAGE'
  }]
  async ngOnInit() {
    this.paymentForm = this.fb.group({
      name: ['', [Validators.required]],
      paymentMethodType: ['', [Validators.required]],
      additionalChargeType: ['', [Validators.required]],
      additionalCharge: ['', [Validators.required]],
      gatewayType: ['', [Validators.required]],
      field: ['', [Validators.required]],
      operator: ['', [Validators.required]],
      value: ['', [Validators.required]],
      config: new FormGroup({})

    });
    this.paymentForm.get('gatewayType')?.valueChanges.subscribe((selectedValue: string) => {
     
      if(selectedValue != '' && selectedValue != null){
        this.fetchFormData(selectedValue);
      }
    });
    this.paymentForm.get('field')?.valueChanges.subscribe((selectedValue: string) => {
      this.options = [];
      console.log(selectedValue);
      
      if(selectedValue != '' && selectedValue != null){
        this.fetchRuleFieldData(selectedValue);
      }
      
    });
    this.store.dispatch(new GetPaymentsList(true));
    this.paymentService.getPaymentMethodsList().subscribe((method: any) => {
      this.paymentMethodsList = method;
    })
    this.paymentService.getPaymentGateWaysList().subscribe((GateWays: any) => {
      this.paymentGateWayList = GateWays;
    })
    this.paymentService.getPaymentMethodRulesList().subscribe((MethodRules: any) => {
      this.paymentMethodRulesList = MethodRules;
    })


  }

  //add condition data
  insertData: boolean = false;
  opratorList: any = [];
  fetchRuleFieldData(type: string) {
    console.log(type, 'typetype');
    this.opratorList = [];
    this.paymentService.getruleFieldOperatorsList(type).subscribe((data: any) => {
      this.opratorList = data;
    });
  }

  conditionDataList: any = [];
  options: any = [];
  inputValue?: string;
  selectedValue = null;
  listOfSelectedValue = [];
  nzFilterOption = (): boolean => true;
  isLoading = false;
  onInputChange(value: any): void {

    this.isLoading = true;
    this.inputValue = value;
    if (this.inputValue !== undefined && this.inputValue.trim().length >= 3) {

      let value = this.inputValue?.trim();
      let type = this.paymentForm.value.field;
      if (type == 'COUNTRY' && value.length >= 3) {
        this.paymentService.getCountryautocompleteList(value).subscribe((data: any) => {
          this.options = data;
          this.isLoading = false;
        });
      } else if (type == 'STATE' && value.length >= 3) {
        this.paymentService.getStateautocompleteList(value).subscribe((data: any) => {
          this.options = data;
          this.isLoading = false;

        });
      } else {
        this.options = [];
      }
    } else {
      this.options = [];
    }

  }
  btnType: string = 'Insert Condition';
  enableCondition() {

    this.insertData = true;
    this.btnType = 'Insert Condition';
  }
  indexToRemove: number = -1;
  editCondition(obj: any, ind: number) {
    this.insertData = true;
    this.btnType = 'Update Condition';
    this.indexToRemove = ind;
    this.paymentForm.controls['field'].setValue(obj.field);
    this.paymentForm.controls['operator'].setValue(obj.operator);
    this.paymentForm.controls['value'].setValue(obj.value);
    if (obj.field == 'COUNTRY') {
      this.onInputChange(obj.value.name);

    }
    if (obj.field == 'STATE') {
      this.options = obj.value;
    }
  }
  deleteCondition(ind: number) {
    this.conditionDataList.splice(ind, 1);
  }
  addCondition() {

    let obj = {
      field: this.paymentForm.value.field,
      operator: this.paymentForm.value.operator,
      value: this.paymentForm.value.value,
    }
    if (this.btnType == 'Update Condition') {
      // this.conditionDataList.splice(this.indexToRemove, 1);
      // this.conditionDataList.push(obj);
      this.conditionDataList[this.indexToRemove] = obj;

    } else {
      this.conditionDataList.push(obj);
    }

    this.paymentForm.controls['field'].setValue('');
    this.paymentForm.controls['operator'].setValue('');
    this.paymentForm.controls['value'].setValue('');
    this.insertData = false;
  }
  cancelCondition() {
    this.insertData = false;
  }

  //g5etting form data
  formFields: any = [];


  fetchFormData(type: string) {
    console.log(type, 'typetype');
    this.formFields = [];
    this.paymentService.getPaymentTypeFieldsListList(type).subscribe((data: any) => {
      this.formFields = data;
      this.createNestedFormGroup(this.formFields, type)
    });
  }

  createNestedFormGroup(data: any, type?: string) {
    this.removeNestedFormGroup();
    const nestedFormGroup = new FormGroup({});
    if (this.modaltitle == 'Edit Payment Method' && (this.editTotalData.paymentGatewayConfig.type == type)) {
      data.forEach((item: any, i: any) => {
        nestedFormGroup.addControl(item.key, new FormControl(this.paymentGateValues[i]));
      });
    } else {
      data.forEach((item: any) => {
        nestedFormGroup.addControl(item.key, new FormControl(''));
      });
    }

    this.paymentForm.addControl('config', nestedFormGroup);
  }

  removeNestedFormGroup() {
    // Remove the nested FormGroup from the parent FormGroup
    this.paymentForm.removeControl('config');
  }

  updateFormArray(newData: any[]): void {
    const myFormArray = this.paymentForm.get('config') as FormArray;
    myFormArray.clear();

    newData.forEach(item => {
      const formGroup = this.fb.group({
        [item.key]: ''
      });
      myFormArray.push(formGroup);
    });
  }

  getFormArrayControls(): FormGroup[] {
    const myFormArray = this.paymentForm.get('config') as FormArray;
    return myFormArray.controls as FormGroup[];
  }


  isVisible = false;
  showModal(): void {
    this.isVisible = true;
    this.modaltitle = 'Add Payment Method';
  }
  modaltitle: string = 'Add Payment Method';
  editTotalData: any = null;
  paymentGateValues: any = [];
  editModal(category: any) {
    this.isVisible = true;
    this.editTotalData = category;
    console.log(this.editTotalData);

    this.modaltitle = 'Edit Payment Method';
    this.paymentForm.controls['name'].setValue(category.name);
    this.paymentForm.controls['paymentMethodType'].setValue(category.type);

    this.paymentForm.controls['additionalChargeType'].setValue(category.addiontalChargeType);
    this.paymentForm.controls['additionalCharge'].setValue(category.additionalCharge);

    if (category.paymentGatewayConfig.configValues.length > 0) {
      this.paymentForm.controls['gatewayType'].setValue(category.paymentGatewayConfig.type);
      category.paymentGatewayConfig.configValues.forEach((element: any) => {
        console.log(element);
        // element.property.code = element.value;
        this.paymentGateValues.push(element.value);
      });
    }
    this.conditionDataList = [];
    if (category.rules.length > 0) {
      category.rules[0].conditions.forEach((ele: any) => {
        let obj = {
          field: ele.field.key,
          operator: ele.operator.key,
          value: ele.value,
        }
        this.conditionDataList.push(obj);
      });
    }
  }

  Cancel(): void {
    this.isVisible = false;
    this.paymentForm.reset();
  }

  deletePayment() {
    this.showDeleteModal = true;
  }

  SavePayment() {
    console.log(this.paymentForm.value);
    console.log(this.conditionDataList);
    let finalObj: any;
    finalObj = {
      "rules": [
        {
          "ruleType": "PAYMENT_METHOD_RULE",
          "conditions": this.conditionDataList || []
        }
      ],
      "paymentMethodType": this.paymentForm.value.paymentMethodType || null,
      "settings": {
        "gatewayType": this.paymentForm.value.gatewayType|| null,
        "config": this.paymentForm.value.config || null,
      },
      "additionalChargeType": this.paymentForm.value.additionalChargeType|| null,
      "name": this.paymentForm.value.name|| null,
      "additionalCharge": this.paymentForm.value.additionalCharge || null,
    }
   
    for (const key in finalObj) {

      if (finalObj[key] === null || finalObj[key] === undefined) {
        delete finalObj[key];
      }
     
    }
    if (finalObj.settings.gatewayType === null) {
      delete finalObj.settings;
    }

    console.log(finalObj);
    if (this.modaltitle == 'Edit Payment Method') {
      finalObj.id = this.editTotalData.id;
     
      this.store.dispatch(new EditPayments(finalObj)).subscribe((result) => {
        // Handle the success result here if needed
        console.log(result);
        
        if (result.status == 'success') {
            
        }
      });
      setTimeout(() => {
        this.store.dispatch([new GetPaymentsList('')]);
        this.Cancel();
      }, 500);
    } else {
      this.store.dispatch(new AddPayments(finalObj)).subscribe((result) => {
        // Handle the success result here if needed
        console.log(result);
        if (result.status == 'success') {
          
        }
      });
      setTimeout(() => {
        this.store.dispatch([new GetPaymentsList('')]);
        this.Cancel();
      }, 500);
      

    }


  }

  updateCollection(value: any, data: any) {
    let updatedObj = { ...data };
    const date = new Date();
    const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear());
    const lastUpdated = `${day}-${month}-${year}`;


    updatedObj.lastUpdatedOn = lastUpdatedOn;
    updatedObj.lastUpdated = lastUpdated;
    // this.store.dispatch([new UpdateCollectionsStatus(updatedObj.id, updatedObj), new GetCollectionsList(this.tabStatus)])
  }

  onChangePage(page: number): void {
    this.store.dispatch([new ChangePaymentsPage(page), new GetPaymentsList(this.tabStatus)])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdatePaymentsStatus(id, event)])
  }



    DeletePayment(payment: any){
      this.deleteitempayment = payment;
      this.showDeleteModal=true;
    }
 
    deletePaymentID(payment: any) {
      this.deleteitempayment = payment;
      this.showDeleteModal = true;
    }
    proceedtoDelete() {
      this.store.dispatch([new DeletePayments(this.deleteitempayment.id)])
      this.store.dispatch([new GetPaymentsList('')])
      this.showDeleteModal = false;
    }

   

    
    updatePayment(value: any, data: any) {
      let updatedObj = { ...data };  
      this.store.dispatch([new UpdatePaymentsStatus(updatedObj.id, value), new GetPaymentsList(this.tabStatus)])
    }
}
