import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddPickupLocation, ChangePickupLocationPage, DeletePickupLocation, EditPickupLocation, GetPickupLocationList, UpdatePickupLocationStatus } from './pickup-location.action';
import { PickupLocationService } from '../service/pickup-location.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface PickupLocationStateModel {
    [x: string]: any;
    PickupLocationList: [];
    paginationPickupLocation: IPage;
    total: number;
    loading: boolean;
}
@State<PickupLocationStateModel>({
    name: 'PickupLocation',
    defaults: {
        PickupLocationList: [],
        paginationPickupLocation: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class PickupLocationState implements NgxsOnInit {
    constructor(private PickupLocationService: PickupLocationService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetPickupLocationList)
    getPickupLocationList({ getState, patchState }: StateContext<PickupLocationStateModel>, action: GetPickupLocationList) {
        const { paginationPickupLocation } = getState();
        patchState({ loading: true })
        return this.PickupLocationService.getPickupLocation(action.status, paginationPickupLocation).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const PickupLocationList = result.content;
                    const total = result.length;
                    patchState({
                        PickupLocationList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangePickupLocationPage)
    changePickupLocationPage({ patchState, getState }: StateContext<PickupLocationStateModel>, action: ChangePickupLocationPage) {
        patchState({ paginationPickupLocation: { ...getState().paginationPickupLocation, page: action.paylaod } })
    }
    @Action(UpdatePickupLocationStatus)
    updatePickupLocationStatus({ patchState }: StateContext<PickupLocationStateModel>, action: UpdatePickupLocationStatus) {
        patchState({ loading: true })
        return this.PickupLocationService.updatePickupLocationStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeletePickupLocation)
    deletePickupLocation({ patchState }: StateContext<PickupLocationStateModel>, action: DeletePickupLocation) {
        patchState({ loading: true })
        return this.PickupLocationService.deletePickupLocation(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddPickupLocation)
    addPickupLocation({ patchState }: StateContext<PickupLocationStateModel>, action: AddPickupLocation) {
        patchState({ loading: true })
        return this.PickupLocationService.addPickupLocation(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
   
}