export class GetShippingMethodsList {
    static readonly type = '[ShippingMethods] Get ShippingMethods';
    constructor(public status: any) { }
}

export class ChangeShippingMethodsPage {
    static readonly type = '[ShippingMethods] Change ShippingMethods Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdateShippingMethodsStatus {
    static readonly type = '[ShippingMethods] Update ShippingMethods Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeleteShippingMethods {
    static readonly type = '[ShippingMethods] Delete ShippingMethods';
    constructor(public readonly id: number) { }
}

export class AddShippingMethods {
    pipe(arg0: any) {
      throw new Error('Method not implemented.');
    }
    static readonly type = '[ShippingMethods] Add ShippingMethods';
    constructor(public readonly payload: any) { }
}
export class EditShippingMethods {
    static readonly type = '[ShippingMethods] Edit ShippingMethods';
    constructor(public readonly payload: any) { }
}