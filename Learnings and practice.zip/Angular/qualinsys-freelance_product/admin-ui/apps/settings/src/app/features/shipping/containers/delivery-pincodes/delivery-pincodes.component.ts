import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-delivery-pincodes',
  templateUrl: './delivery-pincodes.component.html',
  styleUrls: ['./delivery-pincodes.component.less'],
})
export class DeliveryPincodesComponent {}
