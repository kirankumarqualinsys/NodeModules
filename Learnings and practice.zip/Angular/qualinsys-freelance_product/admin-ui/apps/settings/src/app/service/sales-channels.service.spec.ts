import { TestBed } from '@angular/core/testing';

import { SalesChannelsService } from './sales-channels.service';

describe('SalesChannelsService', () => {
  let service: SalesChannelsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SalesChannelsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
