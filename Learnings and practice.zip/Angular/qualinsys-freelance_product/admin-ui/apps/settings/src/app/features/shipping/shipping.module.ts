import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShippingComponent } from './shipping.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShippingMethodsComponent } from './containers/shipping-methods/shipping-methods.component';
import { ShippingSettingsComponent } from './containers/shipping-settings/shipping-settings.component';
import { DeliveryPincodesComponent } from './containers/delivery-pincodes/delivery-pincodes.component';
import { PickupLocationsComponent } from './containers/pickup-locations/pickup-locations.component';

import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzAlertModule } from 'ng-zorro-antd/alert';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzModalModule } from 'ng-zorro-antd/modal';
import{AddAddressModalModule} from '../../../../../../libs/shared/src/lib/modals/add-address-modal/add-address-modal.module';


@NgModule({
  declarations: [
    ShippingComponent,
    ShippingMethodsComponent,
    ShippingSettingsComponent,
    DeliveryPincodesComponent,
    PickupLocationsComponent 

  ],
  imports: [
    CommonModule,
   RouterModule.forChild([
      {
        path: '',
        component: ShippingComponent,
        children: [
          {
            path: '',
            component: ShippingSettingsComponent,
          },
          {
            path:'view',
            component: ShippingSettingsComponent,
          },
          {
            path: 'da',
            component: DeliveryPincodesComponent,
          },
          {
            path: 'pl',
            component: PickupLocationsComponent,
          },
          {
            path: 'sm',
            component: ShippingMethodsComponent
          }
        ],
      },
    ]),

    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzSelectModule,
    NzInputModule,
    NzButtonModule,
    NzTabsModule,
    NzDividerModule,
    NzAlertModule,
    NzCheckboxModule,
    NzTableModule,
    NzDropDownModule,
    NzSwitchModule,
    NzModalModule,
    AddAddressModalModule,
  ],
})
export class ShippingModule {}
