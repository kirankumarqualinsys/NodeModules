import { Component } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { BusinessService } from '../../service/business.service';

@Component({
  selector: 'commerceq-admin-ui-business',
  templateUrl: './business.component.html',
  styleUrls: ['./business.component.less'],
})
export class BusinessComponent {

  businessForm!: UntypedFormGroup;
  adressFormGroup!: UntypedFormGroup;
  constructor(private fb: UntypedFormBuilder , public businessService : BusinessService){
    this.businessForm=this.fb.group({
      businessType:[null,[Validators.required]],
      businessName:['',[Validators.required]],
      year:[''],
      pan:[''],
      companyIdType:[''],
      companyId:[''],
      TaxNumberType:[''],
      TaxNumber:['']
    });

    this.adressFormGroup=this.fb.group({
        countryId:[null,],
        stateId:[null],
        city:[''],
        locality:[''],
        postalCode:[''],
        address:[''],
        landmark:[''],
    });
  }
  ngOnInit(): void {  
    this.getBusinessTypeList();
    this.getCompanyList();
    this.getTaxList();
    this.getBusinessList();
    this.getcountryList();
    this.getstateList();
  }
 

  companyIdTypeList: any = [];
  getCompanyList(): void {
    this.businessService.getCompanyList().subscribe((res: any) => {
      this.companyIdTypeList = [];
        this.companyIdTypeList = res; 
    })

  }
taxList: any = [];
getTaxList(): void {
    this.businessService.getTaxList().subscribe((res: any) => {
      this.taxList = [];
        this.taxList = res; 
    })

  }
  
  businessTypeList: any = [];
  getBusinessTypeList(): void {
    this.businessService.getBusinessTypeDetailsList().subscribe((res: any) => {
      this.businessTypeList = [];
        this.businessTypeList = res; 
    })

  }

  businessDetailsList: any = [];
  getBusinessList(): void {
    this.businessService.getBusinessDetailsList().subscribe((res: any) => {
      this.businessDetailsList = [];
        this.businessDetailsList = res;
        this.businessForm.controls['businessType'].setValue(this.businessDetailsList?.businessType.key);
        this.businessForm.controls['businessName'].setValue(this.businessDetailsList.name);
        this.businessForm.controls['year'].setValue(this.businessDetailsList.establishedYear);        
        this.businessForm.controls['pan'].setValue(this.businessDetailsList?.pan);
        this.businessForm.controls['companyIdType'].setValue(this.businessDetailsList.companyIdType.name);
        this.businessForm.controls['companyId'].setValue(this.businessDetailsList.companyId);        
        this.businessForm.controls['TaxNumberType'].setValue(this.businessDetailsList?.taxType.name);
        this.businessForm.controls['TaxNumber'].setValue(this.businessDetailsList.taxNumber);
        console.log('business',this.businessDetailsList);    
      // }
    })

  }

  countryList: any = [];
getcountryList(): void {
    this.businessService.getCountrysList().subscribe((res: any) => {
      this.countryList = [];
        this.countryList.push(res); 
        console.log('countryList list',  this.countryList);
    })

  }

  stateList: any = [];
getstateList(): void {
    this.businessService.getStatesList().subscribe((res: any) => {
      this.stateList = [];
        this.stateList.push(res); 
        console.log('state list',  this.stateList);
    })

  }


  submitForm(){
    console.log(this.businessForm.value);
    
  }


  isVisible=false;
  locaionList: any = [];
  showModal(data:any): void {
    this.locaionList = data.businessLocation;
    this.adressFormGroup.controls['countryId'].setValue(this.locaionList?.countryId);
    this.adressFormGroup.controls['stateId'].setValue(this.locaionList.stateId);
    this.adressFormGroup.controls['city'].setValue(this.locaionList.city);
    this.adressFormGroup.controls['locality'].setValue(this.locaionList.locality); 
    this.adressFormGroup.controls['landmark'].setValue(this.locaionList.landmark);        
    this.adressFormGroup.controls['postalCode'].setValue(this.locaionList?.postalCode);
    this.adressFormGroup.controls['address'].setValue(this.locaionList.address); 
    this.isVisible = true;
  }

  Cancel(): void {
    this.isVisible = false;
  }

  updateLocationDetailsList(): void {
    // if (this.businessForm.valid) {
      let locaionListObj = { ...this.locaionList }; 
      locaionListObj.countryId = this.adressFormGroup.value.countryId;
      locaionListObj.stateId = this.adressFormGroup.value.stateId;
      locaionListObj.city = this.adressFormGroup.value.city;
      locaionListObj.locality = this.adressFormGroup.value.locality;
      locaionListObj.landmark = this.adressFormGroup.value.landmark;
      locaionListObj.postalCode = this.adressFormGroup.value.postalCode;
      locaionListObj.address = this.adressFormGroup.value.address;  
    this.businessService.updateLocationDetailsList(locaionListObj).subscribe((res: any) => {
      console.log('service success', res);
    })
  // }

  }


  updateBusinessDetailsList(): void {
      // if (this.businessForm.valid) {
      let businessDetailsListObj = { ...this.businessDetailsList }; 
      businessDetailsListObj.businessType.name =  this.businessForm.value.businessType; 
      businessDetailsListObj.name =   this.businessForm.value.businessName;
     businessDetailsListObj.establishedYear   = this.businessForm.value.year;      
    businessDetailsListObj.pan =  this.businessForm.value.pan; 
     businessDetailsListObj.companyIdType.name =  this.businessForm.value.companyIdType;
     businessDetailsListObj.companyId   =  this.businessForm.value.companyId;     
     businessDetailsListObj.taxType =  this.businessForm.value.TaxNumberType;
      businessDetailsListObj.taxNumber = this.businessForm.value.TaxNumber; 
    this.businessService.updateBusinessDetailsList(businessDetailsListObj).subscribe((res: any) => {
      console.log('service success', res);
    })
  // }
  }
}
