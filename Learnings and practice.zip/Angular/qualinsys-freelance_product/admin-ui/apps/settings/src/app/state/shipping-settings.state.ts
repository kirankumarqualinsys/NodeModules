import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { ShippingSettingsService } from '../service/shipping-settings.service';
import { GetShippingSettingsList } from './shipping-settings.action';

// export interface IPage {
//     size: number;
//     page: number;
//     filter?: string;
//     filterParams?: { value: string[], key: string }[];
//     sort?: { key: string, value: string }
// }
export interface ShippingSettingsStateModel {
    [x: string]: any;
    ShippingSettingsList: [];
    // paginationShippingMethods: IPage;
    total: number;
    loading: boolean;
}
@State<ShippingSettingsStateModel>({
    name: 'ShippingSettings',
    defaults: {
        ShippingSettingsList: [],
        // paginationShippingMethods: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class ShippingSettingsState implements NgxsOnInit {
    constructor(private ShippingSettingsService: ShippingSettingsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetShippingSettingsList)
    getShippingMethodsList({ getState, patchState }: StateContext<ShippingSettingsStateModel>, action: GetShippingSettingsList) {
        
    }
}