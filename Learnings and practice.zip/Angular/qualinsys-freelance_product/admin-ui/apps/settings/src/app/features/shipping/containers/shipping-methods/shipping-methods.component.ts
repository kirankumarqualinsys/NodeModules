import { Component, TrackByFunction } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { ShippingMethodsService } from 'apps/settings/src/app/service/shipping-methods.service';
import { GetShippingMethodsList, UpdateShippingMethodsStatus } from 'apps/settings/src/app/state/shipping-methods.action';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-shipping-methods',
  templateUrl: './shipping-methods.component.html',
  styleUrls: ['./shipping-methods.component.less'],
})
export class ShippingMethodsComponent {
  @Select((state: any) => state.ShippingMethods.ShippingMethodsList)
  ShippingMethodsList$!: Observable<any>;
  @Select((state: any) => state.ShippingMethods.paginationShippingMethods.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.ShippingMethods.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.ShippingMethods.paginationShippingMethods.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.ShippingMethods.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;

data:any;
private showModalSubscription: Subscription | undefined;
  constructor(private store:Store, private smService:ShippingMethodsService){
    this.showModalSubscription = this.smService.showModal$.subscribe((action: string) => {
    
      this.showModal(action);
    });
  }
async ngOnInit() {
   
    this.store.dispatch(new GetShippingMethodsList(true));
  
  }
  //location status cahnge

  updateShippingMethods(value: boolean, id: number) {
    this.store.dispatch([new UpdateShippingMethodsStatus(id, value), new GetShippingMethodsList('')])
  }

  isVisible = false;
  showDeleteModal: boolean = false;
  selectedShippingMethod: any = null;
  title: string = 'Add Shipping Method'
  showModal(sm: any): void {
    if (sm == 'add') {
      this.title = 'Edit Shipping Method';
      this.isVisible = true;
    } else {
      this.isVisible = true;
      this.title = 'Add Shipping Method'
      this.selectedShippingMethod = sm;
      // this.insertData(sm);
    }

  }

  Cancel(): void {
    this.isVisible = false;
  }

  deleteMethod() {
    this.showDeleteModal = true;
  }

}
