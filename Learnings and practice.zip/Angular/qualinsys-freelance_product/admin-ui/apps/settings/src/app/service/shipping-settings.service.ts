import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';

@Injectable({
  providedIn: 'root'
})
export class ShippingSettingsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

    getShippingDetailsList(){
      console.log('hiojjoijijio');
    const url = `${this.environment.apiUrl}/store/api/settings/shipping`;
    return this.http.get(url)
    }
    getShippingBoundaries(){
      console.log('hiojjoijijio');
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/shipping-boundareis`;
    return this.http.get(url)
    }

}
