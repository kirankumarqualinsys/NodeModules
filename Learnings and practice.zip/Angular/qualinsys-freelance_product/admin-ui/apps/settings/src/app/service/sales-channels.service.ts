import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';

import { IPage } from '../state/payment.state';
@Injectable({
  providedIn: 'root'
})
export class SalesChannelsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
    getsalesChannels(status: any, pagination: IPage): Observable<any> {
      const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels`;
      // let params = new HttpParams();
      // if (pagination) {
      //   params = params.append('page', pagination.page - 1);
      // }
      // if (pagination?.size) {
      //   params = params.append('size', pagination.size.toString());
      // }
      // if (status !== "skip") {
      //   params = params.append('active', status);
      // }
      return this.http.get(url)
  
    }
    updatesaleschannelsStatus(id: number, status: boolean) {
      const url = `${this.environment.apiUrl}/store/api/payment-methods${id}/${status}`;
      return this.http.patch(url, {})
    }
    deletesaleschannels(id: number): Observable<any> {
      const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels/${id}`;
      return this.http.delete(url)
    }
    addsaleschannels(payload: any): Observable<any> {
      const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels/add`;
      return this.http.post(url, payload)
    }
    editsaleschannels(payload: any): Observable<any> {
      const url = `${this.environment.apiUrl}/store/api/payment-methods/${payload.id}`;
      return this.http.put(url, payload)
    }
  
    getsaleschannelsList() {
      const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels`;
      return this.http.get(url, {});
    }

    getsales() {
      const url = `${this.environment.apiUrl}/store/api/v1/sales-channels`;
      return this.http.get(url, {});
    }
  }
  
