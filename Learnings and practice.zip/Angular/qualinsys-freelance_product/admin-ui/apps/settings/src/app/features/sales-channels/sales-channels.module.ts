import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesChannelsComponent } from './sales-channels.component';
import { RouterModule } from '@angular/router';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';

import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [SalesChannelsComponent],
  imports: [CommonModule,
    RouterModule.forChild([{ path: '', component: SalesChannelsComponent }]),

    NzButtonModule,
    NzTabsModule,
    NzDividerModule,
    NzTableModule,
    NzDropDownModule,
    NzModalModule ,
    NzSwitchModule,
    NzPaginationModule
,
FormsModule
   
  ],
})
export class SalesChannelsModule {}
