export class GetShippingSettingsList {
    static readonly type = '[ShippingSettings] Get ShippingSettings';
    constructor(public status: any) { }
}