import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddSaleschannels, ChangeSaleschannelsPage, DeleteSaleschannels, EditSaleschannels, GetSaleschannelsList, UpdateSaleschannelsStatus } from './sales-channels.action';
import { SalesChannelsService } from '../service/sales-channels.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface SaleschannelsStateModel {
    [x: string]: any;
    saleschannelsList: [];
    paginationSaleschannels: IPage;
    total: number;
    loading: boolean;
}
@State<SaleschannelsStateModel>({
    name: 'saleschannels',
    defaults: {
        saleschannelsList: [],
        paginationSaleschannels: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class SaleschannelsState implements NgxsOnInit {
    constructor(private salesChannelsService: SalesChannelsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetSaleschannelsList)
    getsaleschannelsList({ getState, patchState }: StateContext<SaleschannelsStateModel>, action: GetSaleschannelsList) {
        const { paginationSaleschannels } = getState();
        patchState({ loading: true })
        return this.salesChannelsService.getsaleschannelsList().pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const saleschannelsList = result?.data;
                    const total = result?.data?.length;
                    patchState({
                        saleschannelsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeSaleschannelsPage)
    ChangeSaleschannelsPage({ patchState, getState }: StateContext<SaleschannelsStateModel>, action: ChangeSaleschannelsPage) {
        patchState({ paginationSaleschannels: { ...getState().paginationSaleschannels, page: action.paylaod } })
    }
    @Action(UpdateSaleschannelsStatus)
    updatesaleschannelsStatus({ patchState }: StateContext<SaleschannelsStateModel>, action: UpdateSaleschannelsStatus) {
        patchState({ loading: true })
        return this.salesChannelsService.updatesaleschannelsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeleteSaleschannels)
    deletesaleschannels({ patchState }: StateContext<SaleschannelsStateModel>, action: DeleteSaleschannels) {
        patchState({ loading: true })
        return this.salesChannelsService.deletesaleschannels(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddSaleschannels)
    addsaleschannels({ patchState }: StateContext<SaleschannelsStateModel>, action: AddSaleschannels) {
        patchState({ loading: true })
        return this.salesChannelsService.addsaleschannels(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(EditSaleschannels)
    editsaleschannels({ patchState }: StateContext<SaleschannelsStateModel>, action: EditSaleschannels) {
        patchState({ loading: true })
        return this.salesChannelsService.editsaleschannels(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
}