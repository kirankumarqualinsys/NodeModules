import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BusinessComponent } from './business.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { NzFormModule } from 'ng-zorro-antd/form';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzModalModule  } from 'ng-zorro-antd/modal';

@NgModule({
    declarations: [BusinessComponent],
    imports: [CommonModule,
        RouterModule.forChild([{ path: '', component: BusinessComponent }]),
        FormsModule,
        ReactiveFormsModule,
        NzFormModule, 
        NzSelectModule,
        NzInputModule,
        NzModalModule

    ],
})
export class BusinessModule { }