import { Selector } from '@ngxs/store';
import {
    PaymentsStateModel,
    PaymentsState,
} from './payment.state';


export class PaymentsStateSelectors {
    @Selector([PaymentsState])
    static paymentsList(state: PaymentsStateModel) {
        return state['paymentsList'];
    }
    static pageSize(state: PaymentsStateModel) {
        return state.paginationPayments.size;
    }
    static total(state: PaymentsStateModel) {
        return state.total;
    }
    static pageIndex(state: PaymentsStateModel) {
        return state.paginationPayments.page;
    }
    static loading(state: PaymentsStateModel) {
        return state.loading;
    }
}