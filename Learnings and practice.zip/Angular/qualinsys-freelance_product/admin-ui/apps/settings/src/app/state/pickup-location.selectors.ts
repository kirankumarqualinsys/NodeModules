import { Selector } from '@ngxs/store';
import {
    PickupLocationStateModel,
    PickupLocationState,
} from './pickup-location.state';


export class PickupLocationStateSelectors {
    @Selector([PickupLocationState])
    static PickupLocationList(state: PickupLocationStateModel) {
        return state['PickupLocationList'];
    }
    static pageSize(state: PickupLocationStateModel) {
        return state.paginationPickupLocation.size;
    }
    static total(state: PickupLocationStateModel) {
        return state.total;
    }
    static pageIndex(state: PickupLocationStateModel) {
        return state.paginationPickupLocation.page;
    }
    static loading(state: PickupLocationStateModel) {
        return state.loading;
    }
}