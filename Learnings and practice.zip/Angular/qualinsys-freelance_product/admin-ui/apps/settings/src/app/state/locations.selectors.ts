import { Selector } from '@ngxs/store';
import {
    LocationsStateModel,
    LocationsState,
} from './locations.state';


export class LocationsStateSelectors {
    @Selector([LocationsState])
    static locationsList(state: LocationsStateModel) {
        return state['locationsList'];
    }
    static pageSize(state: LocationsStateModel) {
        return state.paginationLocations.size;
    }
    static total(state: LocationsStateModel) {
        return state.total;
    }
    static pageIndex(state: LocationsStateModel) {
        return state.paginationLocations.page;
    }
    static loading(state: LocationsStateModel) {
        return state.loading;
    }
}