import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable, Subject } from 'rxjs';

import { IPage } from '../state/pickup-location.state';


@Injectable({
  providedIn: 'root'
})
export class PickupLocationService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getPickupLocation(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations/search`;
    let obj = {
      page: pagination.page - 1,
      size: pagination.size.toString(),
      pincode: ""
    }

    return this.http.post(url, obj)

  }
  updatePickupLocationStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/store/api/locations/${id}/update-status/${status}`;
    return this.http.put(url, {})
  }
  deletePickupLocation(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/locations/${id}`;
    return this.http.delete(url)
  }
  addPickupLocation(payload: any): Observable<any> {
    payload.code = payload.name;
    const url = `${this.environment.apiUrl}/store/api/locations`;
    return this.http.post(url, payload)
  }


  getPickupLocationList() {
    const url = `${this.environment.apiUrl}/store/api/payment-methods?page=0&size=100`;
    return this.http.get(url, {});
  }

  private showModalSource = new Subject<string>();
  showModal$ = this.showModalSource.asObservable();

  openLocationModal(action: string) {
    console.log(action);
    
    this.showModalSource.next(action);
  }

}
