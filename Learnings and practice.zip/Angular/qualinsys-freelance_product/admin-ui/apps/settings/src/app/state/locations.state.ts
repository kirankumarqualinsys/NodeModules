import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddLocation, ChangeLocationsPage, DeleteLocation, DeleteLocationsStatus, EditLocation, GetLocationsList, UpdateLocationsStatus } from './locations.action';
import { LocationsService } from '../service/locations.service';

export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface LocationsStateModel {
    [x: string]: any;
    locationsList: [];
    paginationLocations: IPage;
    total: number;
    loading: boolean;
}
@State<LocationsStateModel>({
    name: 'locations',
    defaults: {
        locationsList: [],
        paginationLocations: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})

@Injectable()
export class LocationsState implements NgxsOnInit {
    constructor(private locationsService: LocationsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetLocationsList)
    getLocations({ getState, patchState }: StateContext<LocationsStateModel>, action: GetLocationsList) {
        const { paginationLocations } = getState();
        patchState({ loading: true })
        return this.locationsService.getLocations(action, paginationLocations).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const locationsList = result.content;
                    const total = result.length;
                    patchState({
                        locationsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeLocationsPage)
    changePaymentsPage({ patchState, getState }: StateContext<LocationsStateModel>, action: ChangeLocationsPage) {
        patchState({ paginationPayments: { ...getState().paginationLocations, page: action.paylaod } })
    }
    @Action(UpdateLocationsStatus)
    updateLocationsStatus({ patchState }: StateContext<LocationsStateModel>, action: UpdateLocationsStatus) {
        patchState({ loading: true })
        return this.locationsService.updateLocationsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeleteLocationsStatus)
    deleteLocation({ patchState }: StateContext<LocationsStateModel>, action: DeleteLocationsStatus) {
        patchState({ loading: true })
        return this.locationsService.deleteLocation(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddLocation)
    addLocation({ patchState }: StateContext<LocationsStateModel>, action: AddLocation) {
        patchState({ loading: true })
        return this.locationsService.addLocation(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(EditLocation)
    editLocation({ patchState }: StateContext<LocationsStateModel>, action: EditLocation) {
        patchState({ loading: true })
        return this.locationsService.editLocation(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
}