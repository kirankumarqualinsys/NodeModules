import { TestBed } from '@angular/core/testing';

import { ShippingSettingsService } from './shipping-settings.service';

describe('ShippingSettingsService', () => {
  let service: ShippingSettingsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShippingSettingsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
