import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeliveryPincodesComponent } from './delivery-pincodes.component';

describe('DeliveryPincodesComponent', () => {
  let component: DeliveryPincodesComponent;
  let fixture: ComponentFixture<DeliveryPincodesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DeliveryPincodesComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(DeliveryPincodesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
