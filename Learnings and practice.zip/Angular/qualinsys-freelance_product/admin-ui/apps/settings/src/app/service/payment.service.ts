import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';

import { IPage } from '../state/payment.state';


@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getPayments(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/payment-methods`;
    let params = new HttpParams();
    if (pagination) {
      params = params.append('page', pagination.page - 1);
    }
    if (pagination?.size) {
      params = params.append('size', pagination.size.toString());
    }
    if (status !== "skip") {
      params = params.append('active', status);
    }
    return this.http.get(url, { params })

  }
  updatePaymentsStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/store/api/payment-methods/${id}/update-status/${status}`;
    return this.http.put(url, {})
  }
  deletePayment(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/payment-methods/${id}`;
    return this.http.delete(url)
  }
  addPayment(payload: any): Observable<any> {
    payload.code = payload.name;
    const url = `${this.environment.apiUrl}/store/api/payment-methods`;
    return this.http.post(url, payload)
  }
  editPayment(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/payment-methods/${payload.id}`;
    return this.http.put(url, payload)
  }

  getPaymentsList() {
    const url = `${this.environment.apiUrl}/store/api/payment-methods?page=0&size=100`;
    return this.http.get(url, {});
  }
  getPaymentMethodsList() {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/payment-methods`;
    return this.http.get(url, {});
  }
  getPaymentGateWaysList() {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/payment-gateways`;
    return this.http.get(url, {});
  }
  getPaymentMethodRulesList() {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/rule-fields/PAYMENT_METHOD_RULE`;
    return this.http.get(url, {});
  }
  getruleFieldOperatorsList(type:string) {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/rule-field-operators/${type}`;
    return this.http.get(url, {});
  }
  getPaymentTypeFieldsListList(type:string) {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/payment-gateway-config/${type}`;
    return this.http.get(url, {});
  }
  getCountryautocompleteList(type:string) {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/countries/autocompleter?query=${type}`;
    return this.http.get(url, {});
  }
  getStateautocompleteList(type:string) {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/states/autocompleter?country=India&query=${type}`;
    return this.http.get(url, {});
  }


}
