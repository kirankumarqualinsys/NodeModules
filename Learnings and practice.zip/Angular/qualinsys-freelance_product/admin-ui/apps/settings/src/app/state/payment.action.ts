export class GetPaymentsList {
    static readonly type = '[Payments] Get Payments';
    constructor(public status: any) { }
}

export class ChangePaymentsPage {
    static readonly type = '[Payments] Change Payments Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdatePaymentsStatus {
    static readonly type = '[Payments] Update Payments Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeletePayments {
    static readonly type = '[Payments] Delete Payments';
    constructor(public readonly id: number) { }
}

export class AddPayments {
    pipe(arg0: any) {
      throw new Error('Method not implemented.');
    }
    static readonly type = '[Payments] Add Payments';
    constructor(public readonly payload: any) { }
}
export class EditPayments {
    static readonly type = '[Payments] Edit Payments';
    constructor(public readonly payload: any) { }
}