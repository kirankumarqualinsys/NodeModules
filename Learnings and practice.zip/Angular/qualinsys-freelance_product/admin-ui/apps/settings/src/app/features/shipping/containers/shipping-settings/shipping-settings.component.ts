import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PaymentService } from 'apps/settings/src/app/service/payment.service';
import { ShippingSettingsService } from 'apps/settings/src/app/service/shipping-settings.service';
import { StoreService } from 'apps/settings/src/app/service/store.service';

@Component({
  selector: 'commerceq-admin-ui-shipping-settings',
  templateUrl: './shipping-settings.component.html',
  styleUrls: ['./shipping-settings.component.less'],
})
export class ShippingSettingsComponent {

  shippingForm!: any;
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    public storeService: StoreService,
    public paymentService:PaymentService,
    public shippingService:ShippingSettingsService,
   
    )
     {
    this.shippingForm = this.fb.group({
      shippingBoundary: [''],
      enablePartialFulfilment: [''],
      enablePincodeCheckForDelivery: [''],
      checkPaymentMethodAvailability:[''],
      shipmentLength:[''],
      shipmentWidth:[''],
      shipmentBreadth:[''],
      shippingOriginAddress:[''],
      shippingReturnAddress:['']
    });
  }
  
  ngOnInit(): void {
    this.getDimensionUnits();
    this.getWeightUnits();
    this.getShippingBoundaries();
  }

  ShippingBoundariesList:any=[];
  getShippingBoundaries() {
   this.shippingService.getShippingBoundaries().subscribe((res:any)=>{
    this.ShippingBoundariesList=[];
    this.ShippingBoundariesList=res;
   }) 
  }
  

  weightUnitList: any = [];
  getWeightUnits() {
    this.storeService.getWeightUnits().subscribe((res: any) => {
      this.weightUnitList = [];
      this.weightUnitList = res;
    })
  }

  dimensionUnitList: any = [];
  getDimensionUnits() {
    this.storeService.getDimensionUnits().subscribe((res: any) => {
      this.dimensionUnitList = [];
      this.dimensionUnitList = res;
    })
  }




  isVisible = false;

  showModal() {
    this.isVisible=true;
  }

  formSubmit($event: any) {
    console.log($event);
  }
  Cancel(): void {
    this.isVisible = false;
  }
}
