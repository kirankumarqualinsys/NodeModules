export class GetSaleschannelsList {
    static readonly type = '[Saleschannels] Get Saleschannels';
    constructor(public status: any) { }
}

export class ChangeSaleschannelsPage {
    static readonly type = '[Saleschannels] Change Saleschannels Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdateSaleschannelsStatus {
    static readonly type = '[Saleschannels] Update Saleschannels Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeleteSaleschannels {
    static readonly type = '[Saleschannels] Delete Saleschannels';
    constructor(public readonly id: number) { }
}

export class AddSaleschannels {
    static readonly type = '[Saleschannels] Add Saleschannels';
    constructor(public readonly payload: any) { }
}
export class EditSaleschannels {
    static readonly type = '[Saleschannels] Edit Saleschannels';
    constructor(public readonly payload: any) { }
}