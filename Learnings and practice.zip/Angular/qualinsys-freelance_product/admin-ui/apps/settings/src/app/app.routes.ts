
import { Route } from '@angular/router';


export const appRoutes: Route[] = [
  {
    path: '',
    loadChildren: () =>
      import('./features/settings-home/settings-home.module').then(m => m.SettingsHomeModule)
  }
];