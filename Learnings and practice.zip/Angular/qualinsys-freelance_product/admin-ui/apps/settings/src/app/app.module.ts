import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { appRoutes } from "./app.routes";
import { NgxsModule } from "@ngxs/store";
import { PaymentsState } from "./state/payment.state";
import { LocationsState } from "./state/locations.state";
import { SaleschannelsState } from "./state/sales-channels.state";
import { PickupLocationState } from "./state/pickup-location.state";
import { ShippingMethodsState } from "./state/shipping-methods.state";

@NgModule({
  declarations: [AppComponent],
  imports: [
    RouterModule.forChild(appRoutes),
    NgxsModule.forFeature([LocationsState , SaleschannelsState, PaymentsState,PickupLocationState,ShippingMethodsState ]),
  ],

  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
