import { Component ,OnInit} from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-settings-home',
  templateUrl: './settings-home.component.html',
  styleUrls: ['./settings-home.component.less'],
})
export class SettingsHomeComponent implements OnInit{
menuConfig:any;
  constructor(){}

  async ngOnInit() {
    this.setMenuItems();
  }
  async setMenuItems() {
    this.menuConfig = {
      items: [
        {
          key: 'business',
          value: 'Business'
        },
        {
          key: 'locations',
          value: 'Locations',
        },
        {
          key: 'sales-channels',
          value: 'Sales Channels'
        },
        {
          key: 'payment',
          value: 'Payment'
        },
        {
          key: 'store',
          value: 'Store',
        },
        {
          key: 'shipping',
          value: 'Shipping',
        },
      ]
    }
  }
}
