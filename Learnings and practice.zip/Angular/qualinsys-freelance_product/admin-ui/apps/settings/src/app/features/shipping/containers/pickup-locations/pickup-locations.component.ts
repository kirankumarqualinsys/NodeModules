import { Component, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { PickupLocationService } from 'apps/settings/src/app/service/pickup-location.service';
import { GetPickupLocationList, UpdatePickupLocationStatus } from 'apps/settings/src/app/state/pickup-location.action';
import { Observable, Subscription } from 'rxjs';


@Component({
  selector: 'commerceq-admin-ui-pickup-locations',
  templateUrl: './pickup-locations.component.html',
  styleUrls: ['./pickup-locations.component.less'],
})
export class PickupLocationsComponent {

  @Select((state: any) => state.PickupLocation.PickupLocationList)
  pickupLocationList$!: Observable<any>;
  @Select((state: any) => state.PickupLocation.paginationPickupLocation.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.PickupLocation.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.PickupLocation.paginationPickupLocation.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.PickupLocation.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  showDeleteModal: boolean = false;
  isVisible = false;
  deletePayment: any;

  //form
  pickupLocationForm !: UntypedFormGroup;
  private showModalSubscription: Subscription | undefined;
  constructor(private store: Store, private fb: UntypedFormBuilder, private pickupLocationService:PickupLocationService) {
    this.showModalSubscription = this.pickupLocationService.showModal$.subscribe((action: string) => {
      console.log('helo from service');
      
      this.showModal(action);
    });
   }
  async ngOnInit() {

    this.store.dispatch(new GetPickupLocationList(true));

    this.pickupLocationForm = this.fb.group({
      "locationId": ['9852762153'],
      "locationName": ['', [Validators.required]],
      "country": ['', [Validators.required]],
      "state": ['', [Validators.required]],
      "city": ['', [Validators.required]],
      "locality": ['', [Validators.required]],
      "postalCode": ['', [Validators.required]],
      "address": ['', [Validators.required]],
      "landmark": ['', [Validators.required]],
      "placeId": [null],
      "longitude": [null],
      "latitude": [null],
      "contactName": ['', [Validators.required]],
      "contactMobile": ['', [Validators.required]],
      "enableFulfilment": [true],
      "enablePickup": [true],
      "enableOutlet": [false],
      "enabledLabel": ['Enabled'],
      "statusLabel": ['Enabled'],
    })

  }
  //location status cahnge

  updateLocation(value: boolean, id: number) {
    this.store.dispatch([new UpdatePickupLocationStatus(id, value), new GetPickupLocationList('')])
  }
  selectedLocation: any = null;
  title: string = 'Edit Pickup Location'
  showModal(location: any): void {
    if (location == 'add') {
      this.title = 'Add Pickup Location';
      this.isVisible = true;
    } else {
      this.isVisible = true;
      this.title = 'Edit Pickup Location'
      this.selectedLocation = location;
      this.insertData(location);
    }

  }

  insertData(obj: any) {
    // Patch the values from the object into the form group
    this.pickupLocationForm.patchValue({
      "locationId": obj.locationId,
      "locationName": obj.locationName,
      "country": obj.country,
      "state": obj.state,
      "city": obj.city,
      "locality": obj.locality,
      "postalCode": obj.postalCode,
      "address": obj.address,
      "landmark": obj.landmark,
      "placeId": obj.placeId,
      "longitude": obj.longitude,
      "latitude": obj.latitude,
      "contactName": obj.contactName,
      "contactMobile": obj.contactMobile,
      "enableFulfilment": obj.enableFulfilment,
      "enablePickup": obj.enablePickup,
      "enableOutlet": obj.enableOutlet,
      "enabledLabel": obj.enabledLabel,
      "statusLabel": obj.statusLabel,
    });

  }


  Cancel(): void {
    this.isVisible = false;
    this.pickupLocationForm.reset();
  }

  deleteMethod() {
    this.showDeleteModal = true;
  }

  ngOnDestroy() {
    if (this.showModalSubscription) {
      this.showModalSubscription.unsubscribe();
    }
  }

}
