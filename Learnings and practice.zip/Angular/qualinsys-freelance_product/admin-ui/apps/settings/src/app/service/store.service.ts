import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';

@Injectable({
  providedIn: 'root'
})
export class StoreService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

    getStoreDetailsList(){
      console.log('hiojjoijijio');
    const url = `${this.environment.apiUrl}/store/api/stores/current`;
    return this.http.get(url)
    }

    getDimensionUnits(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/dimension-units`;
      return this.http.get(url)
    }

    getWeightUnits(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/weight-units`;
      return this.http.get(url)
    }

    getCurrencies(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/currencies`;
      return this.http.get(url)
    }

    getTimeZones(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/time-zones`;
      return this.http.get(url)
    }

    getCategories(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/store/categories`;
      return this.http.get(url)
    }

    getMasterTemplates(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/master-templates`;
      return this.http.get(url)
    }
    getMasterTemplateTheme(){
      const url = `${this.environment.apiUrl}/masterdata/api/master-data/master-template-themes/4`;
      return this.http.get(url)
    }
    updateStoreDetailsList(storeDetailsListObj:any) {
      const url = `${this.environment.apiUrl}/store/api/stores/3`;
      return this.http.put(url, storeDetailsListObj)
    }
}