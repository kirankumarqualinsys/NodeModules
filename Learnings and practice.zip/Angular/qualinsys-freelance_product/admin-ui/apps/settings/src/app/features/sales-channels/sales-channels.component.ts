
import { NzButtonSize } from 'ng-zorro-antd/button';

import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';

import { AddSaleschannels, ChangeSaleschannelsPage, DeleteSaleschannels, EditSaleschannels, GetSaleschannelsList, UpdateSaleschannelsStatus } from '../../state/sales-channels.action';

import { SalesChannelsService } from '../../service/sales-channels.service';
import { SaleschannelsStateSelectors } from '../../state/sales-channels.selectors';


@Component({
  selector: 'commerceq-admin-ui-sales-channels',
  templateUrl: './sales-channels.component.html',
  styleUrls: ['./sales-channels.component.less'],
})
export class SalesChannelsComponent {
  size: NzButtonSize = 'large';
  tabs = ['Active Sales Channels'];
  activetabIndex = 0;
  tabStatus: any = true;
  data:any



  saleschannel: any = [];
  salesChannelList: any = [];
  // showDeleteModal: boolean = false;
  selectedCategory: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100];
  mainTabs = ['Active Sales Channels'];
  mainActivetabIndex = 0;
  saleschannelsDummyList:any= [];
updatesales:any=[];
  @Select((state: any) => state.saleschannels.saleschannelsList)
  saleschannelsList$!: Observable<any>;
  @Select((state: any) => state.saleschannels.paginationSaleschannels.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.saleschannels.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.saleschannels.paginationSaleschannels.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.saleschannels.loading)
  loading$: Observable<boolean> | undefined;
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  // linkedproductFormGroup!: UntypedFormGroup;

  constructor(private store: Store,private slaesChannelSErvice:SalesChannelsService) {
  
}

async ngOnInit() {
  // sessionStorage.getItem('storeID');
  this.store.dispatch(new GetSaleschannelsList(''));
  this.saleschannelsList$.subscribe((data:any)=>{
    this.saleschannelsDummyList = [];
    this.saleschannelsDummyList = data;
    
  });
  console.log(this.saleschannelsDummyList,'this.saleschannelsDummyList');
  
}

  isVisible = false;
  showDeleteModal: boolean = false;
  salesChannelsData:any =[];
  showModal(): void {
    this.salesChannelsData =[];
    this.slaesChannelSErvice.getsales().subscribe((list:any)=>{
      console.log(list.data);
        list.data.forEach((element:any, ind:any) => {
          let i = this.saleschannelsDummyList.findIndex((l:any) => l.salesChannel.appId === element.appId );
          if(i == -1){
            console.log(list.data[ind]);
            
            this.salesChannelsData.push(list.data[ind]);
          }
        });
    })
    this.isVisible = true;

  }

  Cancel(): void {
    this.isVisible = false;
  }

  deleteSalesChannel(saleschannel: any){
    this.saleschannel = saleschannel;
    this.showDeleteModal=true;
  }


  deleteProduct(saleschannel: any) {
    this.saleschannel = saleschannel;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([new DeleteSaleschannels(this.saleschannel?.id)])
    setTimeout(() => {
      this.store.dispatch([new GetSaleschannelsList('')])
    }, 500);
    this.showDeleteModal = false;
  }

  AddSalesChannel(){
    this.store.dispatch([new AddSaleschannels({"salesChannels":this.updatesales} )])
    setTimeout(() => {
      this.store.dispatch([new GetSaleschannelsList('')])
    }, 500);
    this.Cancel();
  }

  updateSales(event:any, item:any){
    if(event == true) {
      this.updatesales.push(item.id) ;
    }
    else {
      let ind = this.updatesales.findIndex((id:any) => id == item.id)
     if(ind > -1){
      this.updatesales.splice(ind, 1);
     }
    }


  }


  onChangePage(page:any): void {
    this.store.dispatch([new ChangeSaleschannelsPage(page), new GetSaleschannelsList('')])
  }
  
}
