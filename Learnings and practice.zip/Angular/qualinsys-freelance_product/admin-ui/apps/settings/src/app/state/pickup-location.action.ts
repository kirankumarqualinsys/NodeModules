export class GetPickupLocationList {
    static readonly type = '[PickupLocation] Get PickupLocation';
    constructor(public status: any) { }
}

export class ChangePickupLocationPage {
    static readonly type = '[PickupLocation] Change PickupLocation Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdatePickupLocationStatus {
    static readonly type = '[PickupLocation] Update PickupLocation Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeletePickupLocation {
    static readonly type = '[PickupLocation] Delete PickupLocation';
    constructor(public readonly id: number) { }
}

export class AddPickupLocation {
    pipe(arg0: any) {
      throw new Error('Method not implemented.');
    }
    static readonly type = '[PickupLocation] Add PickupLocation';
    constructor(public readonly payload: any) { }
}
export class EditPickupLocation {
    static readonly type = '[PickupLocation] Edit PickupLocation';
    constructor(public readonly payload: any) { }
}