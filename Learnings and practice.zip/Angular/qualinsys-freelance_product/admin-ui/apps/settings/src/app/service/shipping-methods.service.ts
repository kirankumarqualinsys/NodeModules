import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable, Subject } from 'rxjs';

import { IPage } from '../state/shipping-methods.state';


@Injectable({
  providedIn: 'root'
})
export class ShippingMethodsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getShippingMethods(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/shipping-methods`;
    let obj={
      page:pagination.page - 1,
      size:pagination.size.toString(),
      pincode:""
    }
    
    return this.http.get(url)

  }
  updateShippingMethodsStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/store/api/shipping-methods/${id}/update-status/${status}`;
    return this.http.put(url, {})
  }
  deleteShippingMethods(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/store/api/shipping-methods/${id}`;
    return this.http.delete(url)
  }
  addShippingMethods(payload: any): Observable<any> {
    payload.code = payload.name;
    const url = `${this.environment.apiUrl}/store/api/shipping-methods`;
    return this.http.post(url, payload)
  }
 

  getShippingMethodsList() {
    const url = `${this.environment.apiUrl}/store/api/payment-methods?page=0&size=100`;
    return this.http.get(url, {});
  }

  private showModalSource = new Subject<string>();
  showModal$ = this.showModalSource.asObservable();

  opensmModal(action: string) {
    this.showModalSource.next(action);
  }

}
