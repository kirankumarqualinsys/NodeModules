import { Component, OnInit, TrackByFunction } from '@angular/core';
import {
  ChangeLocationsPage,
  DeleteLocationsStatus,
  GetLocationsList,
} from '../../state/locations.action';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { LocationsService } from '../../service/locations.service';
@Component({
  selector: 'commerceq-admin-ui-locations',
  templateUrl: './locations.component.html',
  styleUrls: ['./locations.component.less'],
})
export class LocationsComponent implements OnInit {
 
  
  tabs = ['Locations'];
  activetabIndex = 0;
  tabStatus: any = false;
  size: any = 'large';
  visible = false;
  showDeleteModal = false;
  selectedLocations: any = {};
  locationsList: any = [];

  //location loop interating
  location: any;

  @Select((state: any) => state.locations.locationsList)
 locationsList$!: Observable<any>;
  @Select((state: any) => state.locations.paginationLocations.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.locations.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.locations.paginationLocations.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.locations.loading)
  loading$: Observable<boolean> | undefined;


  trackByFn: TrackByFunction<any> = (index, item) => item.id;

  constructor(private store: Store, private router:Router, private loacationService:LocationsService) {}
  
  async ngOnInit() {
    //get the add location layout
    this.store.dispatch(new GetLocationsList(''));
    this.loacationService.locationData = null;
  }


  onChangePage(page: number): void {
    this.store.dispatch([
      new ChangeLocationsPage(page),
      new GetLocationsList(this.tabStatus),
    ]);
  }
  onSelectTab(event: number) {
    this.activetabIndex = event;
  }

  showModal(type: string, locationsData?: any): void {
    this.selectedLocations = locationsData;
  }

  addModal(): void {
    this.visible = true;
  }

  editLocation(location:any){
    this.loacationService.locationData = location;
    // this.router.navigateByUrl('/edit');
  }
  //delete modal functionality
  deleteLocation(location: any) {
    this.selectedLocations = location;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([
      new DeleteLocationsStatus(this.selectedLocations.id),
      new GetLocationsList(this.tabStatus),
    ]);

    this.showDeleteModal = false;
  }
}
