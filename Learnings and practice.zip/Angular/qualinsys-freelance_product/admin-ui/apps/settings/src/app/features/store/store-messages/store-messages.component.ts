import { Component } from '@angular/core';
@Component({
  selector: 'commerceq-admin-ui-store-messages',
  templateUrl: './store-messages.component.html',
  styleUrls: ['./store-messages.component.less'],
})
export class StoreMessagesComponent {}
