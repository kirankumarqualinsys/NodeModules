import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddPayments, ChangePaymentsPage, DeletePayments, EditPayments, GetPaymentsList, UpdatePaymentsStatus } from './payment.action';
import { PaymentService } from '../service/payment.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface PaymentsStateModel {
    [x: string]: any;
    paymentsList: [];
    paginationPayments: IPage;
    total: number;
    loading: boolean;
}
@State<PaymentsStateModel>({
    name: 'payments',
    defaults: {
        paymentsList: [],
        paginationPayments: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class PaymentsState implements NgxsOnInit {
    constructor(private paymentService: PaymentService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetPaymentsList)
    getPaymentsList({ getState, patchState }: StateContext<PaymentsStateModel>, action: GetPaymentsList) {
        const { paginationPayments } = getState();
        patchState({ loading: true })
        return this.paymentService.getPayments(action.status, paginationPayments).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const paymentsList = result;
                    const total = result.length;
                    patchState({
                        paymentsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangePaymentsPage)
    changePaymentsPage({ patchState, getState }: StateContext<PaymentsStateModel>, action: ChangePaymentsPage) {
        patchState({ paginationPayments: { ...getState().paginationPayments, page: action.paylaod } })
    }
    @Action(UpdatePaymentsStatus)
    updatePaymentsStatus({ patchState }: StateContext<PaymentsStateModel>, action: UpdatePaymentsStatus) {
        patchState({ loading: true })
        return this.paymentService.updatePaymentsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeletePayments)
    deletePayment({ patchState }: StateContext<PaymentsStateModel>, action: DeletePayments) {
        patchState({ loading: true })
        return this.paymentService.deletePayment(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddPayments)
    addPayment({ patchState }: StateContext<PaymentsStateModel>, action: AddPayments) {
        patchState({ loading: true })
        return this.paymentService.addPayment(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(EditPayments)
    editPayment({ patchState }: StateContext<PaymentsStateModel>, action: EditPayments) {
        patchState({ loading: true })
        return this.paymentService.editPayment(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
}