export class GetLocationsList {
  static readonly type = '[Locations] Get Location';
  constructor(public payload: any) {}
}

export class ChangeLocationsPage {
  static readonly type = '[Locations] Change Location Page';
  constructor(public readonly paylaod: number) {}
}

export class UpdateLocationsStatus {
  static readonly type = '[Locations] Update Location Status';
  constructor(public readonly id: number, public readonly status: boolean) {}
}

export class DeleteLocation {
  static readonly type = '[Locations] Delete Location';
  constructor(public readonly id: number) {}
}

export class DeleteLocationsStatus {
  static readonly type = '[Locations] Delete Locations Status';
  constructor(public readonly id: number) { }
}

export class AddLocation {
  static readonly type = '[Locations] Add Location';
  constructor(public readonly payload: any) {}
}
export class EditLocation {
  static readonly type = '[Locations] Edit Location';
  constructor(public readonly payload: any) {}
}
