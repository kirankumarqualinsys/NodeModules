module.exports = {
  name: 'settings',
  exposes: {
    "./Module": "apps/settings/src/app/app.module.ts",
  },
};
