import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { HomeService } from 'libs/shared/src/lib/services/home.service';
import { GetOrderStatusMonthlyFrequency, GetSalesSummary, GetSalesSummaryMonthlyFrequency, GetShipmentStatusMonthlyFrequency } from './home.action';
import { tap } from 'rxjs';

export interface HomeStateModel {
  salesSummary: any;
  salesSummaryMonthlyFrequency: any;
  orderStatusMonthlyFrequency: any;
  shipmentStatusMonthlyFrequency: any;
}
@State<HomeStateModel>({
  name: 'home',
  defaults: {
    salesSummary: undefined,
    salesSummaryMonthlyFrequency: undefined,
    orderStatusMonthlyFrequency: undefined,
    shipmentStatusMonthlyFrequency: undefined
  }
})
@Injectable()
export class HomeState implements NgxsOnInit {


  constructor(private homeService: HomeService, private readonly store: Store) { }
  async ngxsOnInit() { }

  @Action(GetSalesSummary)
  getSalesSummary({ patchState }: StateContext<HomeStateModel>, action: GetSalesSummary) {
    return this.homeService.getSalesSummary(action.storeId).pipe(
      tap((result: any) => {
        const salesSummary = result.data
        patchState({
          salesSummary
        });
      })
    );
  }

  @Action(GetSalesSummaryMonthlyFrequency)
  getSalesSummaryMonthlyFrequency({ patchState }: StateContext<HomeStateModel>, action: GetSalesSummaryMonthlyFrequency) {
    return this.homeService.getSalesSummaryMonthlyFrequency(action.payload).pipe(
      tap((result: any) => {
        const salesSummaryMonthlyFrequency = result.data
        patchState({
          salesSummaryMonthlyFrequency
        });
      })
    );
  }

  @Action(GetOrderStatusMonthlyFrequency)
  getOrderStatusMonthlyFrequency({ patchState }: StateContext<HomeStateModel>, action: GetOrderStatusMonthlyFrequency) {
    return this.homeService.getOrderStatusMonthlyFrequency(action.payload).pipe(
      tap((result: any) => {
        const orderStatusMonthlyFrequency = result.data
        patchState({
          orderStatusMonthlyFrequency
        });
      })
    );
  }
  @Action(GetShipmentStatusMonthlyFrequency)
  getShipmentStatusMonthlyFrequency({ patchState }: StateContext<HomeStateModel>, action: GetShipmentStatusMonthlyFrequency) {
    return this.homeService.getShipmentStatusMonthlyFrequency(action.payload).pipe(
      tap((result: any) => {
        const shipmentStatusMonthlyFrequency = result.data
        patchState({
          shipmentStatusMonthlyFrequency
        });
      })
    );
  }
}