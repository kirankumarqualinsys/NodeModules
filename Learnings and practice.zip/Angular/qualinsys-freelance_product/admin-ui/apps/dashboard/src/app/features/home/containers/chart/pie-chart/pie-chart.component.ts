import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  ChartType,
  GoogleChartComponent
} from 'angular-google-charts';

@Component({
  selector: 'commerceq-admin-ui-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.less'],
})
export class PieChartComponent implements OnInit {
  @Input() data: any;
  @ViewChild('chart', { static: true })
  public chart!: GoogleChartComponent;
  chartData: any[] = [];
  constructor() { }
  title = 'Last 30 Days Orders By Shipping Status';
  type = ChartType.PieChart;
  columns = ['Task', 'Hours per Day'];
  width = 653;
  height = 400;
  ngOnInit(): void {
    this.chartData.push(['Delivered', this.data['delivered']]);
    this.chartData.push(['Pending', this.data['pending']]);
    this.chartData.push(['Shipped', this.data['shipped']]);
    this.chartData.push(['Unshipped', this.data['unshipped']]);
  }
}
