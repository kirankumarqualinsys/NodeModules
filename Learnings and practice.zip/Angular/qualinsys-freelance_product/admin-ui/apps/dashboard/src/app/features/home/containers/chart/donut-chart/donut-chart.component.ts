import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  ChartType,
  GoogleChartComponent
} from 'angular-google-charts';

@Component({
  selector: 'commerceq-admin-ui-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.less'],
})
export class DonutChartComponent implements OnInit {
  @Input() data: any;
  @ViewChild('chart', { static: true })
  public chart!: GoogleChartComponent;
  chartData: any[] = [];
  constructor() { }
  title = 'Last 30 Days Orders By Order Status';
  type = ChartType.PieChart;
  columns = ['Task', 'Hours per Day'];

  options = {
    pieHole: 0.4
  };
  width = 653;
  height = 400;
  ngOnInit(): void {
    this.chartData.push(['Processing', this.data['processing']]);
    this.chartData.push(['Accepted', this.data['accepted']]);
    this.chartData.push(['Confirmed', this.data['confirmed']]);
    this.chartData.push(['Declined', this.data['declined']]);
    this.chartData.push(['Completed', this.data['completed']]);
    this.chartData.push(['Closed', this.data['closed']]);
    this.chartData.push(['Ordered', this.data['ordered']]);
    this.chartData.push(['Pending', this.data['pending']]);
    this.chartData.push(['Cancelled', this.data['cancelled']]);
  }
}
