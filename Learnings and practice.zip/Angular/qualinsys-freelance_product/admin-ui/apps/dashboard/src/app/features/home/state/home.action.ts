

export class GetSalesSummary {
  static readonly type = '[Home] Get Sales Summary';
  constructor(public storeId: string) { }
}

export class GetSalesSummaryMonthlyFrequency {
  static readonly type = '[Home] Get Sales Summary Monthly Frequency';
  constructor(public payload: any) { }
}

export class GetOrderStatusMonthlyFrequency {
  static readonly type = '[Home] Get Order Status Monthly Frequency';
  constructor(public payload: any) { }
}

export class GetShipmentStatusMonthlyFrequency {
  static readonly type = '[Home] Get Shipment Status Monthly Frequency';
  constructor(public payload: any) { }
}