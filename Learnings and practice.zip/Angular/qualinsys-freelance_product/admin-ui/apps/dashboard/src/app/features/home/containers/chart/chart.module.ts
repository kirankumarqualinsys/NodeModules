import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColumnChartComponent } from './column-chart/column-chart.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { DonutChartComponent } from './donut-chart/donut-chart.component';
import { GoogleChartsModule } from 'angular-google-charts';

@NgModule({
  declarations: [ColumnChartComponent, PieChartComponent, DonutChartComponent],
  imports: [CommonModule, GoogleChartsModule],
  exports:[ColumnChartComponent, PieChartComponent, DonutChartComponent]
})
export class ChartModule {}
