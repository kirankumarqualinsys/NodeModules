import { Selector } from '@ngxs/store';
import {
  HomeStateModel,
  HomeState,
} from './home.state';

export class HomeStateSelectors {
  @Selector([HomeState])
  static salesSummary(state: HomeStateModel) {
    return state.salesSummary;
  }
  @Selector([HomeState])
  static salesSummaryMonthlyFrequency(state: HomeStateModel) {
    return state.salesSummaryMonthlyFrequency;
  }
  @Selector([HomeState])
  static orderStatusMonthlyFrequency(state: HomeStateModel) {
    return state.orderStatusMonthlyFrequency;
  }
  @Selector([HomeState])
  static shipmentStatusMonthlyFrequency(state: HomeStateModel) {
    return state.shipmentStatusMonthlyFrequency;
  }
}