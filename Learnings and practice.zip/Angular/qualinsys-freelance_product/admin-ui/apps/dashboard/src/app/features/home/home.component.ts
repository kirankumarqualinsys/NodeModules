import { Component, OnInit } from '@angular/core';
import { Select, Store } from '@ngxs/store';
import { GetOrderStatusMonthlyFrequency, GetSalesSummary, GetSalesSummaryMonthlyFrequency, GetShipmentStatusMonthlyFrequency } from './state/home.action';
import { HomeStateSelectors } from './state/home.selectors';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.less'],
})
export class HomeComponent implements OnInit {
  @Select(HomeStateSelectors.salesSummary)
  salesSummary$: Observable<any> | undefined;
  @Select(HomeStateSelectors.salesSummaryMonthlyFrequency)
  salesSummaryMonthlyFrequency$: Observable<any> | undefined;
  @Select(HomeStateSelectors.orderStatusMonthlyFrequency)
  orderStatusMonthlyFrequency$: Observable<any> | undefined;
  @Select(HomeStateSelectors.shipmentStatusMonthlyFrequency)
  shipmentStatusMonthlyFrequency$: Observable<any> | undefined;
  constructor(private readonly store: Store) { }

  ngOnInit(): void {
    this.store.dispatch([
      new GetSalesSummary('97932177'),
      new GetSalesSummaryMonthlyFrequency(this.prepareRequestPayload()),
      new GetOrderStatusMonthlyFrequency(this.prepareRequestPayload()),
      new GetShipmentStatusMonthlyFrequency(this.prepareRequestPayload())
    ])
  }

  prepareRequestPayload() {
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30)
    const body = {
      "storeId": "97932177",
      "startDate": startDate.toISOString(),
      "endDate": new Date().toISOString()
    }
    return body;
  }
}
