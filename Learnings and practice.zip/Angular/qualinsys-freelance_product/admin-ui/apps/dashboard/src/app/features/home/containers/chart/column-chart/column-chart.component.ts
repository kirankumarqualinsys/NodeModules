import { Component, Input, OnInit, ViewChild } from '@angular/core';
import {
  ChartType,
  GoogleChartComponent
} from 'angular-google-charts';

@Component({
  selector: 'commerceq-admin-ui-column-chart',
  templateUrl: './column-chart.component.html',
  styleUrls: ['./column-chart.component.less'],
})
export class ColumnChartComponent implements OnInit {
  @Input() data: any;
  @ViewChild('chart', { static: true })
  public chart!: GoogleChartComponent;
  chartData: any[] = [];
  constructor() { }
  title = '30 Days Total Sales';
  type = ChartType.ColumnChart;
  columns = ['Sales', 'Total Sales'];

  dynamicResize = true;

  options = {
    colors: ['#2caffe'],
    fontSize: 10,
    dynamicResize: true,
    annotations: {
      alwaysOutside: true,
      textStyle: {
        fontSize: 12,
        auraColor: 'none',
        color: '#555'
      },
      boxStyle: {
        stroke: '#ccc',
        strokeWidth: 1,
        gradient: {
          color1: '#2caffe',
          x1: '0%',
          y1: '0%',
          x2: '100%',
          y2: '100%'
        }
      }
    },
  }
  width = document.documentElement.clientWidth - 40;
  height = 370;

  ngOnInit(): void {

    if (this.data && this.data.length > 0) {
      this.data.forEach((it: any) => {
        const arr = [it.index, it.totalSales]
        this.chartData.push(arr);
      })
    }
  }

  resetWindowSize(event:any){
    //Reset the width and height based on current window size
    this.width = document.documentElement.clientWidth - 40;
    //this.chart.dynamicResize = true;
  }
}
