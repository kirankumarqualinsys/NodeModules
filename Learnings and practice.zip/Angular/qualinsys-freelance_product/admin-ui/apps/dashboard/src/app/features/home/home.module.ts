import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { RouterModule } from '@angular/router';
import { NzGridModule } from 'ng-zorro-antd/grid';

import { NzCardModule } from 'ng-zorro-antd/card';
import { ChartModule } from './containers/chart/chart.module';
import { NgxsModule } from '@ngxs/store';
import { HomeState } from './state/home.state';

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    NgxsModule.forFeature([
      HomeState
    ]),
    RouterModule.forChild([{ path: 'home', component: HomeComponent }]),
    NzCardModule,
    NzGridModule,
    ChartModule
  ],
  exports: [RouterModule]
})
export class HomeModule { }
