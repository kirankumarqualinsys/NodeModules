module.exports = {
  name: "dashboard",
  exposes: {
    "./Module": "apps/dashboard/src/app/app.module.ts",
  },
};
