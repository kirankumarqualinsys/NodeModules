module.exports = {
  name: 'catalog',
  exposes: {
    './Module': 'apps/catalog/src/app/app.module.ts',
  },
};
