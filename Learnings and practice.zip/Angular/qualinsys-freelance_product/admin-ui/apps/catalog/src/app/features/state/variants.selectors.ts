import { Selector } from '@ngxs/store';
import {
    VariantsStateModel,
    VariantsState,
} from '././variants.state';

export class VariantsStateSelectors {
    @Selector([VariantsState])
    static variantsList(state: VariantsStateModel) {
        return state['variantsList'];
      }
    @Selector([VariantsState])
    static variantsOptionsList(state: VariantsStateModel) {
        return state['variantsOptionsList'];
      }
      
    static pageSize(state: VariantsStateModel) {
        return state.paginationVariants.size;
    }
    static total(state: VariantsStateModel) {
        return state.total;
    }
    static pageIndex(state: VariantsStateModel) {
        return state.paginationVariants.page;
    }
    static loading(state: VariantsStateModel) {
        return state.loading;
    }
}