export class GetBrandsList {
    static readonly type = '[Brands] Get Brands';
    constructor(public status: any) { }
}

export class GetBrandsWithFilters {
    static readonly type = '[Brands] Get Brands With Filters';
    constructor(public readonly paylaod: any, public readonly status: string) { }
  }

export class ChangeBrandsPage {
    static readonly type = '[Brands] Change Brands Page';
    constructor(public readonly paylaod: number) { }
}



export class UpdateBrandsStatus {
    static readonly type = '[Brands] Update Brands Status';
    constructor(public readonly id: number, public readonly data: any) { }
}
export class AddBrandsStatus {
    static readonly type = '[Brands] Add Brands Status';
    constructor(public readonly data: any) { }
}
export class EditBrandsStatus {
    static readonly type = '[Brands] Edit Brands Status';
    constructor(public readonly id: number, public data: any) { }
}
export class DeleteBrandsStatus {
    static readonly type = '[Brands] Delete Brands Status';
    constructor(public readonly id: number) { }
}