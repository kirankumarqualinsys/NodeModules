import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { NzButtonSize } from 'ng-zorro-antd/button';

import { AddCollection, ChangeCollectionsPage, DeleteCollection, EditCollection, GetCollectionsList, UpdateCollectionsStatus } from '../state/collections.action';
import { CollectionsStateSelectors } from '../state/collections.selectors';
import { CollectionsService } from '../../services/collections.service';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}


@Component({
  selector: 'commerceq-admin-ui-collections',
  templateUrl: './collections.component.html',
  styleUrls: ['./collections.component.less'],
  
})
export class CollectionsComponent {
  
  tabs = ['All', 'Enabled', 'Disabled'];
activetabIndex = 0;
tabStatus: any = true;
date = null;
validateForm!: UntypedFormGroup;
size: NzButtonSize = 'large';


options =  [
  {
    label: "Select Option",
    value: "",
  },
  {
    label: "Manually",
    value: "MANUAL",
  },
  {
    label: "Alphabetically ASC(A-Z)",
    value: "RELATED",
  },
  {
    label: "Alphabetically DESC(Z-A)",
    value: "CROSS_SALE",
  },
  {
    label: "Price - High to Low",
    value: "UP_SALE",
  },


  {
    label: "Price - Low to High",
    value: "RELATED",
  },
  {
    label: "Date - oldest to newest",
    value: "CROSS_SALE",
  },
  {
    label: "Date - newest to oldest",
    value: "UP_SALE",
  },
  
];
collectionsList: any = [];
showDeleteModal: boolean = false;
selectedCategory: any = {};
enabledValues = [
  { key: true, name: 'Active' },
  { key: false, name: 'Inactive' }
]
public paginationLimit = [10, 20, 50, 100]

@Select((state: any) => state.collections.collectionsList)
collectionsList$!: Observable<any>;
@Select((state: any) => state.collections.paginationCollections.size)
pageSize$: Observable<any> | undefined;
@Select((state: any) => state.collections.total)
total$: Observable<any> | undefined;
@Select((state: any) => state.collections.paginationCollections.page)
pageIndex$: Observable<any> | undefined;
@Select((state: any) => state.collections.loading)
loading$: Observable<boolean> | undefined;

trackByFn: TrackByFunction<any> = (index, item) => item.id;
categoryFormGroup!: UntypedFormGroup;
constructor(private store: Store, private fb: UntypedFormBuilder,
  private collectionsService: CollectionsService) {
  this.categoryFormGroup = this.fb.group({
    name: [null, [Validators.required]],
    active: [null, [Validators.required]],
    sortOrder: [null, [Validators.required]],  
    code : [null], 
  })
}
async ngOnInit() {
  this.store.dispatch(new GetCollectionsList(true))

}



submitForm(): void {
  if (this.validateForm.valid) {
  } else {
    Object.values(this.validateForm.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }
}
onChange(result: Date): void {
  // console.log('onChange: ', result);
}


onChangePage(page: number): void {
  this.store.dispatch([new ChangeCollectionsPage(page), new GetCollectionsList(this.tabStatus)])
}
changeStatus(event: boolean, id: number) {
  this.store.dispatch([new UpdateCollectionsStatus(id, event)])
}


updateCategory(value: any, data: any, type: string) {
  let updatedObj = { ...data };
  const date = new Date();
  const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = String(date.getFullYear());
  const lastUpdated = `${day}-${month}-${year}`;
  if (type == 'featured') {
    updatedObj.featured = value;
  } else if (type == 'showInMenu') {
    updatedObj.showInMenu = value;
  } else if (type == 'enabled') {
    updatedObj.enabled = value;
  }

  updatedObj.lastUpdatedOn = lastUpdatedOn;
  updatedObj.lastUpdated = lastUpdated;
  this.store.dispatch([new UpdateCollectionsStatus(updatedObj.id, updatedObj), new GetCollectionsList(this.tabStatus)])
}

editSEO($event: any) {
  // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
}



//modal functionality
isVisible = false;
title: string = 'Add New Collection';
showModal(type: string, categoryData?: any): void {
  this.selectedCategory = categoryData;
  if (type == 'Add') {
    this.title = 'Add New Collection';
    this.categoryFormGroup.reset();
  } else {
    this.title = 'Edit New Collection';
    this.categoryFormGroup.controls['name'].setValue(categoryData.name);
    this.categoryFormGroup.controls['active'].setValue(categoryData.active);
    this.categoryFormGroup.controls['sortOrder'].setValue(categoryData.sortOrder); 
    
  }
  this.isVisible = true;
}

Submit(): void {
  if (this.categoryFormGroup.valid) {
    if (this.title == 'Add New Collection') {
      this.store.dispatch([new AddCollection(this.categoryFormGroup.value), new GetCollectionsList(this.tabStatus)])
      this.isVisible = false;
    } else {
      let categoryObj = { ...this.selectedCategory };     
      categoryObj.name = this.categoryFormGroup.value.name;
      categoryObj.sortOrder = this.categoryFormGroup.value.sortOrder;
      categoryObj.active = this.categoryFormGroup.value.active;

      this.store.dispatch([new EditCollection(categoryObj.id), new GetCollectionsList(this.tabStatus)])
      this.isVisible = false;
    }
    this.Cancel();
  } else {
    Object.values(this.categoryFormGroup.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }


}

Cancel(): void {
  this.isVisible = false;
}

//delete modal functionality
deleteCollection(category: any) {
  this.selectedCategory = category;
  this.showDeleteModal = true;
}
proceedtoDelete() {
  this.store.dispatch([new DeleteCollection(this.selectedCategory.id), new GetCollectionsList(this.tabStatus)])

  this.showDeleteModal = false;
}

updateCollection(value: any, data: any) {
  let updatedObj = { ...data };
  const date = new Date();
  const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = String(date.getFullYear());
  const lastUpdated = `${day}-${month}-${year}`;
  

  updatedObj.lastUpdatedOn = lastUpdatedOn;
  updatedObj.lastUpdated = lastUpdated;
  this.store.dispatch([new UpdateCollectionsStatus(updatedObj.id, updatedObj), new GetCollectionsList(this.tabStatus)])
}

}
