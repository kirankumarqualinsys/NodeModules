import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LinkedProductsComponent } from './linked-products.component';

describe('LinkedProductsComponent', () => {
  let component: LinkedProductsComponent;
  let fixture: ComponentFixture<LinkedProductsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LinkedProductsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LinkedProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
