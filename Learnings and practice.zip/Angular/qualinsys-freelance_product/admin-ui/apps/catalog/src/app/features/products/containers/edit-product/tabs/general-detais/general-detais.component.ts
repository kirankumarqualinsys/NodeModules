import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { NzButtonSize } from 'ng-zorro-antd/button/button.component';
import {  UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { CategoriesService } from 'apps/catalog/src/app/services/categories.service';
import { Select, Store } from '@ngxs/store';
import { CollectionsService } from 'apps/catalog/src/app/services/collections.service';
import { ProductsService } from 'apps/catalog/src/app/services/products.service';
import { Router } from '@angular/router';
import { NzSelectSizeType } from 'ng-zorro-antd/select';
import { AddProductsStatus , GetProductsListById} from 'apps/catalog/src/app/features/state/products.action';
import { BrandsService } from 'apps/catalog/src/app/services/brands.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-general-detais',
  templateUrl: './general-detais.component.html',
  styleUrls: ['./general-detais.component.less'],
})
export class GeneralDetaisComponent {
  size: NzButtonSize = 'large';
  productForm!: UntypedFormGroup;
  @Input() id: any;
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ];
  collectionList: any = [];
  salesChannelsList: any = [];
  brandsList:any =[];
  selectedCollectionValues:any =[]
  sizeSelect: NzSelectSizeType = 'default';
  @Select((state: any) => state.products.productsListById)
  productsListById$!: Observable<any>;
  constructor(private fb: UntypedFormBuilder, private categoriesService: CategoriesService,
    private store: Store, private collectionService: CollectionsService, private productService: ProductsService,
    private router: Router, private brandService:BrandsService) {
    
  }
  productList:any;
  ngOnInit(): void {
    console.log(this.id);
    
   
    //get category list
    this.categoriesService.getCategoriesList().subscribe((res: any) => {
      this.parentList = [];
      if (res && res.length > 0) {
        this.parentList = res;
      }
    });
    //get brands list
    this.brandService.getBrandsWithSize({page:0, size:100}).subscribe((res: any) => {
      this.collectionList = [];
      this.collectionService.getCollectionsList().subscribe((colres: any) => {
      if (colres && colres.length > 0) {
        this.collectionList = colres;
      }
    });
    //get collectionList list
      this.brandsList = [];
      if (res && res.content.length > 0) {
        this.brandsList = res;
      }
    });
    //get sales channels list
    this.productService.getsalesChannelsList().subscribe((res: any) => {
      this.salesChannelsList = [];
      if (res.data && res.data.length > 0) {
        this.salesChannelsList = res.data;
      }
    });

    this.productForm = this.fb.group({
      title: [null, [Validators.required]],
      categoryId: [null, [Validators.required]],
      brand: [null],
      description: [''],
      model: [''],
      paidBy: [''],
      productId: [''],
      quantity: [0, [Validators.required]],
      shipsIn: [''],
      sku: [null, [Validators.required]],
      tags: [null],
      collections: [[]],
      options: [null, [Validators.required]],
      variant: [null, [Validators.required]],
      uom: [null, [Validators.required]],
      barcode: [null],
      hsnCode: [null],
      trackInventory: [false],
      allowOutOfStockSelling: [false],
      supplyPrice: [null, [Validators.required]],
      markupPercentage: [null, [Validators.required]],
      retailPrice: [null, [Validators.required]],
      comparePrice: [null, [Validators.required]],
      enabled: [false],


    }, { validators: this.compareValues('comparePrice', 'retailPrice') });
    this.productForm.valueChanges.subscribe((data: any) => {
      if (data.supplyPrice && data.markupPercentage) {
        let value = (parseInt(data.supplyPrice) * (parseInt(data.markupPercentage) / 100)) + parseInt(data.supplyPrice);
        this.productForm.controls['retailPrice'].setValue(value, { emitEvent: false });
        // this.productForm.controls['retailPrice'].updateValueAndValidity({emitEvent : false});
      } 

      
      // else {
      //   this.productForm.controls['retailPrice'].setValue('', { emitEvent: false });
      //   // this.productForm.controls['retailPrice'].updateValueAndValidity({emitEvent : false});
      // }
    });

    this.store.dispatch([new GetProductsListById(this.id)]);
    this.productsListById$.subscribe((data:any)=> {
      this.productList = data?.product;
      console.log(this.productList);
      if(this.productList != undefined){
        console.log('i am in');
        
        this.productForm.controls['title'].setValue(this.productList.title);
        this.productForm.controls['categoryId'].setValue(this.productList.categoryId);
        
        this.productForm.controls['description'].setValue(this.productList.description);
        this.productForm.controls['tags'].setValue(this.productList.tags);
        this.productForm.controls['collections'].setValue(this.productList.collections);
        this.selectedCollectionValues =this.productList.collections;
        this.productForm.controls['hsnCode'].setValue(this.productList.hsnCode);
        this.productForm.controls['enabled'].setValue(this.productList.enabled);
        this.productForm.controls['brand'].setValue([this.productList.brand]);
        this.productForm.controls['model'].setValue(this.productList.model);
        // this.productForm.
        this.channels= this.productList.salesChannels
        this.tags = this.productList.tags;

      }
      
    })
  }
  compareValues(controlName: string, compareToControlName: string) {
    return (formGroup: UntypedFormGroup) => {
      const control = formGroup.controls[controlName];
      const compareToControl = formGroup.controls[compareToControlName];
  
      if (control.value < compareToControl.value) {
        compareToControl.setErrors({ compareValues: true });
      } else {
        compareToControl.setErrors(null);
      }
    };
  }
  channels:any =[];
  channelsList(event:any,id:number){
   console.log(event.target.checked);
   if(event.target.checked){
     this.channels.push(id);
   } else{
    this.channels = this.channels.filter((tag: any) => tag !== id);
   }
   console.log(this.channels);
   
  }
  submitForm() {
     console.log(this.productForm.value);
     console.log(this.selectedCollectionValues);

     let productObj={
      "brandId": "",
      "categoryId": this.productForm.value.categoryId?.id,
      "description": "",
      "discountedPrice": 0,
      "model": this.productForm.value.model,
      "paidBy": "",
      "productId": this.productForm.value.product,
      "quantity": this.productForm.value.quantity,
      "shipsIn": "",
      "sku": this.productForm.value.sku,
      "title": this.productForm.value.title,
      "variantOptions": [
          {
              "variant": this.productForm.value.variant,
              "options": [
                this.productForm.value.options
              ]
          }
      ],
      "variants": [
          {
              "barcode": this.productForm.value.barcode,
              "code": "",
              "name": this.productForm.value.variant,
              "price": 0,
              "sku": this.productForm.value.sku,
              "variantValues": {
                  [this.productForm.value.variant]: this.productForm.value.options
              },
              "supplyPrice": this.productForm.value.supplyPrice,
              "markupPercentage": this.productForm.value.markupPercentage,
              "retailPrice": this.productForm.value.retailPrice,
              "comparePrice": this.productForm.value.comparePrice,
              "quantity": this.productForm.value.quantity,
              "uom": this.productForm.value.uom,
          }
      ],
      "weight": "",
      "enabled": this.productForm.value.enabled,
      "tags": this.tags,
      "collections": this.productForm.value.collections,
      "hsnCode": this.productForm.value.hsnCode,
      "trackInventory": this.productForm.value.trackInventory,
      "allowOutOfStockSelling": this.productForm.value.allowOutOfStockSelling,
      "supplyPrice": this.productForm.value.supplyPrice,
      "retailPrice": this.productForm.value.retailPrice,
      "markupPercentage": this.productForm.value.markupPercentage,
      "comparePrice": this.productForm.value.comparePrice,
      "salesChannels": this.channels
  }

  console.log(productObj);
  if (this.productForm.valid) {
    console.log('valid');
    // this.store.dispatch([new AddProductsStatus(productObj)]);
   
  } else {
    Object.values(this.productForm.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }
  
  }

 
  parentList: any = []
  getParentList(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    if (value && value.length > 2) {
      this.categoriesService.getParent(value).subscribe((res: any) => {
        this.parentList = [];
        if (res && res.length > 0) {
          this.parentList = res;
        }
      })
    }
  }
 

  //add tags func
  tags: any = [];
  inputVisible = false;
  inputValue = '';
  @ViewChild('inputElement', { static: false }) inputElement?: ElementRef;

  handleClose(removedTag: {}): void {
    this.tags = this.tags.filter((tag: any) => tag !== removedTag);
  }

  sliceTagName(tag: string): string {
    const isLongTag = tag.length > 20;
    return isLongTag ? `${tag.slice(0, 20)}...` : tag;
  }

  showInput(): void {
    this.inputVisible = true;
    setTimeout(() => {
      this.inputElement?.nativeElement.focus();
    }, 10);
  }

  handleInputConfirm(): void {
    if (this.inputValue && this.tags.indexOf(this.inputValue) === -1) {
      this.tags = [...this.tags, this.inputValue];
    }
    this.inputValue = '';
    this.inputVisible = false;
  }

  //navig5ate to list product page
  listProduct() {
    this.router.navigateByUrl('/list');
  }
}
