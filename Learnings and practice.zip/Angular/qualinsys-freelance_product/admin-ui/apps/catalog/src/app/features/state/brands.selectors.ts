import { Selector } from '@ngxs/store';
import {
    BrandsStateModel,
    BrandsState,
} from './brands.state';


export class BrandsStateSelectors {
    @Selector([BrandsState])
    static categoriesList(state: BrandsStateModel) {
        return state['brandsList'];
      }
    static pageSize(state: BrandsStateModel) {
        return state.paginationBrands.size;
    }
    static total(state: BrandsStateModel) {
        return state.total;
    }
    static pageIndex(state: BrandsStateModel) {
        return state.paginationBrands.page;
    }
    static loading(state: BrandsStateModel) {
        return state.loading;
    }
}