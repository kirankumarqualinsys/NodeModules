import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class VariantsService {


  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  // getVariants(payload: any, pagination: IPage): Observable<any> {
  //   let id ='145'
  //   const url = `${this.environment.apiUrl}/catalog/api/products/${id}/variants`;
  //   const data = {
  //     page: pagination.page - 1,
  //     size: pagination.size
  //   }
  //   return this.http.post(url, data)

  // }

//Variant api's


  getVariants(id: number) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}/variants`;  
    return this.http.get(url);
  }

  getVariantsWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/variants/v2/search`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  updateVariantsStatus(id: number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/variants/${id}`;
    return this.http.put(url, data)
  }
  addVariantsStatus( data:any,  vid:number) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${vid}/variants`;
    return this.http.post(url, data);
  }
  editVariantsStatus(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}/variants/${data.id}`;
    return this.http.get(url, data);
  }
  deleteVariantsStatus( id:number) {
    const url = `${this.environment.apiUrl}/catalog/api/variants/${id}`;
   
    return this.http.delete(url);
  }

  getsalesChannelsList() {
    const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels`;
   
    return this.http.get(url);
  }

//Variant options api's

  addVariantOptions( data:any, vid:number) {
    // const optionData = {
    //   id:vid,
    //   option:data.option,
    //   variantId:vid
    // }
     const optionData = {
      options:data,
      productId:vid
    }
    

    const url = `${this.environment.apiUrl}/catalog/api/products/${vid}/variants/options`;
//     const url = `${this.environment.apiUrl}/catalog/api/products/${vid}/variants/options/${vid}`;

    // http://216.250.122.50:8765/catalog/api/products/153/variants/options
   
    return this.http.post(url, optionData);
  }

  getVariantOptions(vid:number) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${vid}/variants/options`;   
    return this.http.get(url);
  }


  deleteVariantOptions(productid:number,vid:number) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${productid}/variants/options/${vid}`;
       return this.http.delete(url);
  }
  

}

