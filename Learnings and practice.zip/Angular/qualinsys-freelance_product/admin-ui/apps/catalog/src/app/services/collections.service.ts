import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class CollectionsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getCollections(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections`;
    let params = new HttpParams();
    if (pagination) {
      params = params.append('page', pagination.page - 1);
    }
    if (pagination?.size) {
      params = params.append('size', pagination.size.toString());
    }
    if (status !== "skip") {
      params = params.append('active', status);
    }
    return this.http.get(url, { params })

  }
  updateCollectionsStatus(id: number, status: boolean) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections${id}/${status}`;
    return this.http.patch(url, {})
  }
  deleteCollection(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections/${id}`;
    return this.http.delete(url)
  }
  addCollection(payload: any): Observable<any> {
    payload.code = payload.name;
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections`;
    return this.http.post(url, payload)
  }
  editCollection(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections/${payload.id}`;
    return this.http.put(url, payload)
  }

  getCollectionsList() {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/collections?page=0&size=100`;
    return this.http.get(url, {});
  }
}
