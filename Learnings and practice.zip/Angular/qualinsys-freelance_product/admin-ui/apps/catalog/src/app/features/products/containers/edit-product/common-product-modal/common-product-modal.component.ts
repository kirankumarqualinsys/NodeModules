import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable, Subject, takeUntil } from 'rxjs';
// import { CategoriesStateSelectors } from '../../../state/categories.selectors';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { ProductsService } from 'apps/catalog/src/app/services/products.service';
import { LinkedProductsService } from 'apps/catalog/src/app/services/linked-products.service';
import { ChangeProductsPage, GetProductsList, GetProductsWithFilters } from '../../../../state/products.action';
import { NzModalService } from 'ng-zorro-antd/modal';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}

@Component({
  selector: 'commerceq-admin-ui-common-product-modal',
  templateUrl: './common-product-modal.component.html',
  styleUrls: ['./common-product-modal.component.less'],
})
export class CommonProductModalComponent {
  @Input() modalData: any;
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'large';
  optionsList: any = [{
    label: "Select Option",
    value: "",
  }]
  productsFilterFields = {
    title: {
      type: "text",
      value: "",
      label: "Title",
      span: "6"
    },
    sku: {
      type: "text",
      value: "",
      label: "SKU",
      span: "6"
    },
    categoryId: {
      type: "select",
      value: "",
      label: "Product Category",
      span: "6",
      options: this.optionsList
    },
    enabled: {
      type: "select",
      value: "",
      label: "Status",
      span: "6",
      options: [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Enabled",
          value: "true",
        },
        {
          label: "Disabled",
          value: "false",
        }
      ],
    },
  };
  productsList: any = [];
  showDeleteModal: boolean = false;
  selectedProduct: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100]

  @Select((state: any) => state.products.productsList)
  productsList$!: Observable<any>;
  @Select((state: any) => state.products.paginationProducts.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.products.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.products.paginationProducts.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.products.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  productsFormGroup!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder,
    private productsService: ProductsService, private linkedproductService: LinkedProductsService,
    private readonly modalService: NzModalService) {
    this.productsFormGroup = this.fb.group({
      name: [null, [Validators.required]],
      parent: [null],
      featured: [false],
      showInMenu: [false],
      enabled: [true],
    })
  }
  private unsubscribe$ = new Subject<void>();
  dupProductsList: any = [];
  async ngOnInit() {
    this.getProductCategoryList();
    this.store.dispatch(new GetProductsList(''));
    this.loading$?.pipe(
      takeUntil(this.unsubscribe$)
    ).subscribe(loading => {
      if (loading) {
        // Show loading indicator or perform necessary actions while loading
        console.log('Loading...');
      } else {
        this.productsList$.subscribe((data: any) => {
          this.dupProductsList = data;
          this.productsList = this.dupProductsList.map((item:any) =>
            Object.assign({}, item, { selected: false })
          )
          // this.productsList.forEach((ele: any) => {
          //   Object.assign({}, ele, { selected: false })
          // });
        })
      }
    });

  }

  getProductCategoryList(): void {
    console.log('hiojjoijijio');
    this.linkedproductService.getLinkedProductCategoryList('true').subscribe((res: any) => {
      let ProductCategoryList = [];
      if (res && res.length > 0) {
        ProductCategoryList = res;
        ProductCategoryList.forEach((e: any) => {
          let obj = {
            label: e.displayName,
            value: e.id.toString()
          };
          this.optionsList.push(obj);
          console.log(this.optionsList);

        });
      }
    })

  }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeProductsPage(page), new GetProductsList('')])
  }

  onChange(result: Date): void {
    // console.log('onChange: ', result);
  }


  filtersFormSubmit(event: any) {
    for (const key in event) {
      if (event[key] == null || event[key] == '') {
        delete event[key];
      }
    }
    if (event.categoryId) {
      event.categoryIds = [event.categoryId]
    } else {
      event.categoryIds = []
    }
    this.store.dispatch(new GetProductsWithFilters(event, ''))
  }

  dataList: any[] = []; // Your list of items

  selectAll = false;
  selectedItems: any[] = [];
  toggleSelectAll() {
    console.log(this.productsList, 'testst');

    for (const product of this.productsList) {
      product.selected = this.selectAll;
      if (this.selectAll) {
        this.selectedItems.push(product.id);
      }
    }
  }

  toggleItemSelection(product: any) {
    console.log(product);
      // product.selected = !product.selected;
      console.log(product.selected);
      if (product.selected) {
        this.selectedItems.push(product.id);
      } else {
        const index = this.selectedItems.findIndex(item => item === product.id);
        if (index !== -1) {
          this.selectedItems.splice(index, 1);
        }
      }
      console.log(this.selectedItems);
      
  }
  addLinkedProducts() {
    let obj = {
      "linkedProductIds": this.selectedItems,
      "productId": this.modalData.id,
      "type": this.modalData.type
    }
    this.linkedproductService.addLinkedProducts(this.modalData.id, obj).subscribe((data: any) => {
      console.log(data);
      if (data != null && data?.status == 400) {

      } else {
        this.closeModal();
      }

    })
  }
  closeModal() {
    this.modalService.closeAll();
  }

}
