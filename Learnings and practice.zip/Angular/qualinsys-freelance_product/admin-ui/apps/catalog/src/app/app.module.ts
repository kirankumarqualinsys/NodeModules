import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { AppComponent } from "./app.component";
import { appRoutes } from "./app.routes";
import { NgxsModule } from "@ngxs/store";
import { CategoriesState } from "./features/state/categories.state";
import { LinkedProductsState } from "./features/state/linkedproducts.state";
import { ProductsState } from "./features/state/products.state";
import { BrandsState } from "./features/state/brands.state";
import { CollectionsState } from "./features/state/collections.state";
import { VariantsState } from "./features/state/variants.state";

@NgModule({
  declarations: [AppComponent],
  imports: [
    RouterModule.forChild(appRoutes),
    NgxsModule.forFeature([CategoriesState , LinkedProductsState,ProductsState , BrandsState , CollectionsState, VariantsState ]),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
