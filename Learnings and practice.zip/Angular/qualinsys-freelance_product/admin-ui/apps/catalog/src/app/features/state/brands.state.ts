import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddBrandsStatus, ChangeBrandsPage, DeleteBrandsStatus, EditBrandsStatus, GetBrandsList, GetBrandsWithFilters, UpdateBrandsStatus } from './brands.action';
import { BrandsService } from '../../services/brands.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface BrandsStateModel {
    [x: string]: any;
    brandsList: [];
    paginationBrands: IPage;
    total: number;
    loading: boolean;
}
@State<BrandsStateModel>({
    name: 'brands',
    defaults: {
        brandsList: [],
        paginationBrands: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class BrandsState implements NgxsOnInit {
    constructor(private brandsService: BrandsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetBrandsList)
    getBrandsList({ getState, patchState }: StateContext<BrandsStateModel>, action: GetBrandsList) {
        const { paginationBrands } = getState();
        patchState({ loading: true })
        return this.brandsService.getBrands(action.status, paginationBrands).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const brandsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        brandsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeBrandsPage)
    changeBrandsPage({ patchState, getState }: StateContext<BrandsStateModel>, action: ChangeBrandsPage) {
        patchState({ paginationBrands: { ...getState().paginationBrands, page: action.paylaod } })
    }

    @Action(GetBrandsWithFilters)
    getBrandsWithFilters({ getState, patchState }: StateContext<BrandsStateModel>, action: GetBrandsWithFilters) {
        const { paginationBrands } = getState();
        patchState({ loading: true })
        return this.brandsService.getBrandsWithFilters(action.paylaod, action.status, paginationBrands).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const categoriesList = result.content;
                    const total = result.totalElements;
                    patchState({
                        categoriesList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(AddBrandsStatus)
    addBrandsStatus({ patchState }: StateContext<BrandsStateModel>, action: AddBrandsStatus) {
        patchState({ loading: true })
        return this.brandsService.addBrandsStatus(action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(UpdateBrandsStatus)
    UpdateBrandsStatus({ patchState }: StateContext<BrandsStateModel>, action: UpdateBrandsStatus) {
        patchState({ loading: true })
        return this.brandsService.updateBrandsStatus(action.id,action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(EditBrandsStatus)
    editBrandsStatus({ patchState }: StateContext<BrandsStateModel>, action: EditBrandsStatus) {
        patchState({ loading: true })
        return this.brandsService.editBrandsStatus(action.id, action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(DeleteBrandsStatus)
    deleteBrandsStatus({ patchState }: StateContext<BrandsStateModel>, action: DeleteBrandsStatus) {
        patchState({ loading: true })
        return this.brandsService.deleteBrandsStatus(action.id).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
}