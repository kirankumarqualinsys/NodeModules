import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzAvatarModule } from 'ng-zorro-antd/avatar';
import { NzIconModule } from 'ng-zorro-antd/icon';
import { NzTagModule } from 'ng-zorro-antd/tag';
import { NzSpaceModule } from 'ng-zorro-antd/space';
import { CommonProductModalComponent } from './common-product-modal.component';
import { FiltersDynamicFormModule } from 'libs/shared/src/lib/components/common/filters-dynamic-form/filters-dynamic-form.module';

@NgModule({
  declarations: [
    CommonProductModalComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
     
    ]),
    NzDividerModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzDatePickerModule,
    NzButtonModule,
    NzInputModule,
    NzDropDownModule,
    NzModalModule,
    NzSelectModule,
    NzRadioModule,
    NzAutocompleteModule,
    FiltersDynamicFormModule,
    NzAvatarModule,
    NzIconModule,
    NzSpaceModule,
    NzTagModule,
  ],
  exports: [CommonProductModalComponent]
})
export class CommonProductModalModule {}

