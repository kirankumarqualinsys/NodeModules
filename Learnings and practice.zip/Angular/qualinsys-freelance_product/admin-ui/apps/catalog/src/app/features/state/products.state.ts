import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddProductsStatus, ChangeProductsPage, DeleteProductsStatus, EditProductsStatus, GetProductsList, GetProductsListById, GetProductsWithFilters, UpdateProductsStatus } from './products.action';
import { CategoriesService } from '../../services/categories.service';
import { ProductsService } from '../../services/products.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface ProductsStateModel {
    [x: string]: any;
    productsList: [];
    paginationProducts: IPage;
    total: number;
    loading: boolean;
}
@State<ProductsStateModel>({
    name: 'products',
    defaults: {
        productsList: [],
        paginationProducts: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class ProductsState implements NgxsOnInit {
    constructor(private productsService: ProductsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetProductsList)
    getProductsList({ getState, patchState }: StateContext<ProductsStateModel>, action: GetProductsList) {
        const { paginationProducts } = getState();
        patchState({ loading: true })
        return this.productsService.getProducts(action.status, paginationProducts).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const productsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        productsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }

    @Action(GetProductsListById)
    getProductsListById({ getState, patchState }: StateContext<ProductsStateModel>, action: GetProductsList) {
        const { paginationProducts } = getState();
        patchState({ loading: true })
        return this.productsService.getProductsStatusById(action.status, paginationProducts).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    console.log(result);
                    
                    const productsListById = result;
                    const total = result.totalElements;
                    patchState({
                        productsListById,
                        total,
                        loading: false
                    });
                }
            })
        );
    }

    @Action(ChangeProductsPage)
    changeProductsPage({ patchState, getState }: StateContext<ProductsStateModel>, action: ChangeProductsPage) {
        patchState({ paginationProducts: { ...getState().paginationProducts, page: action.paylaod } })
    }

    @Action(GetProductsWithFilters)
    getProductsWithFilters({ getState, patchState }: StateContext<ProductsStateModel>, action: GetProductsWithFilters) {
        const { paginationProducts } = getState();
        patchState({ loading: true })
        return this.productsService.getProductsWithFilters(action.paylaod, action.status, paginationProducts).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const productsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        productsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(AddProductsStatus)
    addProductsStatus({ patchState }: StateContext<ProductsStateModel>, action: AddProductsStatus) {
        patchState({ loading: true })
        return this.productsService.addProductsStatus(action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(UpdateProductsStatus)
    UpdateProductsStatus({ patchState }: StateContext<ProductsStateModel>, action: UpdateProductsStatus) {
        patchState({ loading: true })
        return this.productsService.updateProductsStatus(action.id,action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(EditProductsStatus)
    editProductsStatus({ patchState }: StateContext<ProductsStateModel>, action: EditProductsStatus) {
        patchState({ loading: true })
        return this.productsService.editProductsStatus(action.id, action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(DeleteProductsStatus)
    deleteProductsStatus({ patchState }: StateContext<ProductsStateModel>, action: DeleteProductsStatus) {
        patchState({ loading: true })
        return this.productsService.deleteProductsStatus(action.id).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
}