export class GetProductsList {
    static readonly type = '[Products] Get Products';
    constructor(public status: any) { }
}
export class GetProductsListById {
    static readonly type = '[Products] Get Products By Id';
    constructor(public status: any) { }
}

export class GetProductsWithFilters {
    static readonly type = '[Products] Get Products With Filters';
    constructor(public readonly paylaod: any, public readonly status: string) { }
  }

export class ChangeProductsPage {
    static readonly type = '[Products] Change Products Page';
    constructor(public readonly paylaod: number) { }
}



export class UpdateProductsStatus {
    static readonly type = '[Products] Update Products Status';
    constructor(public readonly id: number, public readonly data: any) { }
}
export class AddProductsStatus {
    static readonly type = '[Products] Add Products Status';
    constructor(public readonly data: any) { }
}
export class EditProductsStatus {
    static readonly type = '[Products] Edit Products Status';
    constructor(public readonly id: number, public data: any) { }
}
export class DeleteProductsStatus {
    static readonly type = '[Products] Delete Products Status';
    constructor(public readonly id: number) { }
}