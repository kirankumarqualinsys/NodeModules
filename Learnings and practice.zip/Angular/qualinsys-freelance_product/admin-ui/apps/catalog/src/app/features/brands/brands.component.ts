import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { AddBrandsStatus, ChangeBrandsPage, GetBrandsList, GetBrandsWithFilters, UpdateBrandsStatus, DeleteBrandsStatus, EditBrandsStatus } from '../state/brands.action';
import { NzButtonSize } from 'ng-zorro-antd/button';

import { BrandsStateSelectors } from '../state/brands.selectors';
import { BrandsService } from '../../services/brands.service';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}
@Component({
  selector: 'commerceq-admin-ui-brands',
  templateUrl: './brands.component.html',
  styleUrls: ['./brands.component.less'],
})
export class BrandsComponent { 
  
  tabs = ['All', 'Enabled', 'Disabled'];
activetabIndex = 0;
tabStatus: any = true;
date = null;
validateForm!: UntypedFormGroup;
size: NzButtonSize = 'large';
options =  [
  {
    label: "Select Option",
    value: "",
  },
  {
    label: "Manually",
    value: "MANUAL",
  },
  {
    label: "Alphabetically ASC(A-Z)",
    value: "RELATED",
  },
  {
    label: "Alphabetically DESC(Z-A)",
    value: "CROSS_SALE",
  },
  {
    label: "Price - High to Low",
    value: "UP_SALE",
  },


  {
    label: "Price - Low to High",
    value: "RELATED",
  },
  {
    label: "Date - oldest to newest",
    value: "CROSS_SALE",
  },
  {
    label: "Date - newest to oldest",
    value: "UP_SALE",
  },
  
];

brandsList: any = [];
showDeleteModal: boolean = false;
selectedCategory: any = {};
enabledValues = [
  { key: true, name: 'Active' },
  { key: false, name: 'Inactive' }
]
public paginationLimit = [10, 20, 50, 100]

@Select((state: any) => state.brands.brandsList)
brandsList$!: Observable<any>;
@Select((state: any) => state.brands.paginationBrands.size)
pageSize$: Observable<any> | undefined;
@Select((state: any) => state.brands.total)
total$: Observable<any> | undefined;
@Select((state: any) => state.brands.paginationBrands.page)
pageIndex$: Observable<any> | undefined;
@Select((state: any) => state.brands.loading)
loading$: Observable<boolean> | undefined;

trackByFn: TrackByFunction<any> = (index, item) => item.id;
categoryFormGroup!: UntypedFormGroup;
constructor(private store: Store, private fb: UntypedFormBuilder,
  private brnadsService: BrandsService) {
  this.categoryFormGroup =  this.fb.group({
    name: [null, [Validators.required]],
    active: [null, [Validators.required]],
    sortOrder: [null, [Validators.required]],  
    code : [null], 
  })
}
async ngOnInit() {
  this.store.dispatch(new GetBrandsList(true))

}



submitForm(): void {
  if (this.validateForm.valid) {
  } else {
    Object.values(this.validateForm.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }
}
onChange(result: Date): void {
  // console.log('onChange: ', result);
}

onChangePage(page: number): void {
  this.store.dispatch([new ChangeBrandsPage(page), new GetBrandsList(this.tabStatus)])
}
changeStatus(event: boolean, id: number) {
  this.store.dispatch([new UpdateBrandsStatus(id, event)])
}



updateCategory(value: any, data: any, type: string) {
  let updatedObj = { ...data };
  const date = new Date();
  const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = String(date.getFullYear());
  const lastUpdated = `${day}-${month}-${year}`;
  if (type == 'featured') {
    updatedObj.featured = value;
  } else if (type == 'showInMenu') {
    updatedObj.showInMenu = value;
  } else if (type == 'enabled') {
    updatedObj.enabled = value;
  }

  updatedObj.lastUpdatedOn = lastUpdatedOn;
  updatedObj.lastUpdated = lastUpdated;
  this.store.dispatch([new UpdateBrandsStatus(updatedObj.id, updatedObj), new GetBrandsList(this.tabStatus)])
}
editSEO($event: any) {
  // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
}



//modal functionality
isVisible = false;
title: string = 'Add New Brand';
showModal(type: string, categoryData?: any): void {
  this.selectedCategory = categoryData;
  if (type == 'Add') {
    this.title = 'Add New Brand';
    this.categoryFormGroup.reset();
  } else {

    this.title = 'Edit New Brand';
    this.categoryFormGroup.controls['name'].setValue(categoryData.name);
    this.categoryFormGroup.controls['active'].setValue(categoryData.active);
    this.categoryFormGroup.controls['sortOrder'].setValue(categoryData.sortOrder); 
   
  }
  this.isVisible = true;
}

Submit(): void {
  if (this.categoryFormGroup.valid) {
    if (this.title == 'Add New Brand') {
      this.store.dispatch([new AddBrandsStatus(this.categoryFormGroup.value), new GetBrandsList(this.tabStatus)])
      this.isVisible = false;
    } else {
      let categoryObj = { ...this.selectedCategory };     
      categoryObj.name = this.categoryFormGroup.value.name;
      categoryObj.sortOrder = this.categoryFormGroup.value.sortOrder;
      categoryObj.active = this.categoryFormGroup.value.active;
      this.store.dispatch([new EditBrandsStatus(categoryObj.id, categoryObj), new GetBrandsList(this.tabStatus)])
      this.isVisible = false;
    }
    this.Cancel();
  } else {
    Object.values(this.categoryFormGroup.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }


}

Cancel(): void {
  this.isVisible = false;
}

//delete modal functionality
deleteCategory(category: any) {
  this.selectedCategory = category;
  this.showDeleteModal = true;
}
proceedtoDelete() {
  this.store.dispatch([new DeleteBrandsStatus(this.selectedCategory.id), new GetBrandsList(this.tabStatus)])

  this.showDeleteModal = false;
}


}


