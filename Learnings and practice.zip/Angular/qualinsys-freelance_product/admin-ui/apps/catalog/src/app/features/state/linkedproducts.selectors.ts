import { Selector } from '@ngxs/store';
import {
    LinkedProductsStateModel,
    LinkedProductsState,
} from './linkedproducts.state';


export class LinkedproductsStateSelectors {
    @Selector([LinkedProductsState])
    static linkedProductList(state: LinkedProductsStateModel) {
        return state['linkedProductList'];
      }
    static pageSize(state: LinkedProductsStateModel) {
        return state.paginationLinkedProducts.size;
    }
    static total(state: LinkedProductsStateModel) {
        return state.total;
    }
    static pageIndex(state: LinkedProductsStateModel) {
        return state.paginationLinkedProducts.page;
    }
    static loading(state: LinkedProductsStateModel) {
        return state.loading;
    }
}