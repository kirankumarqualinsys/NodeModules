import { Selector } from '@ngxs/store';
import {
    CollectionsStateModel,
    CollectionsState,
} from './collections.state';


export class CollectionsStateSelectors {
    @Selector([CollectionsState])
    static collectionsList(state: CollectionsStateModel) {
        return state['collectionsList'];
    }
    static pageSize(state: CollectionsStateModel) {
        return state.paginationCollections.size;
    }
    static total(state: CollectionsStateModel) {
        return state.total;
    }
    static pageIndex(state: CollectionsStateModel) {
        return state.paginationCollections.page;
    }
    static loading(state: CollectionsStateModel) {
        return state.loading;
    }
}