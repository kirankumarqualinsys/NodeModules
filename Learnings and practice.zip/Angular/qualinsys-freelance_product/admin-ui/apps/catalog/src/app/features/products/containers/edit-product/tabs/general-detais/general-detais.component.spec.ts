import { ComponentFixture, TestBed } from '@angular/core/testing';
import { GeneralDetaisComponent } from './general-detais.component';

describe('GeneralDetaisComponent', () => {
  let component: GeneralDetaisComponent;
  let fixture: ComponentFixture<GeneralDetaisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [GeneralDetaisComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(GeneralDetaisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
