import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class CategoriesService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getCategories(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/search`;
    const data = {
      "name": "",
      "parentName": "",
      "featured": "",
      "hasImage": "",
      "showInMenu": "",
      "enabled": payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)

  }

  getCategoriesWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/search`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  updateCategoriesStatus(id: number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/${id}`;
    return this.http.put(url, data)
  }
  addCategoriesStatus( data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories`;
   
    return this.http.post(url, data);
  }
  editCategoriesStatus(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/${id}`;
   
    return this.http.put(url, data);
  }
  deleteCategoriesStatus( id:number) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/${id}`;
   
    return this.http.delete(url);
  }

  getParent(query: string) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/autocompleter?query=${query}`;
    return this.http.get(url)
  }

  getCategoriesList() {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/list?loadChilds=true`;
    return this.http.get(url)
  }
  
}
