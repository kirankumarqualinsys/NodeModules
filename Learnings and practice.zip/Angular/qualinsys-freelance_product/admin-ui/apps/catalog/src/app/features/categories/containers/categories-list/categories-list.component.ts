import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { AddCategoriesStatus, ChangeCategoriesPage, GetCategoriesList, GetCategoriesWithFilters, UpdateCategoriesStatus, DeleteCategoriesStatus, EditCategoriesStatus } from '../../../state/categories.action';
import { CategoriesStateSelectors } from '../../../state/categories.selectors';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { CategoriesService } from 'apps/catalog/src/app/services/categories.service';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}

@Component({
  selector: 'commerceq-admin-ui-categories-list',
  templateUrl: './categories-list.component.html',
  styleUrls: ['./categories-list.component.less']
})
export class CategoriesListComponent {
  tabs = ['All', 'Enabled', 'Disabled'];
  activetabIndex = 0;
  tabStatus: any = true;
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'large';
  categoriesFilterFields = {
    categoryName: {
      type: "text",
      value: "",
      label: "Category Name",
      span: "6"
    },
    parentName: {
      type: "text",
      value: "",
      label: "Parent Name",
      span: "6"
    },
    featured: {
      type: "select",
      value: "",
      label: "Featured",
      span: "6",
      options: [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Yes",
          value: "Yes",
        },
        {
          label: "No",
          value: "No",
        }
      ],
    },
    showInMenu: {
      type: "select",
      value: "",
      label: "Show In Menu",
      span: "6",
      options: [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Yes",
          value: "Yes",
        },
        {
          label: "No",
          value: "No",
        }
      ],
    },
  };
  categoriesList: any = [];
  showDeleteModal: boolean = false;
  selectedCategory: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100]

  @Select((state: any) => state.categories.categoriesList)
  categoriesList$!: Observable<any>;
  @Select((state: any) => state.categories.paginationCategories.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.categories.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.categories.paginationCategories.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.categories.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  categoryFormGroup!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder,
    private categoriesService: CategoriesService) {
    this.categoryFormGroup = this.fb.group({
      name: [null, [Validators.required]],
      parent: [null],
      featured: [false],
      showInMenu: [false],
      enabled: [true],
    })
  }
  async ngOnInit() {
    this.store.dispatch(new GetCategoriesList(true))

  }

  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = true;
      this.store.dispatch([new ChangeCategoriesPage(1), new GetCategoriesList(true)]);
    } else if (this.activetabIndex === 1) {
      this.tabStatus = true;
      this.store.dispatch([new ChangeCategoriesPage(1), new GetCategoriesList(true)]);
    } else {
      this.tabStatus = false;
      this.store.dispatch([new ChangeCategoriesPage(1), new GetCategoriesList(false)]);
    }
  }


  submitForm(): void {
    if (this.validateForm.valid) {
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  onChange(result: Date): void {
    // console.log('onChange: ', result);
  }

  // async ngOnInit() {
  //   console.log(123)
  // }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeCategoriesPage(page), new GetCategoriesList(this.tabStatus)])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateCategoriesStatus(id, event)])
  }

  filtersFormSubmit(event: any) {
    let obj = {
      "name": event.categoryName,
      "parentName": event.parentName,
      "featured": event.featured == 'Yes' ? true : event.featured == '' ? '' : false,
      "hasImage": "",
      "showInMenu": event.showInMenu == 'Yes' ? true : event.showInMenu == '' ? '' : false,
    }
    this.store.dispatch(new GetCategoriesWithFilters(obj, this.tabStatus))
  }

  updateCategory(value: any, data: any, type: string) {
    let updatedObj = { ...data };
    const date = new Date();
    const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear());
    const lastUpdated = `${day}-${month}-${year}`;
    if (type == 'featured') {
      updatedObj.featured = value;
    } else if (type == 'showInMenu') {
      updatedObj.showInMenu = value;
    } else if (type == 'enabled') {
      updatedObj.enabled = value;
    }

    updatedObj.lastUpdatedOn = lastUpdatedOn;
    updatedObj.lastUpdated = lastUpdated;
    this.store.dispatch([new UpdateCategoriesStatus(updatedObj.id, updatedObj), new GetCategoriesList(this.tabStatus)])
  }
  editSEO($event: any) {
    // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
  }

  //auto complete for parent
  parentList: any = []
  getParentList(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    if (value && value.length > 2) {
      this.categoriesService.getParent(value).subscribe((res: any) => {
        this.parentList = [];
        if (res && res.length > 0) {
          this.parentList = res;
        }
      })
    }
  }

  //modal functionality
  isVisible = false;
  title: string = 'Add Category';
  showModal(type: string, categoryData?: any): void {
    this.selectedCategory = categoryData;
    if (type == 'Add') {
      this.title = 'Add Category';
      this.categoryFormGroup.reset();
    } else {

      this.title = 'Edit Category';
      this.categoryFormGroup.controls['name'].setValue(categoryData.name);
      this.categoryFormGroup.controls['featured'].setValue(categoryData.featured);
      this.categoryFormGroup.controls['showInMenu'].setValue(categoryData.showInMenu);
      this.categoryFormGroup.controls['enabled'].setValue(categoryData.enabled);
      this.parentList = [];
      if (categoryData.parent != null) {
        if (typeof categoryData.parent === 'object') {
          this.categoryFormGroup.controls['parent'].setValue(categoryData.parent);
        } else {
          let value = categoryData.parent.substring(0, 3);
          if (value && value.length > 2) {
            this.categoriesService.getParent(value).subscribe((res: any) => {
              this.parentList = [];
              if (res && res.length > 0) {
                this.parentList = res;
                this.categoryFormGroup.controls['parent'].setValue(this.parentList[0].displayName);
              }
            })
          }
        }
      }

      
    }
    this.isVisible = true;
  }

  Submit(): void {
    if (this.categoryFormGroup.valid) {
      if (this.title == 'Add Category') {
        this.store.dispatch([new AddCategoriesStatus(this.categoryFormGroup.value), new GetCategoriesList(this.tabStatus)])
        this.isVisible = false;
      } else {
        let categoryObj = { ...this.selectedCategory };
        let parent = (typeof this.categoryFormGroup.value.parent === 'object' && this.categoryFormGroup.value.parent !== null) ? this.categoryFormGroup.value.parent : null;
        if (parent != null) {
          categoryObj.parentId = parent.id;
        }
        categoryObj.name = this.categoryFormGroup.value.name;
        categoryObj.featured = this.categoryFormGroup.value.featured;
        categoryObj.enabled = this.categoryFormGroup.value.enabled;
        categoryObj.showInMenu = this.categoryFormGroup.value.showInMenu;
        categoryObj.parent = parent;

        this.store.dispatch([new EditCategoriesStatus(categoryObj.id, categoryObj), new GetCategoriesList(this.tabStatus)])
        this.isVisible = false;
      }
      this.Cancel();
    } else {
      Object.values(this.categoryFormGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }


  }

  Cancel(): void {
    this.isVisible = false;
  }

  //delete modal functionality
  deleteCategory(category: any) {
    this.selectedCategory = category;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([new DeleteCategoriesStatus(this.selectedCategory.id), new GetCategoriesList(this.tabStatus)])

    this.showDeleteModal = false;
  }


}

