import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddLinkedProductsStatus, ChangeLinkedProductsPage, DeleteLinkedProductsStatus, EditLinkedProductsStatus, GetlinkedProdcutsList, GetLinkedProductsWithFilters, UpdateLinkedProductsStatus } from './linkedproudcts.action';
import { LinkedProductsService } from '../../services/linked-products.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface LinkedProductsStateModel {
    [x: string]: any;
    linkedProductList: [];
    paginationLinkedProducts: IPage;
    total: number;
    loading: boolean;
}
@State<LinkedProductsStateModel>({
    name: 'linkedproducts',
    defaults: {
        linkedProductList: [],
        paginationLinkedProducts: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class LinkedProductsState implements NgxsOnInit {
    constructor(private linkedproductService: LinkedProductsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetlinkedProdcutsList)
    getLinkedProductsList({ getState, patchState }: StateContext<LinkedProductsStateModel>, action: GetlinkedProdcutsList) {
        const { paginationLinkedProducts } = getState();
        patchState({ loading: true })
        console.log(action.status, paginationLinkedProducts, 'paginationLinkedProducts');
        return this.linkedproductService.getLinkedProducts(action.status, paginationLinkedProducts).pipe(
            take(1),
            tap((result: any) => {
                console.log('hiiiiiiiiiiiii',result);
                if (result && result.content) {
                    const linkedProductList = result.content;
                    const total = result.totalElements;
                    patchState({
                        linkedProductList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeLinkedProductsPage)
    changeLinkedProductsPage({ patchState, getState }: StateContext<LinkedProductsStateModel>, action: ChangeLinkedProductsPage) {
        patchState({ paginationLinkedProducts: { ...getState().paginationLinkedProducts, page: action.paylaod } })
    }

    @Action(GetLinkedProductsWithFilters)
    getLinkedProductsWithFilters({ getState, patchState }: StateContext<LinkedProductsStateModel>, action: GetLinkedProductsWithFilters) {
        const { paginationLinkedProducts } = getState();
        patchState({ loading: true })
        return this.linkedproductService.getLinkedProductsWithFilters(action.paylaod, action.status, paginationLinkedProducts).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const linkedProductList = result.content;
                    const total = result.totalElements;
                    patchState({
                        linkedProductList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(AddLinkedProductsStatus)
    addLinkedProductsStatus({ patchState }: StateContext<LinkedProductsStateModel>, action: AddLinkedProductsStatus) {
        patchState({ loading: true })
        return this.linkedproductService.addLinkedProductsStatus(action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(EditLinkedProductsStatus)
    editLinkedProductsStatus({ patchState }: StateContext<LinkedProductsStateModel>, action: EditLinkedProductsStatus) {
        patchState({ loading: true })
        return this.linkedproductService.editLinkedProductsStatus(action.id, action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(UpdateLinkedProductsStatus)
    updateLinkedProductsStatus({ patchState }: StateContext<LinkedProductsStateModel>, action: UpdateLinkedProductsStatus) {
        patchState({ loading: true })
        return this.linkedproductService.updateLinkedProductsStatus(action.id, action.value).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(DeleteLinkedProductsStatus)
    deleteLinkedProductsStatus({ patchState }: StateContext<LinkedProductsStateModel>, action: DeleteLinkedProductsStatus) {
        patchState({ loading: true })
        return this.linkedproductService.deleteLinkedProductsStatus(action.id).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
}