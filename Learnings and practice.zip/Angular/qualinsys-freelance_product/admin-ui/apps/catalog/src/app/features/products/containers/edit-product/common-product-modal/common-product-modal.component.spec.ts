import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonProductModalComponent } from './common-product-modal.component';

describe('CommonProductModalComponent', () => {
  let component: CommonProductModalComponent;
  let fixture: ComponentFixture<CommonProductModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CommonProductModalComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(CommonProductModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
