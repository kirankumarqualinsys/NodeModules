import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.less'],
})
export class CategoriesComponent {}
