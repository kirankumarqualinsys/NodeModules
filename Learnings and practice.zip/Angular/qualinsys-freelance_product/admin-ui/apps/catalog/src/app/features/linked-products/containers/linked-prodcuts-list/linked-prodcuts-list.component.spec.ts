import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LinkedProdcutsListComponent } from './linked-prodcuts-list.component';

describe('LinkedProdcutsListComponent', () => {
  let component: LinkedProdcutsListComponent;
  let fixture: ComponentFixture<LinkedProdcutsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LinkedProdcutsListComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(LinkedProdcutsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
