export class GetVariantsList {
    static readonly type = '[Variants] Get Variants';
    constructor(public status: any , public readonly id: number) { }
}
export class GetVariantsWithFilters {
    static readonly type = '[Variants] Get Variants With Filters';
    constructor(public readonly paylaod: any, public readonly status: string) { }
  }

export class ChangeVariantsPage {
    static readonly type = '[Variants] Change Variants Page';
    constructor(public readonly paylaod: number) { }
}



export class UpdateVariantsStatus {
    static readonly type = '[Variants] Update Variants Status';
    constructor(public readonly id: number, public readonly data: any) { }
}
export class AddVariantsStatus {
    static readonly type = '[Variants] Add Variants Status';
    constructor(public readonly data: any, public readonly id: number) { }
}
export class EditVariantsStatus {
    static readonly type = '[Variants] Edit Variants Status';
    constructor(public readonly id: number, public data: any) { }
}

export class AddVariantOptions {
    static readonly type = '[VariantOptions] Add Variant Options';
    constructor(public readonly payload: any,public readonly  id:any) { }
}

export class DeleteVariantOptions {
    static readonly type = '[VariantOptions] Delete VariantOptions';
    constructor(public readonly productid: number ,public readonly id: number) { }
}
 

export class GetVariantsOptionsList {
    static readonly type = '[VariantOptions] Get VariantOptions';
    constructor(public readonly id: number) { }
}