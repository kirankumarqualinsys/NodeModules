import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class BrandsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getBrands(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands/search`;
    const data = {
      "name": "",
      "parentName": "",
      "featured": "",
      "hasImage": "",
      "showInMenu": "",
      "enabled": payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)

  }

  getBrandsWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  updateBrandsStatus(id: number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands/${id}`;
    return this.http.put(url, data)
  }
  addBrandsStatus( data:any) {
    data.code = data.name;
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands`;
   
    return this.http.post(url, data);
  }
  editBrandsStatus(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands/${id}`;
   
    return this.http.put(url, data);
  }
  deleteBrandsStatus( id:number) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands/${id}`;
   
    return this.http.delete(url);
  }

  getParent(query: string) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands/autocompleter?query=${query}`;
    return this.http.get(url)
  }

  getBrandsWithSize(size:any) {
    const url = `${this.environment.apiUrl}/catalog/api/catalog/brands?page=${size.page}&size=${size.size}`;
    return this.http.get(url)
  }
}

