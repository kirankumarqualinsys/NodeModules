import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-linked-products',
  templateUrl: './linked-products.component.html',
  styleUrls: ['./linked-products.component.less'],
})
export class LinkedProductsComponent {}
