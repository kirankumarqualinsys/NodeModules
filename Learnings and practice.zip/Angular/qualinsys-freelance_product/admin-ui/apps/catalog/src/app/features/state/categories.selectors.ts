import { Selector } from '@ngxs/store';
import {
    CategoriesStateModel,
    CategoriesState,
} from './categories.state';


export class CategoriesStateSelectors {
    @Selector([CategoriesState])
    static categoriesList(state: CategoriesStateModel) {
        return state['categoriesList'];
      }
    static pageSize(state: CategoriesStateModel) {
        return state.paginationCategories.size;
    }
    static total(state: CategoriesStateModel) {
        return state.total;
    }
    static pageIndex(state: CategoriesStateModel) {
        return state.paginationCategories.page;
    }
    static loading(state: CategoriesStateModel) {
        return state.loading;
    }
}