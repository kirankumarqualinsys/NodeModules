import { Component, ElementRef, ViewChild } from '@angular/core';
import { NzButtonSize } from 'ng-zorro-antd/button/button.component';
import { FormGroup, UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { AddCategoriesStatus, EditCategoriesStatus, GetCategoriesList } from '../../../state/categories.action';
import { CategoriesService } from 'apps/catalog/src/app/services/categories.service';
import { Store } from '@ngxs/store';
import { CollectionsService } from 'apps/catalog/src/app/services/collections.service';
import { distinctUntilChanged } from 'rxjs';
import { ProductsService } from 'apps/catalog/src/app/services/products.service';
import { Router } from '@angular/router';
import { NzSelectSizeType } from 'ng-zorro-antd/select';
import { AddProductsStatus } from '../../../state/products.action';

@Component({
  selector: 'commerceq-admin-ui-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.less'],
})
export class AddProductComponent {
  size: NzButtonSize = 'large';
  productForm!: UntypedFormGroup;
  categoryFormGroup!: UntypedFormGroup;
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ];
  collectionList: any = [];
  salesChannelsList: any = [];
  sizeSelect: NzSelectSizeType = 'default';
  constructor(private fb: UntypedFormBuilder, private categoriesService: CategoriesService,
    private store: Store, private collectionService: CollectionsService, private productService: ProductsService,
    private router: Router) {
    this.categoryFormGroup = this.fb.group({
      name: [null, [Validators.required]],
      parent: [null],
      featured: [false],
      showInMenu: [false],
      enabled: [true],
    })
  }

  ngOnInit(): void {
    //get categ5ory list
    this.categoriesService.getCategoriesList().subscribe((res: any) => {
      this.parentList = [];
      if (res && res.length > 0) {
        this.parentList = res;
      }
    });
    //get collectionList list
    this.collectionService.getCollectionsList().subscribe((res: any) => {
      this.collectionList = [];
      if (res && res.length > 0) {
        this.collectionList = res;
      }
    });
    //get sales channels list
    this.productService.getsalesChannelsList().subscribe((res: any) => {
      this.salesChannelsList = [];
      if (res.data && res.data.length > 0) {
        this.salesChannelsList = res.data;
      }
    });

    this.productForm = this.fb.group({
      title: ['', [Validators.required]],
      categoryId: [null, [Validators.required]],
      brandId: [''],
      description: ['', [Validators.required]],
      model: [''],
      paidBy: [''],
      productId: [''],
      quantity: [0, [Validators.required]],
      shipsIn: [''],
      sku: [null, [Validators.required]],
      tags: [[]],
      collections: [[]],
      options: [null, [Validators.required]],
      variant: [null, [Validators.required]],
      uom: [null, [Validators.required]],
      barcode: [''],
      hsnCode: [''],
      trackInventory: [false],
      allowOutOfStockSelling: [false],
      supplyPrice: [null, [Validators.required]],
      markupPercentage: [null, [Validators.required]],
      retailPrice: [null, [Validators.required]],
      comparePrice: [null, [Validators.required]],
      enabled: [false],


    }, { validators: this.compareValues('comparePrice', 'retailPrice') });
    this.productForm.valueChanges.subscribe((data: any) => {
      if (data.supplyPrice && data.markupPercentage) {
        let value = (parseInt(data.supplyPrice) * (parseInt(data.markupPercentage) / 100)) + parseInt(data.supplyPrice);
        this.productForm.controls['retailPrice'].setValue(value, { emitEvent: false });
        // this.productForm.controls['retailPrice'].updateValueAndValidity({emitEvent : false});
      } 

      
      // else {
      //   this.productForm.controls['retailPrice'].setValue('', { emitEvent: false });
      //   // this.productForm.controls['retailPrice'].updateValueAndValidity({emitEvent : false});
      // }
    })
  }
  compareValues(controlName: string, compareToControlName: string) {
    return (formGroup: UntypedFormGroup) => {
      const control = formGroup.controls[controlName];
      const compareToControl = formGroup.controls[compareToControlName];
  
      if (control.value < compareToControl.value) {
        compareToControl.setErrors({ compareValues: true });
      } else {
        compareToControl.setErrors(null);
      }
    };
  }
  channels:any =[];
  channelsList(event:any,id:number){
   console.log(event.target.checked);
   if(event.target.checked){
     this.channels.push(id);
   } else{
    this.channels = this.channels.filter((tag: any) => tag !== id);
   }
   console.log(this.channels);
   
  }
  submitForm() {
     console.log(this.productForm.value)
     let productObj={
      "brandId": "",
      "categoryId": this.productForm.value.categoryId?.id,
      "description": this.productForm.value.description,
      "discountedPrice": 0,
      "model": "",
      "paidBy": "",
      "productId": "",
      "quantity": this.productForm.value.quantity,
      "shipsIn": "",
      "sku": this.productForm.value.sku,
      "title": this.productForm.value.title,
      "variantOptions": [
          {
              "variant": this.productForm.value.variant,
              "options": [
                this.productForm.value.options
              ]
          }
      ],
      "variants": [
          {
              "barcode": this.productForm.value.barcode,
              "code": "",
              "name": this.productForm.value.variant,
              "price": 0,
              "sku": this.productForm.value.sku,
              "variantValues": {
                  [this.productForm.value.variant]: this.productForm.value.options
              },
              "supplyPrice": parseInt(this.productForm.value.supplyPrice) ,
              "markupPercentage": parseInt(this.productForm.value.markupPercentage) ,
              "retailPrice":parseInt(this.productForm.value.retailPrice) ,
              "comparePrice":parseInt(this.productForm.value.comparePrice) ,
              "quantity": this.productForm.value.quantity,
              "uom": this.productForm.value.uom,
          }
      ],
      "weight": "",
      "enabled": this.productForm.value.enabled,
      "tags": this.tags,
      "collections": this.productForm.value.collections,
      "hsnCode": this.productForm.value.hsnCode,
      "trackInventory": this.productForm.value.trackInventory,
      "allowOutOfStockSelling": this.productForm.value.allowOutOfStockSelling,
      "supplyPrice": parseInt(this.productForm.value.supplyPrice)  ,
      "retailPrice": this.productForm.value.retailPrice,
      "markupPercentage": parseInt(this.productForm.value.markupPercentage) ,
      "comparePrice": parseInt(this.productForm.value.comparePrice),
      "salesChannels": this.channels
  }

  console.log(productObj);
  if (this.productForm.valid) {
    console.log('valid');
    this.store.dispatch([new AddProductsStatus(productObj)]);
    this.router.navigateByUrl('/list');
   
  } else {
    Object.values(this.productForm.controls).forEach(control => {
      if (control.invalid) {
        control.markAsDirty();
        control.updateValueAndValidity({ onlySelf: true });
      }
    });
  }
  
  }

  //add categ5ory functinality
  //modal functionality
  isVisible = false;
  title: string = 'Add Category';
  showModal(): void {
    this.categoryFormGroup.reset();
    this.isVisible = true;
  }

  parentList: any = []
  getParentList(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    if (value && value.length > 2) {
      this.categoriesService.getParent(value).subscribe((res: any) => {
        this.parentList = [];
        if (res && res.length > 0) {
          this.parentList = res;
        }
      })
    }
  }
  Submit(): void {
    if (this.categoryFormGroup.valid) {
      this.store.dispatch([new AddCategoriesStatus(this.categoryFormGroup.value)])
      this.isVisible = false;
      this.Cancel();
    } else {
      Object.values(this.categoryFormGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }


  }

  Cancel(): void {
    this.isVisible = false;
  }

  //add tags func
  tags: any = [];
  inputVisible = false;
  inputValue = '';
  @ViewChild('inputElement', { static: false }) inputElement?: ElementRef;

  handleClose(removedTag: {}): void {
    this.tags = this.tags.filter((tag: any) => tag !== removedTag);
  }

  sliceTagName(tag: string): string {
    const isLongTag = tag.length > 20;
    return isLongTag ? `${tag.slice(0, 20)}...` : tag;
  }

  showInput(): void {
    this.inputVisible = true;
    setTimeout(() => {
      this.inputElement?.nativeElement.focus();
    }, 10);
  }

  handleInputConfirm(): void {
    if (this.inputValue && this.tags.indexOf(this.inputValue) === -1) {
      this.tags = [...this.tags, this.inputValue];
    }
    this.inputValue = '';
    this.inputVisible = false;
  }

  //navig5ate to list product page
  listProduct() {
    this.router.navigateByUrl('/list');
  }
}
