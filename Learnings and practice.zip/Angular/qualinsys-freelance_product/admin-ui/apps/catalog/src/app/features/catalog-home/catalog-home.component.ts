import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-catalog-home',
  templateUrl: './catalog-home.component.html',
  styleUrls: ['./catalog-home.component.less'],
})
export class CatalogHomeComponent implements OnInit {
  menuConfig: any;
  constructor() { }
  async ngOnInit() {
    this.setMenuItems();
  }
  async setMenuItems() {
    this.menuConfig = {
      items: [
        {
          key: 'products',
          value: 'Products'
        },
        {
          key: 'collections',
          value: 'Collections'
        },
        {
          key: 'categories',
          value: 'Categories'
        },
        {
          key: 'brands',
          value: 'Brands'
        },
        {
          key: 'linked-products',
          value: 'Linked Products'
        }
      ]
    }
  }
}
