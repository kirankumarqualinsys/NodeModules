import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { AddProductsStatus, ChangeProductsPage, GetProductsList, GetProductsWithFilters, UpdateProductsStatus, DeleteProductsStatus, EditProductsStatus } from '../../../state/products.action';
// import { CategoriesStateSelectors } from '../../../state/categories.selectors';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { ProductsService } from 'apps/catalog/src/app/services/products.service';
import { LinkedProductsService } from 'apps/catalog/src/app/services/linked-products.service';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}

@Component({
  selector: 'commerceq-admin-ui-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.less'],
})
export class ProductsListComponent {
  tabs = ['All', 'Enabled', 'Disabled'];
  activetabIndex = 0;
  tabStatus: any = true;
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'small';
  optionsList: any = [{
    label: "Select Option",
    value: "",
  }]
  productsFilterFields = {
    title: {
      type: "text",
      value: "",
      label: "Title",
      span: "6"
    },
    sku: {
      type: "text",
      value: "",
      label: "SKU",
      span: "6"
    },
    categoryId: {
      type: "select",
      value: "",
      label: "Product Category",
      span: "6",
      options: this.optionsList
    },
    enabled: {
      type: "select",
      value: "",
      label: "Status",
      span: "6",
      options: [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Enabled",
          value: "true",
        },
        {
          label: "Disabled",
          value: "false",
        }
      ],
    },
  };
  productsList: any = [];
  showDeleteModal: boolean = false;
  selectedProduct: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100]

  @Select((state: any) => state.products.productsList)
  productsList$!: Observable<any>;
  @Select((state: any) => state.products.paginationProducts.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.products.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.products.paginationProducts.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.products.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  productsFormGroup!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder,
    private productsService: ProductsService, private linkedproductService: LinkedProductsService) {
    this.productsFormGroup = this.fb.group({
      name: [null, [Validators.required]],
      parent: [null],
      featured: [false],
      showInMenu: [false],
      enabled: [true],
    })
  }
  async ngOnInit() {
    this.getProductCategoryList();
    this.store.dispatch(new GetProductsList(''))

  }

  getProductCategoryList(): void {
    console.log('hiojjoijijio');
    this.linkedproductService.getLinkedProductCategoryList('true').subscribe((res: any) => {
      let ProductCategoryList = [];
      if (res && res.length > 0) {
        ProductCategoryList = res;
        ProductCategoryList.forEach((e: any) => {
          let obj = {
            label: e.displayName,
            value: e.id.toString()
          };
          this.optionsList.push(obj);
          console.log(this.optionsList);

        });
      }
    })

  }

  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = '';
      this.store.dispatch([new ChangeProductsPage(1), new GetProductsList('')]);
    } else if (this.activetabIndex === 1) {
      this.tabStatus = true;
      this.store.dispatch([new ChangeProductsPage(1), new GetProductsList(true)]);
    } else {
      this.tabStatus = false;
      this.store.dispatch([new ChangeProductsPage(1), new GetProductsList(false)]);
    }
  }


  submitForm(): void {
    if (this.validateForm.valid) {
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  onChange(result: Date): void {
    // console.log('onChange: ', result);
  }

  // async ngOnInit() {
  //   console.log(123)
  // }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeProductsPage(page), new GetProductsList(this.tabStatus)])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateProductsStatus(id, event)])
  }

  filtersFormSubmit(event: any) {
    if(event.categoryId){
       event.categoryIds = [event.categoryId]       
    }
    this.store.dispatch(new GetProductsWithFilters(event, this.tabStatus))
  }

  updateProduct(value: any, data: any, type: string) {
    let updatedObj = { ...data };
    // const date = new Date();
    // const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
    // const day = String(date.getDate()).padStart(2, '0');
    // const month = String(date.getMonth() + 1).padStart(2, '0');
    // const year = String(date.getFullYear());
    // const lastUpdated = `${day}-${month}-${year}`;
    // if (type == 'featured') {
    //   updatedObj.featured = value;
    // } else if (type == 'showInMenu') {
    //   updatedObj.showInMenu = value;
    // } else if (type == 'enabled') {
    //   updatedObj.enabled = value;
    // // }

    // updatedObj.lastUpdatedOn = lastUpdatedOn;
    // updatedObj.lastUpdated = lastUpdated;
    this.store.dispatch([new UpdateProductsStatus(updatedObj.id, value), new GetProductsList(this.tabStatus)])
  }
  editSEO($event: any) {
    // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
  }



 
  Submit(): void {
   


  }

 
  //delete modal functionality
  deleteProduct(products: any) {
    this.selectedProduct = products;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([new DeleteProductsStatus(this.selectedProduct.id), new GetProductsList(this.tabStatus)])

    this.showDeleteModal = false;
  }


}
