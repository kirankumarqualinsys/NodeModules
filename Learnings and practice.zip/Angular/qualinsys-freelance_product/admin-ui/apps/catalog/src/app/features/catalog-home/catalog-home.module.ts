import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CatalogHomeComponent } from './catalog-home.component';
import { RouterModule, Routes } from '@angular/router';

import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzDividerModule } from 'ng-zorro-antd/divider';

const routes: Routes = [
  {
    path: '',
    component: CatalogHomeComponent,
    children: [
      {
        path: '',
        redirectTo: 'products',
        pathMatch: 'full'
      },
      {
        path: 'products',
        loadChildren: () =>
          import('../products/products.module').then(m => m.ProductsModule)
      },
      {
        path: 'collections',
        loadChildren: () =>
          import('../collections/collections.module').then(m => m.CollectionsModule)
      },
      {
        path: 'categories',
        loadChildren: () =>
          import('../categories/categories.module').then(m => m.CategoriesModule)
      },
      {
        path: 'brands',
        loadChildren: () =>
          import('../brands/brands.module').then(m => m.BrandsModule)
      },
      {
        path: 'linked-products',
        loadChildren: () =>
          import('../linked-products/linked-products.module').then(m => m.LinkedProductsModule)
      }
    ]
  }
];
@NgModule({
  declarations: [CatalogHomeComponent],
  imports: [CommonModule,
    RouterModule.forChild(routes),
    NzLayoutModule,
    NzSliderModule,
    NzMenuModule,
    NzDividerModule,
  ],
})
export class CatalogHomeModule { }
