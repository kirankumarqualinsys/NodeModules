export class GetlinkedProdcutsList {
    static readonly type = '[LinkedProducts] Get LinkedProducts';
    constructor(public status: any) { }
}

export class GetLinkedProductsWithFilters {
    static readonly type = '[LinkedProducts] Get LinkedProducts With Filters';
    constructor(public readonly paylaod: any, public readonly status: string) { }
  }

export class ChangeLinkedProductsPage {
    static readonly type = '[LinkedProducts] Change LinkedProducts Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdateLinkedProductsStatus {
    static readonly type = '[LinkedProducts] Update LinkedProducts Status';
    constructor(public readonly id: number, public readonly value: any) { }
}
export class AddLinkedProductsStatus {
    static readonly type = '[LinkedProducts] Add LinkedProducts Status';
    constructor(public readonly data: any) { }
}
export class EditLinkedProductsStatus {
    static readonly type = '[LinkedProducts] Edit LinkedProducts Status';
    constructor(public readonly id: number, public data: any) { }
}
export class DeleteLinkedProductsStatus {
    static readonly type = '[LinkedProducts] Delete LinkedProducts Status';
    constructor(public readonly id: number) { }
}