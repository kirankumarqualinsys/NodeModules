import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.less'],
})
export class ProductsComponent {}
