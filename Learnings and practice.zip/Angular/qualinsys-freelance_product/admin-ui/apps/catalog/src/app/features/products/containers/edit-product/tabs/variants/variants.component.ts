import { Component, OnInit, TrackByFunction, Input } from '@angular/core';
import { UntypedFormArray, UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';

import { Observable, Subject, switchMap, take, takeUntil } from 'rxjs';
import { AddVariantsStatus, AddVariantOptions, ChangeVariantsPage, EditVariantsStatus, GetVariantsList, GetVariantsWithFilters, UpdateVariantsStatus, GetVariantsOptionsList, DeleteVariantOptions } from '../../../../../state/variants.action';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { VariantsService } from 'apps/catalog/src/app/services/variants.service';

export interface Data {
  name: string;
  lastUpdatedOn: null;

}

@Component({
  selector: 'commerceq-admin-ui-variants',
  templateUrl: './variants.component.html',
  styleUrls: ['./variants.component.less'],
})
export class VariantsComponent {
  activetabIndex = 0;
  tabStatus: any = true;
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'large';
  optionsList: any = [{
    label: "Select Option",
    value: "",
  }]

  variantsList: any = [];
  variantOptionsList: any = [];
  showDeleteModal: boolean = false;
  selectedvariant: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100]
  @Input() id: any;
  @Select((state: any) => state.variants.variantsList)
  variantsList$!: Observable<any>;

  @Select((state: any) => state.variants.variantsOptionsList)
  variantsOptionsList$!: Observable<any>;

  @Select((state: any) => state.variants.paginationVariants.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.variants.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.variants.paginationVariants.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.variants.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  variantFormGroup!: UntypedFormGroup;
  addVariantForm!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder, private addfb: UntypedFormBuilder,
    private variantsService: VariantsService,) {
    this.form = this.fb.group({
      controls: this.fb.array([])
    });
    this.variantFormGroup = this.fb.group({
      value: [null],

    });

    this.addVariantForm = this.addfb.group({
      // maximumOnlineStock: [null, [Validators.required]],
      // minimumOrderQuantity: [null, [Validators.required]],
      // uom: [null, [Validators.required]],
      // salesTax: [null, [Validators.required]],
      // taxable: [null, [Validators.required]],
      // name: [null, [Validators.required]],
      // trackInventory: [false],
      // supplyPrice: [null, [Validators.required]],
      // retailPrice: [null, [Validators.required]],
      // comparePrice: [null, [Validators.required]],


      "maximumOnlineStock": [null, [Validators.required]],
      "minimumOrderQuantity": [null, [Validators.required]],
      "uom":[null, [Validators.required]],
      "salesTax": [null],
      "selleable": [null],
      "comparePrice":[null, [Validators.required]],
      "discountPercentage": [null],
      "markupPercentage": [null],
      "name": [null],
      "productId": [null],
      "purchasable": [null],
      "retailPrice": [null, [Validators.required]],      
      "supplyPrice": [null, [Validators.required]],
      "taxable": [null],
      "weight": [null],
      "optionValues": [null],
    })
  }
  async ngOnInit() {
    // this.getVariantsList();
    this.store.dispatch(new GetVariantsList('', this.id))

  }

  getVariantsList(): void {
    console.log('hiojjoijijio');
    // this.linkedproductService.getLinkedProductCategoryList('true').subscribe((res: any) => {
    //   let ProductCategoryList = [];
    //   if (res && res.length > 0) {
    //     ProductCategoryList = res;
    //     ProductCategoryList.forEach((e: any) => {
    //       let obj = {
    //         label: e.name,
    //         value: e.id.toString()
    //       };
    //       this.optionsList.push(obj);
    //       console.log(this.optionsList);

    //     });
    //   }
    // })

  }

  submitForm(): void {
    if (this.validateForm.valid) {
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  onChange(result: Date): void {
    // console.log('onChange: ', result);
  }

  // async ngOnInit() {
  //   console.log(123)
  // }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeVariantsPage(page), new GetVariantsList(this.tabStatus, this.id)])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateVariantsStatus(id, event)])
  }

  filtersFormSubmit(event: any) {
    if (event.categoryId) {
      event.categoryIds = [event.categoryId]
    }
    this.store.dispatch(new GetVariantsWithFilters(event, this.tabStatus))
  }

  updateVariant(value: any, data: any, type: string) {
    let updatedObj = { ...data };
    const date = new Date();
    const lastUpdatedOn = date.toISOString().replace("Z", "+00:00");
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = String(date.getFullYear());
    const lastUpdated = `${day}-${month}-${year}`;
    if (type == 'featured') {
      updatedObj.featured = value;
    } else if (type == 'showInMenu') {
      updatedObj.showInMenu = value;
    } else if (type == 'enabled') {
      updatedObj.enabled = value;
    }

    updatedObj.lastUpdatedOn = lastUpdatedOn;
    updatedObj.lastUpdated = lastUpdated;
    this.store.dispatch([new UpdateVariantsStatus(updatedObj.id, updatedObj), new GetVariantsList(this.tabStatus, this.id)])
  }
  editSEO($event: any) {
    // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
  }

  // Submit(): void {

  // }

  //modal functionality
  isVisible = false;
  title: string = 'Variant Options';
  private unsubscribe$ = new Subject<void>();
  async showModal(type: string, categoryData?: any): Promise<void> {
    this.store.dispatch([new GetVariantsOptionsList(this.id)]);
    // Wait for the action completion
    this.loading$?.pipe(
      takeUntil(this.unsubscribe$)
    ).subscribe(loading => {
      if (loading) {
        // Show loading indicator or perform necessary actions while loading
        console.log('Loading...');
      } else {
        // Loading completed

        this.populateFormArray();
      }
    });


    // Action completed
    console.log('Dispatch completed!');

    this.selectedvariant = categoryData;
    if (type == 'Add') {
      this.title = 'Variant Options';
      this.variantFormGroup.reset();
    } else {
      this.title = 'Edit New Variant Option';
      // this.variantFormGroup.controls['option'].setValue(categoryData.option); 

    }
    this.isVisible = true;
  }

  isVariantVisible = false;
  varianttitle: string = 'Add Variants';
  buttonTitle: any;
  showAddVariantModal(type: string, categoryData?: any): void {
    this.store.dispatch([new GetVariantsOptionsList(this.id)])
    if (type == 'Add') {
      this.varianttitle = 'Add Variants';
      this.buttonTitle = 'Save Details';
      this.addVariantForm.reset();
    } else {
      this.varianttitle = 'Edit New Variant';
      this.buttonTitle = 'Update Details';
      this.store.dispatch([new EditVariantsStatus(this.id, categoryData)]);
      this.addVariantForm.controls['maximumOnlineStock'].setValue(categoryData.maximumOnlineStock);
      this.addVariantForm.controls['minimumOrderQuantity'].setValue(categoryData.minimumOrderQuantity);
      this.addVariantForm.controls['uom'].setValue(categoryData.uom);
      this.addVariantForm.controls['salesTax'].setValue(categoryData.salesTax);
      this.addVariantForm.controls['taxable'].setValue(categoryData.taxable);
      // this.addVariantForm.controls['trackInventory'].setValue(categoryData.trackInventory);
      this.addVariantForm.controls['supplyPrice'].setValue(categoryData.supplyPrice);
      this.addVariantForm.controls['retailPrice'].setValue(categoryData.retailPrice);
      this.addVariantForm.controls['comparePrice'].setValue(categoryData.comparePrice);
      // this.addVariantForm.controls['quantity'].setValue(categoryData.quantity);
    }
    this.isVariantVisible = true;
  }


  Submit(): void {
    if (this.form.valid) {
      if (this.title == 'Variant Options') {
        // this.logFormChanges();
        let array: any = [];
        this.form.value.controls.forEach((ele: any) => {
          if (ele.id == '') {
            array.push(ele.value);
          }
        });
        console.log(array);

        this.store.dispatch([new AddVariantOptions(array, this.id), new GetVariantsOptionsList(this.id)])
        this.isVisible = false;
      } else {
        let categoryObj = { ...this.selectedvariant };
        categoryObj.name = this.form.value.option;
        this.isVisible = false;
      }
      this.Cancel();
    } else {
      // Object.values(this.categoryFormGroup.controls).forEach(control => {
      //   if (control.invalid) {
      //     control.markAsDirty();
      //     control.updateValueAndValidity({ onlySelf: true });
      //   }
      // });
    }


  }

  AddVariantSubmit(): void {
    if (this.addVariantForm.valid) {
      if (this.varianttitle == 'Add Variants') {
        this.store.dispatch([new AddVariantsStatus(this.addVariantForm.value, this.id), new GetVariantsList(this.tabStatus, this.id)])
        this.isVariantVisible = false;
      } else {
        // let categoryObj = { ...this.selectedvariant };     
        // categoryObj.name = this.addVariantForm.value.option;
        // this.isVariantVisible = false;
      }
      this.Cancel();
    } else {
      // Object.values(this.categoryFormGroup.controls).forEach(control => {
      //   if (control.invalid) {
      //     control.markAsDirty();
      //     control.updateValueAndValidity({ onlySelf: true });
      //   }
      // });
    }


  }





  Cancel(): void {
    this.isVisible = false;
  }
  CancelModal(): void {
    this.isVariantVisible = false;
  }

  // delete modal functionality
  deleteVariantOptions(category: any) {
    this.selectedvariant = category;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch(new DeleteVariantOptions(this.id, this.selectedvariant.id));

    setTimeout(() => {
      this.store.dispatch(new GetVariantsOptionsList(this.id));
    }, 2000);

    this.loading$?.pipe(
      takeUntil(this.unsubscribe$)
    ).subscribe(loading => {
      if (loading) {
        // Show loading indicator or perform necessary actions while loading
        console.log('Loading...');
      } else {
        this.populateFormArray();
      }
    });
    this.showDeleteModal = false;
  }

  SaveOptions() {

  }


  //model for 
  form: UntypedFormGroup;
  get controlArray(): UntypedFormArray {
    return this.form.get('controls') as UntypedFormArray;
  }

  populateFormArray(): void {
    this.form.reset();
    let list: any = [];
    this.variantsOptionsList$.subscribe((data: any) => {
      list = data
    });
    console.log(list);

    const controlGroups = list.map((value: any) => this.fb.group({
      value: [value.name, Validators.required],
      id: [value.id]
    }));
    const controlArray = this.fb.array(controlGroups);
    this.form.setControl('controls', controlArray);

  }
  addFormControl(): void {
    this.controlArray.push(this.fb.group({
      value: ['', Validators.required],
      id: ''
    }));

  }

  removeFormControl(index: number, control: any): void {
    this.selectedvariant = control.value;
    if (this.selectedvariant.id) {
      this.showDeleteModal = true;
    } else {
      this.controlArray.removeAt(index);
    }

  }
  previousFormValue: any;


}

