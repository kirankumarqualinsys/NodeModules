import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddVariantsStatus,AddVariantOptions, ChangeVariantsPage, EditVariantsStatus, GetVariantsList, GetVariantsWithFilters, UpdateVariantsStatus , GetVariantsOptionsList , DeleteVariantOptions } from './variants.action';
import { VariantsService } from '../../services/variants.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface VariantsStateModel {
    [x: string]: any;
    varianttsList: [];
    paginationVariants: IPage;
    total: number;
    loading: boolean;
}
@State<VariantsStateModel>({
    name: 'variants',
    defaults: {
        varianttsList: [],
        paginationVariants: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class VariantsState implements NgxsOnInit {
    constructor(private variantsService: VariantsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetVariantsList)
    getVariantsList({ getState, patchState }: StateContext<VariantsStateModel>, action: GetVariantsList) {
        const { paginationVariants } = getState();
        patchState({ loading: true })
        return this.variantsService.getVariants(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    const variantsList = result;
                    console.log('variantsList',variantsList);
                    const total = result.totalElements;
                    patchState({
                        variantsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeVariantsPage)
    changeVariantsPage({ patchState, getState }: StateContext<VariantsStateModel>, action: ChangeVariantsPage) {
        patchState({ paginationVariants: { ...getState().paginationVariants, page: action.paylaod } })
    }

    @Action(GetVariantsWithFilters)
    getVariantsWithFilters({ getState, patchState }: StateContext<VariantsStateModel>, action: GetVariantsWithFilters) {
        const { paginationVariants } = getState();
        patchState({ loading: true })
        return this.variantsService.getVariantsWithFilters(action.paylaod, action.status, paginationVariants).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const variantsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        variantsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(AddVariantsStatus)
    addVariantsStatus({ patchState }: StateContext<VariantsStateModel>, action: AddVariantsStatus) {
        patchState({ loading: true })
        return this.variantsService.addVariantsStatus(action.data, action.id).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(UpdateVariantsStatus)
    UpdateVariantsStatus({ patchState }: StateContext<VariantsStateModel>, action: UpdateVariantsStatus) {
        patchState({ loading: true })
        return this.variantsService.updateVariantsStatus(action.id,action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(EditVariantsStatus)
    editVariantsStatus({ patchState }: StateContext<VariantsStateModel>, action: EditVariantsStatus) {
        patchState({ loading: true })
        return this.variantsService.editVariantsStatus(action.id, action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    // add variant options

    @Action(AddVariantOptions)
    addVariantOptions({ patchState }: StateContext<VariantsStateModel>, action: AddVariantOptions) {
        patchState({ loading: true })
        return this.variantsService.addVariantOptions(action.payload, action.id,).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }

// GetVariantsOptionsList , DeleteVariantOptions

@Action(DeleteVariantOptions)
deleteVariantOptions({ patchState }: StateContext<VariantsStateModel>, action: DeleteVariantOptions) {
    patchState({ loading: true })
    return this.variantsService.deleteVariantOptions(action.productid,action.id).pipe(
        take(1),
        tap((result: any) => {
            if (result) {
                patchState({
                    loading: false
                });
            }
        })
    )
}

@Action(GetVariantsOptionsList)
getVariantsOptionsList({ getState, patchState }: StateContext<VariantsStateModel>, action: GetVariantsOptionsList) {
    const { paginationVariants } = getState();
    patchState({ loading: true })
    return this.variantsService.getVariantOptions(action.id).pipe(
        take(1),
        tap((result: any) => {
            if (result) {
                const variantsOptionsList = result;
                console.log('variantsOptionsList',variantsOptionsList);
                const total = result.totalElements;
                patchState({
                    variantsOptionsList,
                    total,
                    loading: false
                });
            }
        })
    );
}

}