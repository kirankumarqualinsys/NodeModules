import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { AddLinkedProductsStatus, ChangeLinkedProductsPage, GetlinkedProdcutsList, GetLinkedProductsWithFilters, UpdateLinkedProductsStatus, DeleteLinkedProductsStatus, EditLinkedProductsStatus } from '../../../state/linkedproudcts.action';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { LinkedProductsService } from 'apps/catalog/src/app/services/linked-products.service';

@Component({
  selector: 'commerceq-admin-ui-linked-prodcuts-list',
  templateUrl: './linked-prodcuts-list.component.html',
  styleUrls: ['./linked-prodcuts-list.component.less'],
})
export class LinkedProdcutsListComponent {

  tabs = ['All', 'Enabled', 'Disabled'];
  activetabIndex = 0;
  tabStatus: any = '';
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'large';
  optionsList: any = [{
    label: "Select Option",
    value: "",
  }]
  linkedproductsFilterFields = {
    productName: {
      type: "text",
      value: "",
      label: "Product Name",
      span: "4"
    },
    productCategoryId: {
      type: "select",
      value: "",
      label: "Product Category",
      span: "5",
      options: this.optionsList,
    },
    linkedProductName: {
      type: "text",
      value: "",
      label: "Linked Product Name",
      span: "4"
    },
    linkedProductCategoryId: {
      type: "select",
      value: "",
      label: "Linked Product Category",
      span: "5",
      options: this.optionsList,
    },
    type: {
      type: "select",
      value: "",
      label: "Linked Type",
      span: "5",
      options:  [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Related",
          value: "RELATED",
        },
        {
          label: "Cross Sale",
          value: "CROSS_SALE",
        },
        {
          label: "Up Sale",
          value: "UP_SALE",
        },
        
      ],
    },
  };
  linkedProductList: any = [];
  showDeleteModal: boolean = false;
  selectedCategory: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100];

  @Select((state: any) => state.linkedproducts.linkedProductList)
  linkedProductList$!: Observable<any>;
  @Select((state: any) => state.linkedproducts.paginationLinkedProducts.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.paginationLinkedProducts.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  linkedproductFormGroup!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder,
    private linkedproductService: LinkedProductsService) {
    this.linkedproductFormGroup = this.fb.group({
      productName: [null, [Validators.required]],
      orderNumber: [null, [Validators.required]],
      type: [null],
    });

  }
  async ngOnInit() {
    this.getLinkedProductCategoryList();
    this.store.dispatch(new GetlinkedProdcutsList(''));


  }

  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = '';
      this.store.dispatch([new ChangeLinkedProductsPage(1), new GetlinkedProdcutsList('')]);
    } else if (this.activetabIndex === 1) {
      this.tabStatus = true;
      this.store.dispatch([new ChangeLinkedProductsPage(1), new GetlinkedProdcutsList(true)]);
    } else {
      this.tabStatus = false;
      this.store.dispatch([new ChangeLinkedProductsPage(1), new GetlinkedProdcutsList(false)]);
    }
  }


  submitForm(): void {
    if (this.validateForm.valid) {
    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  onChange(result: Date): void {
    // console.log('onChange: ', result);
  }

  // async ngOnInit() {
  //   console.log(123)
  // }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeLinkedProductsPage(page), new GetlinkedProdcutsList(this.tabStatus)])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateLinkedProductsStatus(id, event)])
  }

  filtersFormSubmit(event: any) {
    for (const key in event) {
      if (event[key] == null || event[key] == '' ) {
        delete event[key];
      }
    }
    this.store.dispatch(new GetLinkedProductsWithFilters(event, this.tabStatus))
  }

  updateCategory(value: any, data: any) {
    console.log(value);
    
    this.store.dispatch([new UpdateLinkedProductsStatus(data.id, value), new GetlinkedProdcutsList(this.tabStatus)])
  }
  editSEO($event: any) {
    // this.store.dispatch(new GetCollectionsList($event, this.tabStatus))
  }

  //auto complete for parent
  linkedProductCategoryList: any = [];

  getLinkedProductCategoryList(): void {
    console.log('hiojjoijijio');
    this.linkedproductService.getLinkedProductCategoryList('true').subscribe((res: any) => {
      this.linkedProductCategoryList = [];
      if (res && res.length > 0) {
        this.linkedProductCategoryList = res;
        this.linkedProductCategoryList.forEach((e: any) => {
          let obj = {
            label: e.displayName,
            value: e.id.toString()
          };
          this.optionsList.push(obj);
          console.log(this.optionsList);

        });
      }
    })

  }

  //modal functionality
  isVisible = false;
  title: string = 'Add Category';

  showModal(type: string, categoryData?: any): void {
    this.selectedCategory = categoryData;
    if (type == 'Add') {
      this.title = 'Add Category';
      this.linkedproductFormGroup.reset();
    } else {
      this.title = 'Edit Linked Product';
      console.log('cat data',categoryData);
      this.linkedproductFormGroup.controls['productName'].setValue(categoryData.linkedProduct?.productName);
      this.linkedproductFormGroup.controls['productName'].disable();
      this.linkedproductFormGroup.controls['type'].setValue(categoryData.type?.key);
      this.linkedproductFormGroup.controls['orderNumber'].setValue(categoryData?.orderNumber);
    }
    this.isVisible = true;
  }

  Submit(): void {
    if (this.linkedproductFormGroup.valid) {
      if (this.title == 'Add Category') {
        this.store.dispatch([new AddLinkedProductsStatus(this.linkedproductFormGroup.value), new GetlinkedProdcutsList(this.tabStatus)])
        this.isVisible = false;
      } else {
        let categoryObj = { ...this.selectedCategory }
        // let parent = (typeof this.linkedproductFormGroup.value.parent === 'object' && this.linkedproductFormGroup.value.parent !== null) ? this.linkedproductFormGroup.value.parent : null;
        // if (parent != null) {
        //   categoryObj.parentId = parent.id;
        // }
        categoryObj.productName = this.linkedproductFormGroup.value.productName;
        categoryObj.type = this.linkedproductFormGroup.value.type;
        categoryObj.orderNumber = this.linkedproductFormGroup.value.orderNumber;
        let obj = {id:categoryObj?.id,orderNumber:categoryObj.orderNumber,priority:categoryObj.orderNumber,type:categoryObj.type};
        this.store.dispatch([new EditLinkedProductsStatus(categoryObj.id, obj), new GetlinkedProdcutsList(this.tabStatus)])
        this.isVisible = false;
      }
      this.Cancel();
    } else {
      Object.values(this.linkedproductFormGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }


  }

  Cancel(): void {
    this.isVisible = false;
  }

  //delete modal functionality
  deleteCategory(category: any) {
    this.selectedCategory = category;
    this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([new DeleteLinkedProductsStatus(this.selectedCategory.id), new GetlinkedProdcutsList(this.tabStatus)])

    this.showDeleteModal = false;
  }


}
