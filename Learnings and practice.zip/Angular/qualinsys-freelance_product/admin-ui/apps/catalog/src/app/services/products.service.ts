import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getProducts(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/products/v2/search`;
    const data = {
      status:"",
      enabled: payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)

  }

  getProductsWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/products/v2/search`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  updateProductsStatus(id: number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}/update-status/${data}`;
    return this.http.put(url, data)
  }
  addProductsStatus( data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/products`;
   
    return this.http.post(url, data);
  }
  editProductsStatus(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}`;
   
    return this.http.put(url, data);
  }
  getProductsStatusById(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}`;
   
    return this.http.get(url, data);
  }
  deleteProductsStatus( id:number) {
    const url = `${this.environment.apiUrl}/catalog/api/products/${id}`;
   
    return this.http.delete(url);
  }

  getsalesChannelsList() {
    const url = `${this.environment.apiUrl}/store/api/v1/stores/97932177/sales-channels`;
   
    return this.http.get(url);
  }


}
