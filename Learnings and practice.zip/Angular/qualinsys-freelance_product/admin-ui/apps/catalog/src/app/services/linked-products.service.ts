import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/collections.state';

@Injectable({
  providedIn: 'root'
})
export class LinkedProductsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getLinkedProducts(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/search`;
    console.log('urliiiii',url);
    const data = {     
      enabled: payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }

  getLinkedProductsWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/search`;
    const data = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  updateLinkedProductsStatus(id: number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/${id}/${data}`;
    return this.http.put(url,data);
  }
  addLinkedProductsStatus( data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products`;
   
    return this.http.post(url, data);
  }
  editLinkedProductsStatus(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/${id}`;
   
    return this.http.put(url, data);
  }
  deleteLinkedProductsStatus( id:number) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/${id}`;
   
    return this.http.delete(url);
  }

  getParent(query: string) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/autocompleter?query=${query}`;
    return this.http.get(url)
  }

  getLinkedProductCategoryList(query: string) {
    console.log('hiojjoijijio');
    const url = `${this.environment.apiUrl}/catalog/api/catalog/categories/list?loadChilds=true`;
    return this.http.get(url)
  }

  addLinkedProducts(id:number, data:any) {
    const url = `${this.environment.apiUrl}/catalog/api/linked-products/${id}`;
   
    return this.http.post(url, data);
  }
}



