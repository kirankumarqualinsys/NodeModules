import { TestBed } from '@angular/core/testing';

import { LinkedProductsService } from './linked-products.service';

describe('LinkedProductsService', () => {
  let service: LinkedProductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LinkedProductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
