import { Route } from "@angular/router";

export const appRoutes: Route[] = [
  {
    path: '',
    loadChildren: () =>
      import('./features/catalog-home/catalog-home.module').then(m => m.CatalogHomeModule)
  }
];
