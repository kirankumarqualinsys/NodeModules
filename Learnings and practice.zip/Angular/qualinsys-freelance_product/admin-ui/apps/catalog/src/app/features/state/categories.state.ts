import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddCategoriesStatus, ChangeCategoriesPage, DeleteCategoriesStatus, EditCategoriesStatus, GetCategoriesList, GetCategoriesWithFilters, UpdateCategoriesStatus } from './categories.action';
import { CategoriesService } from '../../services/categories.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface CategoriesStateModel {
    [x: string]: any;
    categoriesList: [];
    paginationCategories: IPage;
    total: number;
    loading: boolean;
}
@State<CategoriesStateModel>({
    name: 'categories',
    defaults: {
        categoriesList: [],
        paginationCategories: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class CategoriesState implements NgxsOnInit {
    constructor(private categoriesService: CategoriesService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetCategoriesList)
    getCategoriesList({ getState, patchState }: StateContext<CategoriesStateModel>, action: GetCategoriesList) {
        const { paginationCategories } = getState();
        patchState({ loading: true })
        return this.categoriesService.getCategories(action.status, paginationCategories).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const categoriesList = result.content;
                    const total = result.totalElements;
                    patchState({
                        categoriesList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeCategoriesPage)
    changeCategoriesPage({ patchState, getState }: StateContext<CategoriesStateModel>, action: ChangeCategoriesPage) {
        patchState({ paginationCategories: { ...getState().paginationCategories, page: action.paylaod } })
    }

    @Action(GetCategoriesWithFilters)
    getCategoriesWithFilters({ getState, patchState }: StateContext<CategoriesStateModel>, action: GetCategoriesWithFilters) {
        const { paginationCategories } = getState();
        patchState({ loading: true })
        return this.categoriesService.getCategoriesWithFilters(action.paylaod, action.status, paginationCategories).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const categoriesList = result.content;
                    const total = result.totalElements;
                    patchState({
                        categoriesList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(AddCategoriesStatus)
    addCategoriesStatus({ patchState }: StateContext<CategoriesStateModel>, action: AddCategoriesStatus) {
        patchState({ loading: true })
        return this.categoriesService.addCategoriesStatus(action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(UpdateCategoriesStatus)
    UpdateCategoriesStatus({ patchState }: StateContext<CategoriesStateModel>, action: UpdateCategoriesStatus) {
        patchState({ loading: true })
        return this.categoriesService.updateCategoriesStatus(action.id,action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(EditCategoriesStatus)
    editCategoriesStatus({ patchState }: StateContext<CategoriesStateModel>, action: EditCategoriesStatus) {
        patchState({ loading: true })
        return this.categoriesService.editCategoriesStatus(action.id, action.data).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
    @Action(DeleteCategoriesStatus)
    deleteCategoriesStatus({ patchState }: StateContext<CategoriesStateModel>, action: DeleteCategoriesStatus) {
        patchState({ loading: true })
        return this.categoriesService.deleteCategoriesStatus(action.id).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }
}