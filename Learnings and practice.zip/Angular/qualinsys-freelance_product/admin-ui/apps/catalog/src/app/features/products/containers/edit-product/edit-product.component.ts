import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { GetOrderDetails } from 'apps/sales/src/app/state/order.action';
import { OrderStateSelectors } from 'apps/sales/src/app/state/order.selector';
import { Observable } from 'rxjs';
import { ProductsStateSelectors } from '../../../state/products.selectors';


@Component({
  selector: 'commerceq-admin-ui-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.less'],
})
export class EditProductComponent implements OnInit {
  tabs = [{ value: 'general-details', displayValue: 'General Details' },
  { value: 'variants', displayValue: 'Variants' },
  { value: 'linked-products', displayValue: 'Linked Products' },
  ];
  selectedTabIndex = 0;
  selectedTab = 'general-details';
  id:any;
  @Select(ProductsStateSelectors.productsList)
  productsList$: Observable<any> | undefined
  constructor(private store: Store, private readonly route: ActivatedRoute) { }
  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');
    
    // if (this.id) {
    //   this.store.dispatch(new GetOrderDetails(id))
    // }
  }
  selectTab(key: string, index: number) {
    this.selectedTab = key;
    this.selectedTabIndex = index;
  }
}
