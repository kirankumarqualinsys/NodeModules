import { Component, ChangeDetectionStrategy, OnInit, TrackByFunction, Input } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { Observable } from 'rxjs';
import { NzButtonSize } from 'ng-zorro-antd/button';
import { LinkedProductsService } from 'apps/catalog/src/app/services/linked-products.service';
import { GetLinkedProductsWithFilters,AddLinkedProductsStatus, ChangeLinkedProductsPage, GetlinkedProdcutsList, UpdateLinkedProductsStatus, DeleteLinkedProductsStatus, EditLinkedProductsStatus  } from 'apps/catalog/src/app/features/state/linkedproudcts.action';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';
import { CommonProductModalComponent } from '../../common-product-modal/common-product-modal.component';

@Component({
  selector: 'commerceq-admin-ui-linked-products',
  templateUrl: './linked-products.component.html',
  styleUrls: ['./linked-products.component.less'],
})
export class LinkedProductsComponent {
  @Input() id: any;
  date = null;
  validateForm!: UntypedFormGroup;
  size: NzButtonSize = 'large';
  optionsList: any = [{
    label: "Select Option",
    value: "",
  }]
  linkedproductsFilterFields = {
   
    linkedProductName: {
      type: "text",
      value: "",
      label: "Linked Product Name",
      span: "6"
    },
    linkedProductCategoryId: {
      type: "select",
      value: "",
      label: "Linked Product Category",
      span: "6",
      options: this.optionsList,
    },
    type: {
      type: "select",
      value: "",
      label: "Linked Type",
      span: "6",
      options:  [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Related",
          value: "RELATED",
        },
        {
          label: "Cross Sale",
          value: "CROSS_SALE",
        },
        {
          label: "Up Sale",
          value: "UP_SALE",
        },
        
      ],
    },
    enabled: {
      type: "select",
      value: "",
      label: "Status",
      span: "6",
      options: [
        {
          label: "Select Option",
          value: "",
        },
        {
          label: "Enabled",
          value: "true",
        },
        {
          label: "Disabled",
          value: "false",
        }
      ],
    },
  };
  linkedProductList: any = [];
  showDeleteModal: boolean = false;
  selectedCategory: any = {};
  enabledValues = [
    { key: true, name: 'Enable' },
    { key: false, name: 'Disable' }
  ]
  public paginationLimit = [10, 20, 50, 100];

  @Select((state: any) => state.linkedproducts.linkedProductList)
  linkedProductList$!: Observable<any>;
  @Select((state: any) => state.linkedproducts.paginationLinkedProducts.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.paginationLinkedProducts.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.linkedproducts.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  linkedproductFormGroup!: UntypedFormGroup;
  constructor(private store: Store, private fb: UntypedFormBuilder,
    private linkedproductService: LinkedProductsService,
    private readonly modalService: NzModalService) {
    this.linkedproductFormGroup = this.fb.group({
      productName: [null, [Validators.required]],
      orderNumber: [null, [Validators.required]],
      type: [null],
    });

  }
  async ngOnInit() {
    this.getLinkedProductCategoryList();
    this.store.dispatch(new GetLinkedProductsWithFilters({productId:this.id}, ''));


  }


 
  // async ngOnInit() {
  //   console.log(123)
  // }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeLinkedProductsPage(page), new GetLinkedProductsWithFilters({productId:this.id}, '')])
  }
  changeStatus(event: boolean, id: number) {
    this.store.dispatch([new UpdateLinkedProductsStatus(id, event)])
  }

  filtersFormSubmit(event: any) {
    for (const key in event) {
      if (event[key] == null || event[key] == '' ) {
        delete event[key];
      }
      }
      event.productId = this.id.toString();
    this.store.dispatch(new GetLinkedProductsWithFilters(event, ''))
  }

  updateCategory(value: any, data: any) {
    console.log(value);
    
    this.store.dispatch([new UpdateLinkedProductsStatus(data.id, value), new GetLinkedProductsWithFilters({productId:this.id}, '')])
  }
  editSEO($event: any) {
    // this.store.dispatch(new GetCollectionsList($event, ''))
  }

  //auto complete for parent
  linkedProductCategoryList: any = [];

  getLinkedProductCategoryList(): void {
    console.log('hiojjoijijio');
    this.linkedproductService.getLinkedProductCategoryList('true').subscribe((res: any) => {
      this.linkedProductCategoryList = [];
      if (res && res.length > 0) {
        this.linkedProductCategoryList = res;
        this.linkedProductCategoryList.forEach((e: any) => {
          let obj = {
            label: e.displayName,
            value: e.id.toString()
          };
          this.optionsList.push(obj);
          console.log(this.optionsList);

        });
      }
    })

  }

  //modal functionality
  isVisible = false;
  title: string = 'Add Category';

  showModal(type: string, categoryData?: any): void {
    this.selectedCategory = categoryData;
    if (type == 'Add') {
      this.title = 'Add Category';
      this.linkedproductFormGroup.reset();
    } else {
      this.title = 'Edit Linked Product';
      console.log('cat data',categoryData);
      this.linkedproductFormGroup.controls['productName'].setValue(categoryData.linkedProduct?.productName);
      this.linkedproductFormGroup.controls['productName'].disable();
      this.linkedproductFormGroup.controls['type'].setValue(categoryData.type?.key);
      this.linkedproductFormGroup.controls['orderNumber'].setValue(categoryData?.orderNumber);
    }
    this.isVisible = true;
  }

  Submit(): void {
    if (this.linkedproductFormGroup.valid) {
      if (this.title == 'Add Category') {
        this.store.dispatch([new AddLinkedProductsStatus(this.linkedproductFormGroup.value), new GetLinkedProductsWithFilters({productId:this.id}, '')])
        this.isVisible = false;
      } else {
        let categoryObj = { ...this.selectedCategory }
        // let parent = (typeof this.linkedproductFormGroup.value.parent === 'object' && this.linkedproductFormGroup.value.parent !== null) ? this.linkedproductFormGroup.value.parent : null;
        // if (parent != null) {
        //   categoryObj.parentId = parent.id;
        // }
        categoryObj.productName = this.linkedproductFormGroup.value.productName;
        categoryObj.type = this.linkedproductFormGroup.value.type;
        categoryObj.orderNumber = this.linkedproductFormGroup.value.orderNumber;
        let obj = {id:categoryObj?.id,orderNumber:categoryObj.orderNumber,priority:categoryObj.orderNumber,type:categoryObj.type};
        this.store.dispatch([new EditLinkedProductsStatus(categoryObj.id, obj), new GetLinkedProductsWithFilters({productId:this.id}, '')])
        this.isVisible = false;
      }
      this.Cancel();
    } else {
      Object.values(this.linkedproductFormGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }


  }

  Cancel(): void {
    this.isVisible = false;
  }

  //delete modal functionality
  deleteCategory(category: any) {
    // this.selectedCategory = category;
    // this.showDeleteModal = true;
  }
  proceedtoDelete() {
    this.store.dispatch([new DeleteLinkedProductsStatus(this.selectedCategory.id), new GetLinkedProductsWithFilters({productId:this.id}, '')])

    this.showDeleteModal = false;
  }


  //model prodct functionality
  openCommonProductModal(title:string, type:string) {
    const modal: NzModalRef = this.modalService.create({
      nzTitle: title,
      nzContent: CommonProductModalComponent,
      nzWidth: 850,
      nzComponentParams: {
        modalData: { id: this.id, type: type } // Pass the data to the modal component
      }
      // nzFooter: [
      //   {
      //     label: 'Submit',
      //     type: 'primary',
      //     onClick: async (data) => {
      //       console.log(data, "data")
      //     },
      //   },
      //   {
      //     label: 'Cancel',
      //     type: 'default',
      //     onClick: () => modal.destroy(),
      //   },
      // ],
    });

    modal.afterClose.subscribe(() => {
      // This code will be executed when the modal is closed
      console.log('Modal is closed');
      this.store.dispatch(new GetLinkedProductsWithFilters({productId:this.id}, ''));
      // You can perform any necessary actions here
    });
  }
}
