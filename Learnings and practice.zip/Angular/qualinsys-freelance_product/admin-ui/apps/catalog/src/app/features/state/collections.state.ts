import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { AddCollection, ChangeCollectionsPage, DeleteCollection, EditCollection, GetCollectionsList, UpdateCollectionsStatus } from './collections.action';
import { CollectionsService } from '../../services/collections.service';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface CollectionsStateModel {
    [x: string]: any;
    collectionsList: [];
    paginationCollections: IPage;
    total: number;
    loading: boolean;
}
@State<CollectionsStateModel>({
    name: 'collections',
    defaults: {
        collectionsList: [],
        paginationCollections: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class CollectionsState implements NgxsOnInit {
    constructor(private collectionsService: CollectionsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetCollectionsList)
    getCollectionsList({ getState, patchState }: StateContext<CollectionsStateModel>, action: GetCollectionsList) {
        const { paginationCollections } = getState();
        patchState({ loading: true })
        return this.collectionsService.getCollections(action.status, paginationCollections).pipe(
            take(1),
            tap((result: any) => {
                if (result ) {
                    const collectionsList = result;
                    const total = result.length;
                    patchState({
                        collectionsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeCollectionsPage)
    changeCollectionsPage({ patchState, getState }: StateContext<CollectionsStateModel>, action: ChangeCollectionsPage) {
        patchState({ paginationCollections: { ...getState().paginationCollections, page: action.paylaod } })
    }
    @Action(UpdateCollectionsStatus)
    updateCollectionsStatus({ patchState }: StateContext<CollectionsStateModel>, action: UpdateCollectionsStatus) {
        patchState({ loading: true })
        return this.collectionsService.updateCollectionsStatus(action.id, action.status).pipe(
            take(1),
            tap((result: any) => {
                patchState({
                    loading: false
                });
            })
        );
    }


    @Action(DeleteCollection)
    deleteCollection({ patchState }: StateContext<CollectionsStateModel>, action: DeleteCollection) {
        patchState({ loading: true })
        return this.collectionsService.deleteCollection(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(AddCollection)
    addCollection({ patchState }: StateContext<CollectionsStateModel>, action: AddCollection) {
        patchState({ loading: true })
        return this.collectionsService.addCollection(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
    @Action(EditCollection)
    editCollection({ patchState }: StateContext<CollectionsStateModel>, action: EditCollection) {
        patchState({ loading: true })
        return this.collectionsService.editCollection(action.payload).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    patchState({
                        loading: false
                    });
                }
            })
        )
    }
}