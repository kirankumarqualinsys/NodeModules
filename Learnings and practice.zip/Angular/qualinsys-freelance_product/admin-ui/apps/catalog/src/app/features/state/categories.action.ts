export class GetCategoriesList {
    static readonly type = '[Categories] Get Categories';
    constructor(public status: any) { }
}

export class GetCategoriesWithFilters {
    static readonly type = '[Categories] Get Categories With Filters';
    constructor(public readonly paylaod: any, public readonly status: string) { }
  }

export class ChangeCategoriesPage {
    static readonly type = '[Categories] Change Categories Page';
    constructor(public readonly paylaod: number) { }
}



export class UpdateCategoriesStatus {
    static readonly type = '[Categories] Update Categories Status';
    constructor(public readonly id: number, public readonly data: any) { }
}
export class AddCategoriesStatus {
    static readonly type = '[Categories] Add Categories Status';
    constructor(public readonly data: any) { }
}
export class EditCategoriesStatus {
    static readonly type = '[Categories] Edit Categories Status';
    constructor(public readonly id: number, public data: any) { }
}
export class DeleteCategoriesStatus {
    static readonly type = '[Categories] Delete Categories Status';
    constructor(public readonly id: number) { }
}