import { Selector } from '@ngxs/store';
import {
    ProductsStateModel,
    ProductsState,
} from './products.state';


export class ProductsStateSelectors {
    @Selector([ProductsState])
    static productsList(state: ProductsStateModel) {
        return state['productsList'];
      }
    @Selector([ProductsState])
    static productsListById(state: ProductsStateModel) {
        return state['productsListById'];
      }
    static pageSize(state: ProductsStateModel) {
        return state.paginationProducts.size;
    }
    static total(state: ProductsStateModel) {
        return state.total;
    }
    static pageIndex(state: ProductsStateModel) {
        return state.paginationProducts.page;
    }
    static loading(state: ProductsStateModel) {
        return state.loading;
    }
}