export class GetCollectionsList {
    static readonly type = '[Collections] Get Collections';
    constructor(public status: any) { }
}

export class ChangeCollectionsPage {
    static readonly type = '[Collections] Change Collections Page';
    constructor(public readonly paylaod: number) { }
}

export class UpdateCollectionsStatus {
    static readonly type = '[Collections] Update Collections Status';
    constructor(public readonly id: number, public readonly status: boolean) { }
}

export class DeleteCollection {
    static readonly type = '[Collections] Delete Collection';
    constructor(public readonly id: number) { }
}

export class AddCollection {
    static readonly type = '[Collections] Add Collection';
    constructor(public readonly payload: any) { }
}
export class EditCollection {
    static readonly type = '[Collections] Edit Collection';
    constructor(public readonly payload: any) { }
}