module.exports = {
  name: 'sales',
  exposes: {
    './Module': 'apps/sales/src/app/app.module.ts',
  },
};
