import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { GetAbandonedCheckoutDetails, GetAbandonedCheckoutsList, GetAbandonedCheckoutssWithFilters, ChangeAbandonedCheckoutsPage } from './abandonedCheckouts.action';
import { AbandonedCheckoutsService } from '../services/abandonedCheckouts.service';

export interface IPage {
  size: number;
  page: number;
  filter?: string;
  filterParams?: { value: string[], key: string }[];
  sort?: { key: string, value: string }
}
export interface AbandonedCheckoutStateModel {
  abandonedCheckoutsList: [];
  paginationAbandonedCheckouts: IPage;
  total: number;
  loading: boolean;
  abandonedCheckoutDetails: any;
}
@State<AbandonedCheckoutStateModel>({
  name: 'abandonedCheckoutState',
  defaults: {
    abandonedCheckoutsList: [],
    paginationAbandonedCheckouts: { page: 1, size: 5 },
    total: 0,
    loading: false,
    abandonedCheckoutDetails: undefined,
  },
})
@Injectable()
export class AbandonedCheckoutState implements NgxsOnInit {


  constructor(private abandonedCheckoutsService: AbandonedCheckoutsService, private readonly store: Store) { }
  async ngxsOnInit() {
  }
  @Action(GetAbandonedCheckoutsList)
  getAbandonedCheckoutsList({ getState, patchState }: StateContext<AbandonedCheckoutStateModel>, action: GetAbandonedCheckoutsList) {
    const { paginationAbandonedCheckouts } = getState();
    patchState({ loading: true })
    return this.abandonedCheckoutsService.getAbandonedCheckouts(action.payload, paginationAbandonedCheckouts).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const abandonedCheckoutsList = result.content;
          const total = result.totalElements;
          patchState({
            abandonedCheckoutsList,
            total,
            loading: false
          });
        }
      })
    );
  }
  @Action(ChangeAbandonedCheckoutsPage)
  changeAbandonedCheckoutsListPage({ patchState, getState }: StateContext<AbandonedCheckoutStateModel>, action: ChangeAbandonedCheckoutsPage) {
    patchState({ paginationAbandonedCheckouts: { ...getState().paginationAbandonedCheckouts, page: action.paylaod } })
  }
  @Action(GetAbandonedCheckoutssWithFilters)
  getOrdersWithFilters({ getState, patchState }: StateContext<AbandonedCheckoutStateModel>, action: GetAbandonedCheckoutssWithFilters) {
    const { paginationAbandonedCheckouts } = getState();
    patchState({ loading: true })
    return this.abandonedCheckoutsService.getAbandonedCheckoutsWithFilters(action.paylaod, action.status, paginationAbandonedCheckouts).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const abandonedCheckoutsList = result.content;
          const total = result.totalElements;
          patchState({
            abandonedCheckoutsList,
            total,
            loading: false
          });
        }
      })
    );
  }
  @Action(GetAbandonedCheckoutDetails)
  getAbandonedCheckoutDetails({ patchState }: StateContext<AbandonedCheckoutStateModel>, action: GetAbandonedCheckoutDetails) {
    patchState({ loading: true })
    return this.abandonedCheckoutsService.getAbandonedCheckoutDetails(action.orderId).pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          const abandonedCheckoutsList = result;
          patchState({
            abandonedCheckoutsList,
            loading: false
          });
        }
      })
    );
  }
 
}