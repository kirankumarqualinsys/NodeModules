export class GetShipmentsList {
  static readonly type = '[Shipment] Get Shipments';
  constructor(public payload: any) { }
}

export class ChangeShipmentPage {
  static readonly type = '[Shipment] Change Shipment Page';
  constructor(public readonly paylaod: number) { }
}
// export class GetShipmentsDetails {
//   static readonly type = '[Shipment] Get Shipment Details';
//   constructor(public readonly orderId: any) { }
// }
export class GetShipmentsWithFilters {
  static readonly type = '[Shipment] Get Shipments With Filters';
  constructor(public readonly paylaod: any) { }
}
export class CancelShipment {
  static readonly type = '[Shipment] Cancel Shipment';
  constructor(public readonly orderId: number) { }
}

export class ChangeShipmentStatus {
  static readonly type = '[Shipment] Change Shipment Status';
  constructor(public readonly payload: number, public readonly status: string) {}
}

export class UpdateShipmentStatus {
  static readonly type = '[Shipment] Update Shipment Status';
  constructor(public readonly orderId: number, public readonly status: string) {}
}
