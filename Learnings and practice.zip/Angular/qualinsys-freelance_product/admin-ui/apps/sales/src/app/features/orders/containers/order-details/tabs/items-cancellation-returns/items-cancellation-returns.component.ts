import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-items-cancellation-returns',
  templateUrl: './items-cancellation-returns.component.html',
  styleUrls: ['./items-cancellation-returns.component.less'],
})
export class ItemsCancellationReturnsComponent {}
