export class GetOrdersList {
  static readonly type = '[Orders] Get Orders';
  constructor(public payload: any) { }
}

export class ChangeOrdersPage {
  static readonly type = '[Orders] Change Orders Page';
  constructor(public readonly paylaod: number) { }
}

export class GetOrderssWithFilters {
  static readonly type = '[Orders] Get Orders With Filters';
  constructor(public readonly paylaod: any, public readonly status: string) { }
}

export class GetOrderDetails {
  static readonly type = '[Orders] Get Orders Details';
  constructor(public readonly orderId: any) { }
}

export class GetCancelOrderReasonTypes {
  static readonly type = '[Orders] Get Cancel Order Reason Types';
  constructor() { }
}
export class CancelOrder {
  static readonly type = '[Orders] Cancel Order';
  constructor(public readonly payload: any) { }
}

export class CancelOrderItem {
  static readonly type = '[Orders] Cancel Order Item';
  constructor(public readonly payload: any) { }
}

export class UploadOrderInvoice {
  static readonly type = '[Orders] Upload Order Invoice';
  constructor(public readonly payload: any, public readonly data: any) { }
}

export class CancelShippedOrderItem {
  static readonly type = '[Orders] Cancel Shipped Order Item';
  constructor(public readonly payload: any) { }
}