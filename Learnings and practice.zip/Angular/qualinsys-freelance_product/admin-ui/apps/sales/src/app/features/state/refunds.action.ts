export class GetRefundsList {
    static readonly type = '[Refunds] Get Refunds';
    constructor(public payload: any) { }
}

export class ChangeRefundsPage {
    static readonly type = '[Refunds] Change refunds Page';
    constructor(public readonly paylaod: number) { }
}
export class GetRefundsWithFilters {
    static readonly type = '[Refunds] Get Refunds With Filters';
    constructor(public readonly paylaod: any) { }
}
export class GetRefundsDetails {
    static readonly type = '[Refunds] Get refunds Details';
    constructor(public readonly id: any) { }
}
// new
export class UpdateRefundsDetails {
    static readonly type = '[Refunds] Update refunds Details';
    constructor(public readonly payload: any) { }
}