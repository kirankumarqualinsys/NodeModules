import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { appRoutes } from './app.routes';
import { NgxsModule } from '@ngxs/store';
import { OrderState } from './state/order.state';
import { ShipmentState } from './state/shipment.state';
import { PaymentsState } from './features/state/payments.state';
import { RefundsState } from './features/state/refunds.state';
import { registerLocaleData } from '@angular/common';
import en from '@angular/common/locales/en';
import { AbandonedCheckoutState } from './state/abandonedCheckouts.state';
registerLocaleData(en)

@NgModule({
  declarations: [AppComponent],
  imports: [
    RouterModule.forChild(appRoutes),
    NgxsModule.forFeature([OrderState, ShipmentState,PaymentsState,RefundsState , AbandonedCheckoutState]),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
