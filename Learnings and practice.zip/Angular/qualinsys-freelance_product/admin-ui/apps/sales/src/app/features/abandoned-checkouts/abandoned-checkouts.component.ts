import { Component, OnInit, TrackByFunction } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { GetCustomerDetails } from 'apps/crm/src/app/state/customer.action';
import {  ChangeAbandonedCheckoutsPage,GetAbandonedCheckoutsList, GetAbandonedCheckoutDetails, GetAbandonedCheckoutssWithFilters } from 'apps/sales/src/app/state/abandonedCheckouts.action';
import { AbandonedCheckoutStateSelectors } from 'apps/sales/src/app/state/abandonedCheckouts.selector';
import { CustomersStateSelectors } from 'apps/crm/src/app/state/customer.selectors';
import { NzModalService } from 'ng-zorro-antd/modal';
import { Observable } from 'rxjs';
import { GetOrderDetails } from '../../state/order.action';
import { OrderStateSelectors } from '../../state/order.selector';

@Component({
  selector: 'commerceq-admin-ui-abandoned-checkouts',
  templateUrl: './abandoned-checkouts.component.html',
  styleUrls: ['./abandoned-checkouts.component.less'],
})
export class AbandonedCheckoutsComponent {
  @Select(CustomersStateSelectors.customerDetails)
  customerDetails$: Observable<any> | undefined;
  cancelOrderForm!: UntypedFormGroup;
  showModal = false;
  showCancelReasonTypes = false;
  showAcceptOrderModal = false;
  selectedOrder: any;
  mainTabs = ['All'];
  mainActivetabIndex = 0;
  AbandonedCheckoutsFilterFields = {
    orderNumber: {
      type: "text",
      value: "",
      label: "Order Number",
      span: "8"
    },
    customerUid: {
      type: "text",
      value: "",
      label: "Customer ID",
      span: "8"
    },
    orderCreatedDate: {
      type: "date",
      value: "",
      label: "Order Date",
      span: "8"
    },
  };
  public paginationLimit = [10, 20, 50, 100]

  @Select(AbandonedCheckoutStateSelectors.abandonedCheckoutList)
  abandonedCheckoutList$: Observable<any> | undefined
  @Select(AbandonedCheckoutStateSelectors.pageSize)
  pageSize$: Observable<any> | undefined;
  @Select(AbandonedCheckoutStateSelectors.total)
  total$: Observable<any> | undefined;
  @Select(AbandonedCheckoutStateSelectors.pageIndex)
  pageIndex$: Observable<any> | undefined;
  @Select(AbandonedCheckoutStateSelectors.loading)
  loading$: Observable<boolean> | undefined;
  selectedTabIndex = 0;
  selectedTab = 'order-overview';
  tabs = [{ value: 'order-overview', displayValue: 'Order Overview' },
   { value: 'customer-details', displayValue: 'Customer Details' },
];
@Select(OrderStateSelectors.orderDetails)
orderDetails$: Observable<any> | undefined
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  constructor(private store: Store, private modal: NzModalService, private readonly fb: FormBuilder) { }
  async ngOnInit() {
    this.store.dispatch(new GetAbandonedCheckoutsList('PENDING'));   
     
  }
  onChangePage(page: number): void {
    this.store.dispatch([new ChangeAbandonedCheckoutsPage(page), new GetAbandonedCheckoutsList('PENDING')])
  }
  openModal(abandonedCheckout:any): void {
    this.store.dispatch([
      new GetOrderDetails(abandonedCheckout?.id),
      new GetCustomerDetails(abandonedCheckout?.customerId)
    ]);
    this.showModal = true;
  }

  onChange(result: Date): void {
  }
  filtersFormSubmit($event: any) {
    this.store.dispatch(new GetAbandonedCheckoutssWithFilters($event, 'PENDING'))
  }
  
  selectTab(key: string, index: number) {
    this.selectedTab = key;
    this.selectedTabIndex = index;
  }
}


