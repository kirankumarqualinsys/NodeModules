import { Component, OnInit, TrackByFunction } from '@angular/core';
import { FormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { CancelOrder, ChangeOrdersPage, GetCancelOrderReasonTypes, GetOrdersList, GetOrderssWithFilters, UploadOrderInvoice } from 'apps/sales/src/app/state/order.action';
import { OrderStateSelectors } from 'apps/sales/src/app/state/order.selector';
import { NzModalService } from 'ng-zorro-antd/modal';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-orders-list',
  templateUrl: './orders-list.component.html',
  styleUrls: ['./orders-list.component.less'],
})
export class OrdersListComponent implements OnInit {
  tabs = ['All', 'Ordered', 'Accepted', 'Processing', 'Completed', 'Cancelled', 'Declined'];
  activetabIndex = 0;
  tabStatus: any = 'skip';
  cancelOrderForm!: UntypedFormGroup;
  showModal = false;
  showCancelReasonTypes = false;
  showAcceptOrderModal = false;
  selectedOrder: any;
  ordersFilterFields = {
    orderNumber: {
      type: "text",
      value: "",
      label: "Order Number",
      span: "6"
    },
    customerUid: {
      type: "text",
      value: "",
      label: "Customer ID",
      span: "4"
    },
    orderCreatedDate: {
      type: "date",
      value: "",
      label: "Order Date",
      span: "6"
    },
    paymentStatus: {
      type: "select",
      value: "",
      label: "Payment Status",
      span: "4",
      options: [
        {
          label: "Select one",
          value: "",
        },
        {
          label: "Pending",
          value: "PENDING",
        },
        {
          label: "Unpaid",
          value: "UNPAID",
        },
        {
          label: "Paid",
          value: "PAID",
        },
      ],
    },
    shipmentStatus: {
      type: "select",
      value: "",
      label: "Shipment Status",
      span: "4",
      options: [
        {
          label: "Select one",
          value: "",
        },
        {
          label: "Pending",
          value: "PENDING",
        },
        {
          label: "Unshipped",
          value: "UNSHIPPED",
        },
        {
          label: "Shipped",
          value: "SHIPPED",
        },
        {
          label: "Delivered",
          value: "DELIVERED",
        },
      ],
    },
  };
  public paginationLimit = [10, 20, 50, 100]

  @Select(OrderStateSelectors.ordersList)
  ordersList$: Observable<any> | undefined
  @Select(OrderStateSelectors.pageSize)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.order.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.order.paginationOrders.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.order.loading)
  loading$: Observable<boolean> | undefined;
  @Select((state: any) => state.order.cancelOrderReasonTypes)
  cancelOrderReasonTypes$: Observable<any> | undefined
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  showInvoiceModal: boolean = false;
  invoiceForm!: UntypedFormGroup;
  submitted: boolean = false;
  uploadedFile: any = null;

  constructor(private store: Store, private modal: NzModalService, private readonly fb: FormBuilder) { }

  async ngOnInit() {
    this.store.dispatch(new GetOrdersList('skip'))
    this.cancelOrderForm = this.fb.group({
      cancelReasonType: [null, [Validators.required]],
      cancelReason: [null]
    });

    this.invoiceForm = this.fb.group({
      invoiceNumber: ['', Validators.required],
      invoiceAdjustment: ['', Validators.required],
      additionalCharges: ['']
    })
  }

  onChangePage(page: number): void {
    this.store.dispatch([new ChangeOrdersPage(page), new GetOrdersList(this.tabStatus)])
  }

  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = 'skip';
      this.store.dispatch([new ChangeOrdersPage(1), new GetOrdersList('skip')]);
    } else {
      this.tabStatus = this.tabs[event];
      this.store.dispatch([new ChangeOrdersPage(1), new GetOrdersList(this.tabStatus)]);
    }
  }

  onChange(result: Date): void { }

  filtersFormSubmit($event: any) {
    this.store.dispatch(new GetOrderssWithFilters($event, this.tabStatus))
  }

  openCancelOrderModal(order: any) {
    this.selectedOrder = order;
    this.store.dispatch(new GetCancelOrderReasonTypes());
    this.showModal = true;
  }

  cancelOrder() {
    this.showCancelReasonTypes = true;
    if (this.showCancelReasonTypes && this.cancelOrderForm.valid) {
      const body = {
        ...this.cancelOrderForm.value,
        id: this.selectedOrder.id,
        orderNumber: this.selectedOrder.orderNumber
      }
      this.store.dispatch([new CancelOrder(body), new GetOrdersList(this.tabStatus)])
      this.showModal = false;
    }
  }

  cancel() {
    this.showModal = false;
    this.showCancelReasonTypes = false;
    this.showAcceptOrderModal = false;
  }

  openAcceptOrderModal(order: any) {
    this.selectedOrder = order;
    this.showAcceptOrderModal = true;
  }

  openUploadInvoiceModal(order: any) {
    this.selectedOrder = order;
    this.showInvoiceModal = true;
  }

  cancelInvoiceUpload() {
    this.showInvoiceModal = false;
    this.invoiceForm.reset();
  }

  invoiceUploaded(event: any) {
    this.uploadedFile = event.target.files[0];
  }

  uploadInvoice() {
    this.submitted = true;
    if (this.invoiceForm.valid) {
      let formData: FormData = new FormData()
      formData.append('file', this.uploadedFile);
      formData.append('invoiceNumber', this.invoiceForm.value.invoiceNumber)
      let payload = {
        invoiceNumber: this.invoiceForm.value.invoiceNumber,
        orderNumber: this.selectedOrder.orderNumber
      }
      this.store.dispatch([new UploadOrderInvoice(payload, formData)])
    }
  }

  acceptOrder() { }
}

