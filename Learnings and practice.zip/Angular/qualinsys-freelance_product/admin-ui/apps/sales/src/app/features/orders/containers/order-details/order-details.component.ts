import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { GetOrderDetails } from 'apps/sales/src/app/state/order.action';
import { OrderStateSelectors } from 'apps/sales/src/app/state/order.selector';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OrderDetailsComponent implements OnInit {
  tabs = [{ value: 'order-overview', displayValue: 'Order Overview' },
  { value: 'shipping', displayValue: 'Shipping' },
  { value: 'payments-and-refunds', displayValue: 'Payments & Refunds' },
    // { value: 'items-cancellation-and-refunds', displayValue: 'Items Cancellation & Returns' }
  ];
  selectedTabIndex = 0;
  selectedTab = 'order-overview';
  @Select(OrderStateSelectors.orderDetails)
  orderDetails$: Observable<any> | undefined;

  constructor(private store: Store, private readonly route: ActivatedRoute) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.store.dispatch(new GetOrderDetails(id))
    }
  }

  selectTab(key: string, index: number) {
    this.selectedTab = key;
    this.selectedTabIndex = index;
  }

  reloadOrderDetails() {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.store.dispatch(new GetOrderDetails(id))
    }
  }
}
