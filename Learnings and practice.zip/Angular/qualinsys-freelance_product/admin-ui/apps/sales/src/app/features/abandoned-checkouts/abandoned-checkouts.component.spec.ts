import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AbandonedCheckoutsComponent } from './abandoned-checkouts.component';

describe('AbandonedCheckoutsComponent', () => {
  let component: AbandonedCheckoutsComponent;
  let fixture: ComponentFixture<AbandonedCheckoutsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AbandonedCheckoutsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(AbandonedCheckoutsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
