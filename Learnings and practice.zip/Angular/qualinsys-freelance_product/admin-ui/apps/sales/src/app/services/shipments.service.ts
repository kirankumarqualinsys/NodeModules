import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { IPage } from '../state/order.state';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ShipmentsService {
  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

  getShipments(status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/search`;
    const data: any = {
      page: pagination.page - 1,
      size: pagination.size
    }
    if (status !== 'skip') {
      Object.assign(data, { 'shipmentStatus': status.toUpperCase() })
    }
    return this.http.post(url, data)
  }

  getShipmentsWithFilters(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/search`;
    const data: any = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }

  cancelShipment(orderId: number): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/${orderId}/status/CANCELLED`;
    return this.http.put(url, {})
  }

  changeShipmentStatus(orderId: number, status: string): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/${orderId}/status/${status}`;
    return this.http.put(url, {})
  }

  updateShipmentStatus(payload: any, status: string): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/update/status/${status}`;
    return this.http.put(url, payload)
  }
}
