import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../state/abandonedCheckouts.state';

@Injectable({
  providedIn: 'root'
})
export class AbandonedCheckoutsService {
  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getAbandonedCheckouts(status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/search`;
    const data = {
      orderStatus: status,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  getAbandonedCheckoutsWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/search`;
    const data = {
      ...payload,
      orderStatus: status ,
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }
  getAbandonedCheckoutDetails(abandonedCheckoutsId: string): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/${abandonedCheckoutsId}`;
    return this.http.get(url);
  }
}
