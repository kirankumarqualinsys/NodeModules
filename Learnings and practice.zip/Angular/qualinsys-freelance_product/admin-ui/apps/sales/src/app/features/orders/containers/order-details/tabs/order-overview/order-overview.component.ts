import { Component, EventEmitter, Input, OnInit, Output, TrackByFunction } from '@angular/core';
import { FormGroup, FormBuilder, Validators, UntypedFormGroup } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import { GetCustomerDetails } from 'apps/crm/src/app/state/customer.action';
import { CancelOrderItem, GetCancelOrderReasonTypes, GetOrdersList } from 'apps/sales/src/app/state/order.action';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-order-overview',
  templateUrl: './order-overview.component.html',
  styleUrls: ['./order-overview.component.less'],
})
export class OrderOverviewComponent implements OnInit {
  @Input() orderDetails: any;
  @Output() refreshOrderDetails: EventEmitter<any> = new EventEmitter();
  @Select((state: any) => state.customer.customerDetails)
  customerDetails$: Observable<any> | undefined;
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  @Select((state: any) => state.order.cancelOrderReasonTypes)
  cancelOrderReasonTypes$: Observable<any> | undefined
  showModal: boolean = false;
  cancelOrderForm!: FormGroup;
  selectedOrderItem: any;
  submitted: boolean = false;

  constructor(private store: Store,
    private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.store.dispatch(new GetCustomerDetails(this.orderDetails.customerId))
    this.cancelOrderForm = this.formBuilder.group({
      cancelReasonType: ['', Validators.required],
      cancelReason: [''],
      quantity: [0],
      cancelQuantity: ['', Validators.required]
    });
  }

  openCancelOrderItemModal(orderItem: any) {
    this.selectedOrderItem = orderItem;
    this.cancelOrderForm.controls['quantity'].setValue(this.selectedOrderItem.quantity)
    this.store.dispatch(new GetCancelOrderReasonTypes());
    this.showModal = true;
  }

  cancelOrder() {
    this.submitted = true;
    if (this.cancelOrderForm.invalid) return false;
    let payload = {
      cancelQuantity: this.cancelOrderForm.value.cancelQuantity,
      cancelReason: this.cancelOrderForm.value.cancelReason,
      cancelReasonType: this.cancelOrderForm.value.cancelReasonType,
      id: this.selectedOrderItem.id,
      quantity: this.selectedOrderItem.quantity
    }

    this.store.dispatch([new CancelOrderItem(payload)])
    this.showModal = false;
    this.refreshOrderDetails.emit();
    this.submitted = false;
    return true;
  }

  cancel() {
    this.showModal = false;
    this.cancelOrderForm.reset();
  }
}
