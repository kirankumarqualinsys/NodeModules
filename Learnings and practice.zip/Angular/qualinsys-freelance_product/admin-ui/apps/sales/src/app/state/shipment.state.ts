import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { catchError, of, take, tap } from 'rxjs';
import { CancelShipment, ChangeShipmentPage, ChangeShipmentStatus, GetShipmentsList, GetShipmentsWithFilters, UpdateShipmentStatus } from './shipment.action';
import { ShipmentsService } from '../services/shipments.service';

export interface IPage {
  size: number;
  page: number;
  filter?: string;
  filterParams?: { value: string[], key: string }[];
  sort?: { key: string, value: string }
}
export interface ShipmentStateModel {
  shipmentsList: [];
  paginationShipments: IPage;
  total: number;
  loading: boolean;
}
@State<ShipmentStateModel>({
  name: 'shipment',
  defaults: {
    shipmentsList: [],
    paginationShipments: { page: 1, size: 5 },
    total: 0,
    loading: false
  }
})
@Injectable()
export class ShipmentState implements NgxsOnInit {


  constructor(private shipmentsService: ShipmentsService, private readonly store: Store) { }

  async ngxsOnInit() { }

  @Action(GetShipmentsList)
  getShipmentsList({ getState, patchState }: StateContext<ShipmentStateModel>, action: GetShipmentsList) {
    const { paginationShipments } = getState();
    patchState({ loading: true })
    console.log(123)
    return this.shipmentsService.getShipments(action.payload, paginationShipments).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const shipmentsList = result.content;
          const total = result.totalElements;
          patchState({
            shipmentsList,
            total,
            loading: false
          });
        }
      })
    );
  }

  @Action(ChangeShipmentPage)
  changeOrdersPage({ patchState, getState }: StateContext<ShipmentStateModel>, action: ChangeShipmentPage) {
    patchState({ paginationShipments: { ...getState().paginationShipments, page: action.paylaod } })
  }

  @Action(GetShipmentsWithFilters)
  getShipmentsWithFilters({ getState, patchState }: StateContext<ShipmentStateModel>, action: GetShipmentsWithFilters) {
    const { paginationShipments } = getState();
    patchState({ loading: true })
    return this.shipmentsService.getShipmentsWithFilters(action.paylaod, paginationShipments).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const shipmentsList = result.content;
          const total = result.totalElements;
          patchState({
            shipmentsList,
            total,
            loading: false
          });
        }
      })
    );
  }

  @Action(CancelShipment)
  cancelShipment({ patchState }: StateContext<ShipmentStateModel>, action: CancelShipment) {
    patchState({ loading: true })
    return this.shipmentsService.cancelShipment(action.orderId).pipe(
      take(1),
      tap((result: any) => {
        patchState({
          loading: false
        });
      })
    )
  }

  @Action(ChangeShipmentStatus)
  changeShipmentStatus({ patchState }: StateContext<ShipmentStateModel>, action: ChangeShipmentStatus) {
    patchState({ loading: true })
    return this.shipmentsService.changeShipmentStatus(action.payload, action.status).pipe(
      take(1),
      tap((result: any) => {
        patchState({
          loading: false
        });
      }),
      catchError((error: any, caught: any) => {
        patchState({loading: false});
        return of();
      })
    )
  }

  @Action(UpdateShipmentStatus)
  updateShipmentStatus({ patchState }: StateContext<ShipmentStateModel>, action: UpdateShipmentStatus) {
    patchState({ loading: true })
    return this.shipmentsService.updateShipmentStatus(action.orderId, action.status).pipe(
      take(1),
      tap((result: any) => {
        patchState({
          loading: false
        });
      }),
      catchError((error: any, caught: any) => {
        patchState({loading: false});
        return of();
      })
    )
  }
}