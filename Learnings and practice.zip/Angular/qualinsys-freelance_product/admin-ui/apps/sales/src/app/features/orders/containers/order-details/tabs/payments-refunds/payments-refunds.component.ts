import { Component, Input, OnInit, TrackByFunction } from '@angular/core';
import { NzModalRef, NzModalService } from 'ng-zorro-antd/modal';

import { AddPaymentsModalComponent } from '../../../../../../../../../../libs/shared/src/lib/modals/add-payments-modal/add-payments-modal.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PaymentsService } from 'apps/sales/src/app/services/payments.service';

@Component({
  selector: 'commerceq-admin-ui-payments-refunds',
  templateUrl: './payments-refunds.component.html',
  styleUrls: ['./payments-refunds.component.less'],
})
export class PaymentsRefundsComponent implements OnInit {
  @Input() orderDetails: any;
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  paymentForm!: FormGroup;
  submitted: boolean = false;
  showModal: boolean = false;
  paymentMethodsList: any = [];
  selectedPayment: any = null;

  constructor(private readonly modalService: NzModalService,
    private fb: FormBuilder, private paymentsService: PaymentsService) { }

  ngOnInit(): void {
    this.paymentForm = this.fb.group({
      // amount: [null],
      referenceNumber: [null, [Validators.required]],
      paymentDate: [null, [Validators.required]],
      paymentType: [null, [Validators.required]]
    })

    this.paymentsService.getPaymentMethodsList().subscribe((method: any) => {
      this.paymentMethodsList = method;
    })
  }
  
  openAddPaymentModal() {
    const modal: NzModalRef = this.modalService.create({
      nzTitle: 'Add Payment',
      nzContent: AddPaymentsModalComponent,
      nzWidth: 660,
      nzFooter: [
        {
          label: 'Submit',
          type: 'primary',
          onClick: async (data) => {
            console.log(data, "data")
          },
        },
        {
          label: 'Cancel',
          type: 'default',
          onClick: () => modal.destroy(),
        },
      ],
    });
  }

  openEditPaymentModal(payment: any) {
    this.showModal = true;
    this.selectedPayment = JSON.parse(JSON.stringify(payment));
    // this.paymentForm.controls['amount'].setValue(payment?.amount);
    this.paymentForm.controls['paymentDate'].setValue(payment?.paymentDate);
    this.paymentForm.controls['paymentType'].setValue(payment?.paymentMode?.key);
    this.paymentForm.controls['referenceNumber'].setValue(payment?.paymentRefNumber);
  }

  closePaymentModal() {
    this.showModal = false;
    this.paymentForm.reset();
    this.selectedPayment = null;
    this.submitted = false;
  }

  updatePayment() {
    this.submitted = true;
    if (this.paymentForm.valid) {
      // this.selectedPayment['amount'] = this.paymentForm.value.amount;
      this.selectedPayment['paymentMode'] = this.paymentForm.value.paymentType;
      this.selectedPayment['paymentRefNumber'] = this.paymentForm.value.referenceNumber;
      this.selectedPayment['paymentDate'] = new Date(this.paymentForm.value.paymentDate);
      this.paymentsService.updatePayment(this.selectedPayment).subscribe((result: any) => {
        this.closePaymentModal();
      }, (error: any) => {
        console.log(error)
      })
    }
  }
}
