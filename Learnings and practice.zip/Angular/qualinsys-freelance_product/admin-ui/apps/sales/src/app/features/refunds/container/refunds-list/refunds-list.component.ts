import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-refunds-list',
  templateUrl: './refunds-list.component.html',
  styleUrls: ['./refunds-list.component.less'],
})
export class RefundsListComponent {}
