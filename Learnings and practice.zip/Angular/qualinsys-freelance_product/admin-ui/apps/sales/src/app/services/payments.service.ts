import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/payments.state';

@Injectable({
    providedIn: 'root'
})
export class PaymentsService {
    constructor(private readonly http: HttpClient,
        private readonly environment: EnvironmentService) { }
    getPayments(status: any, pagination: IPage): Observable<any> {
        const url = `${this.environment.apiUrl}/order/api/97932177/payments/search`;
        const data:any = {
            page: pagination.page - 1,
            size: pagination.size
        }
        if (status!== 'skip') {
            Object.assign(data, { 'paymentStatus': status.toUpperCase() })
        }
        return this.http.post(url, data )
    }

      getPaymentsWithFilters(payload: any, pagination: IPage): Observable<any> {
          const url = `${this.environment.apiUrl}/order/api/97932177/payments/search`;
    const data: any = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }

    return this.http.post(url, data)
  }
  getPaymentsDetails(id: number): Observable<any> {
      const url = `${this.environment.apiUrl}/order/api/97932177/payments/search${id}`;
    return this.http.get(url)
  }
  editPayments(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/payments/search${payload.id}`;
    return this.http.put(url, payload)
  }

  getPaymentMethodsList() {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/payment-methods`;
    return this.http.get(url);
  }

  updatePayment(payload: any) {
    const url = `${this.environment.apiUrl}/order/api/97932177/payments/${payload.id}`;
    return this.http.put(url, payload);
  }
}