import { Component, Input, OnInit, TrackByFunction } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Select, Store } from '@ngxs/store';
import {
  CancelShipment,
  ChangeShipmentPage,
  ChangeShipmentStatus,
  GetShipmentsList,
  UpdateShipmentStatus,
} from 'apps/sales/src/app/state/shipment.action';
import { ShipmentStateSelectors } from 'apps/sales/src/app/state/shipment.selector';
import { Observable } from 'rxjs';

@Component({
  selector: 'commerceq-admin-ui-shipments-list',
  templateUrl: './shipments-list.component.html',
  styleUrls: ['./shipments-list.component.less'],
})
export class ShipmentsListComponent implements OnInit {
  @Input() tabStatus: any;
  @Input() activetabIndex: any;
  showModal = false;
  selectedShipment: any;
  public paginationLimit = [10, 20, 50, 100];

  @Select(ShipmentStateSelectors.shipmentsList)
  shipmentsList$: Observable<any> | undefined;
  @Select(ShipmentStateSelectors.pageSize)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.shipment.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.shipment.paginationShipments.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.shipment.loading)
  loading$: Observable<boolean> | undefined;
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  currentAction: string = '';
  showDeliveryConfirmationModal: boolean = false;
  showShippedConfirmationModal: boolean = false;
  shipmentDeliveredForm!: FormGroup;
  shipmentShippedForm!: FormGroup;
  submitted: boolean = false;
  
  constructor(private store: Store,
    private fb: FormBuilder) { }

  async ngOnInit() {
    this.shipmentDeliveredForm = this.fb.group({
      deliveryDate: ['', Validators.required]
    });
    this.shipmentShippedForm = this.fb.group({
      shippingCarrier: ['', Validators.required],
      serviceName: [''],
      trackingNumber: [''],
      dispatchDate: ['', Validators.required]
    });
  }

  onChangePage(page: number): void {
    this.store.dispatch([
      new ChangeShipmentPage(page),
      new GetShipmentsList(this.tabStatus),
    ]);
  }

  openConfirmationModal(actionName: string, shipment: any) {
    this.showModal = true;
    this.currentAction = actionName ? actionName : '';
    this.selectedShipment = shipment;
  }

  proceedtoCancelShipment() {
    this.store.dispatch([
      new CancelShipment(this.selectedShipment.id),
      new GetShipmentsList(this.tabStatus),
    ]);
    this.showModal = false;
  }

  updateShipmentStatus() {
    switch(this.currentAction.toUpperCase()) {
      case 'DELIVERED':
        this.showModal = false;
        this.showDeliveryConfirmationModal = true;
        break;
      case 'SHIPPED':
        this.showModal = false;
        this.showShippedConfirmationModal = true;
        break;
      default:
        this.store.dispatch([new ChangeShipmentStatus(this.selectedShipment.id, this.currentAction), new GetShipmentsList(this.tabStatus)]);
        this.closeConfirmModal();
        break;
    }
  }

  markShipmentAsDelivered() {
    this.submitted = true;
    if (this.shipmentDeliveredForm.valid) {
      let payload = JSON.parse(JSON.stringify(this.selectedShipment))
      payload['deliveredDate'] = new Date(this.shipmentDeliveredForm.value.deliveryDate).toISOString();
      this.store.dispatch([new UpdateShipmentStatus(payload, this.currentAction), new GetShipmentsList(this.tabStatus)]);
      this.showDeliveryConfirmationModal = false;
      this.submitted = false;
    }
  }

  markShipmentAsShipped() {
    this.submitted = true;
    if (this.shipmentShippedForm.valid) {
      let payload = JSON.parse(JSON.stringify(this.selectedShipment))
      payload['carrierName'] = this.shipmentShippedForm.value.shippingCarrier || null;
      payload['serviceName'] = this.shipmentShippedForm.value.serviceName || null;
      payload['trackingNumber'] = this.shipmentShippedForm.value.trackingNumber || null;
      payload['shipmentDate'] = new Date(this.shipmentShippedForm.value.dispatchDate).toISOString() || null;
      this.store.dispatch([new UpdateShipmentStatus(payload, this.currentAction), new GetShipmentsList(this.tabStatus)]);
      this.showShippedConfirmationModal = false;
      this.submitted = false;
    }
  }

  closeConfirmModal() {
    this.showModal = false;
    this.selectedShipment = null;
    this.currentAction = ''
  }
}
