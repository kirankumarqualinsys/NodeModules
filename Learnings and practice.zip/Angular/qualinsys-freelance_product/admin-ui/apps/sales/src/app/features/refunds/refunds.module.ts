import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RefundsComponent } from './refunds.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { RefundsService } from '../../services/refunds.service';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { FiltersDynamicFormModule } from '../../../../../../libs/shared/src/lib/components/common/filters-dynamic-form/filters-dynamic-form.module';
import { RefundsListComponent } from './container/refunds-list/refunds-list.component';


@NgModule({
    declarations: [RefundsComponent, RefundsListComponent],
    exports: [RefundsComponent],
    providers: [RefundsService],
    imports: [
        CommonModule,
        RouterModule.forChild([{ path: '', component: RefundsComponent }]),
        NzDividerModule,
        NzTabsModule,
        NzTableModule,
        NzPaginationModule,
        NzSwitchModule,
        FormsModule,
        ReactiveFormsModule,
        NzFormModule,
        NzDatePickerModule,
        NzButtonModule,
        NzInputModule,
        NzDropDownModule,
        NzModalModule,
        NzSelectModule,
        FiltersDynamicFormModule,
    ],
})
export class RefundsModule { }
