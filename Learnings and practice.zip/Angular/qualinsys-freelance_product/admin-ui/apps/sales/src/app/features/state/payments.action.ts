export class GetPaymentsList {
    static readonly type = '[Payments] Get Payments';
    constructor(public payload: any) { }
}


export class ChangePaymentsPage {
    static readonly type = '[Payments] Change Payments Page';
    constructor(public readonly paylaod: number) { }
}
 
export class GetPaymentsWithFilters {
    static readonly type = '[Payments] Get Payments With Filters';
    constructor(public readonly paylaod: any) { }
}
export class GetPaymentsDetails {
    static readonly type = '[Payments] Get Payments Details';
    constructor(public readonly id: any) { }
}