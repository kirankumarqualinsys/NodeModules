import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ItemsCancellationReturnsComponent } from './items-cancellation-returns.component';

describe('ItemsCancellationReturnsComponent', () => {
  let component: ItemsCancellationReturnsComponent;
  let fixture: ComponentFixture<ItemsCancellationReturnsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ItemsCancellationReturnsComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(ItemsCancellationReturnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
