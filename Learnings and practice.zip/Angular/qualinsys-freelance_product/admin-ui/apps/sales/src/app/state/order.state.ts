import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { catchError, of, take, tap } from 'rxjs';
import { CancelOrder, ChangeOrdersPage, GetCancelOrderReasonTypes, GetOrderDetails, GetOrdersList, GetOrderssWithFilters, CancelOrderItem, UploadOrderInvoice, CancelShippedOrderItem } from './order.action';
import { OrdersService } from '../services/orders.service';

export interface IPage {
  size: number;
  page: number;
  filter?: string;
  filterParams?: { value: string[], key: string }[];
  sort?: { key: string, value: string }
}
export interface OrderStateModel {
  ordersList: [];
  paginationOrders: IPage;
  total: number;
  loading: boolean;
  orderDetails: any;
  cancelOrderReasonTypes: []
}
@State<OrderStateModel>({
  name: 'order',
  defaults: {
    ordersList: [],
    paginationOrders: { page: 1, size: 5 },
    total: 0,
    loading: false,
    orderDetails: undefined,
    cancelOrderReasonTypes: []
  },
})
@Injectable()
export class OrderState implements NgxsOnInit {

  constructor(private ordersService: OrdersService, private readonly store: Store) { }

  async ngxsOnInit() {
  }

  @Action(GetOrdersList)
  getOrdersList({ getState, patchState }: StateContext<OrderStateModel>, action: GetOrdersList) {
    const { paginationOrders } = getState();
    patchState({ loading: true })
    return this.ordersService.getOrders(action.payload, paginationOrders).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const ordersList = result.content;
          const total = result.totalElements;
          patchState({
            ordersList,
            total,
            loading: false
          });
        }
      })
    );
  }

  @Action(ChangeOrdersPage)
  changeOrdersPage({ patchState, getState }: StateContext<OrderStateModel>, action: ChangeOrdersPage) {
    patchState({ paginationOrders: { ...getState().paginationOrders, page: action.paylaod } })
  }

  @Action(GetOrderssWithFilters)
  getOrdersWithFilters({ getState, patchState }: StateContext<OrderStateModel>, action: GetOrderssWithFilters) {
    const { paginationOrders } = getState();
    patchState({ loading: true })
    return this.ordersService.getOrdersWithFilters(action.paylaod, action.status, paginationOrders).pipe(
      take(1),
      tap((result: any) => {
        if (result && result.content) {
          const ordersList = result.content;
          const total = result.totalElements;
          patchState({
            ordersList,
            total,
            loading: false
          });
        }
      })
    );
  }

  @Action(GetOrderDetails)
  getOrderDetails({ patchState }: StateContext<OrderStateModel>, action: GetOrderDetails) {
    patchState({ loading: true })
    return this.ordersService.getOrderDetails(action.orderId).pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          const orderDetails = result;
          patchState({
            orderDetails,
            loading: false
          });
        }
      })
    );
  }
  
  @Action(GetCancelOrderReasonTypes)
  getCancelOrderReasonTypes({ patchState }: StateContext<OrderStateModel>) {
    patchState({ loading: true })
    return this.ordersService.getCancelOrderReasonTypes().pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          const cancelOrderReasonTypes = result;
          patchState({
            cancelOrderReasonTypes,
            loading: false
          });
        }
      })
    );
  }

  @Action(CancelOrder)
  cancelOrder({ patchState }: StateContext<OrderStateModel>, action: CancelOrder) {
    patchState({ loading: true })
    return this.ordersService.cancelOrder(action.payload).pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          patchState({
            loading: false
          });
        }
      })
    );
  }

  @Action(CancelOrderItem)
  cancelOrderItem({ patchState }: StateContext<any>, action: CancelOrderItem) {
    patchState({ loading: true });
    return this.ordersService.cancelOrderItem(action.payload).pipe(
      take(1),
      tap((result: any) => {
        if (result) {
          patchState({
            result,
            loading: false
          })
        }
      }),
      catchError((error: any, caught: any) => {
        patchState({loading: false})
        return of()
      })
    );
  }

  @Action(UploadOrderInvoice)
  uploadOrderInvoice({ patchState }: StateContext<any>, action: UploadOrderInvoice) {
    patchState({ loading: true });
    return this.ordersService.uploadOrderInvoice(action.payload, action.data).pipe(
      take(1),
      tap((result: any) => {
        patchState({ result, loading: false });
      }),
      catchError((error: any, caught: any) => {
        patchState({ loading: false });
        return of({ loading: false })
      })
    )
  }

  @Action(CancelShippedOrderItem)
  cancelShippedOrderItem({ patchState }: StateContext<any>, action: CancelShippedOrderItem) {
    patchState({ loading: true });
    return this.ordersService.cancelShippingItem(action.payload).pipe(
      take(1),
      tap((result: any) => {
        patchState({ result, loading: false});
      }),
      catchError((error: any, caught: any) => {
        patchState({ loading: false });
        return of({ loading: false })
      })
    )
  }
}