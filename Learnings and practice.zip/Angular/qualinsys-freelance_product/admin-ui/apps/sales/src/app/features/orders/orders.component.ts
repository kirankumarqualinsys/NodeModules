import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';
import { GetOrdersList, GetOrderssWithFilters } from '../../state/order.action';

@Component({
  selector: 'commerceq-admin-ui-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.less'],
})
export class OrdersComponent implements OnInit {

  constructor(private store: Store) { }
  async ngOnInit() {
    console.log(1)
  }


}
