import { TestBed } from '@angular/core/testing';

import { AbandonedCheckoutsService } from './abandonedCheckouts.service';

describe('AbandonedCheckoutsService', () => {
  let service: AbandonedCheckoutsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AbandonedCheckoutsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
