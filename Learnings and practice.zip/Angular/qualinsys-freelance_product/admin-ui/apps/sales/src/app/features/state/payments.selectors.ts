import { Selector } from '@ngxs/store';
import {
    PaymentsStateModel,
    PaymentsState,} 
    from './payments.state';

export class PaymentsStateSelectors {
    @Selector([PaymentsState])
    static paymentsList(state: PaymentsStateModel) {
        return state.paymentsList;
    }
    @Selector([PaymentsState])
    static pageSize(state: PaymentsStateModel) {
        return state.paginationPayments.size;
    }
    @Selector([PaymentsState])
    static total(state: PaymentsStateModel) {
        return state.total;
    }
    @Selector([PaymentsState])
    static pageIndex(state: PaymentsStateModel) {
        return state.paginationPayments.page;
    }
    @Selector([PaymentsState])
    static loading(state: PaymentsStateModel) {
        return state.loading;
    }
    @Selector([PaymentsState])
    static paymentsDetails(state: PaymentsStateModel) {
        return state.paymentsDetails;
    }
    
}