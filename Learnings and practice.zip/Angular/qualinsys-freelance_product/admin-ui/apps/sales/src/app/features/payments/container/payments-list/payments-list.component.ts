import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-payments-list',
  templateUrl: './payments-list.component.html',
  styleUrls: ['./payments-list.component.less'],
})
export class PaymentsListComponent {}
