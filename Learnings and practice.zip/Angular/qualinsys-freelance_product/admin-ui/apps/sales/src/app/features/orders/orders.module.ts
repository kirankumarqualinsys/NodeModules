import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrdersComponent } from './orders.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzToolTipModule } from 'ng-zorro-antd/tooltip';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzCheckboxModule } from 'ng-zorro-antd/checkbox';

import { OrdersListComponent } from './containers/orders-list/orders-list.component';

import { FiltersDynamicFormModule } from '../../../../../../libs/shared/src/lib/components/common/filters-dynamic-form/filters-dynamic-form.module';

@NgModule({
  declarations: [OrdersComponent, OrdersListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild([
      {
        path: '', component: OrdersListComponent,
      },
      {
        path: 'details/:id',
        loadChildren: () =>
          import('./containers/order-details/order-details.module').then(m => m.OrderDetailsModule)
      }

    ]),
    NzDividerModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzDatePickerModule,
    NzButtonModule,
    NzInputModule,
    NzRadioModule,
    FiltersDynamicFormModule,
    NzDropDownModule,
    NzToolTipModule,
    NzModalModule,
    NzCheckboxModule
  ],
})
export class OrdersModule { }
