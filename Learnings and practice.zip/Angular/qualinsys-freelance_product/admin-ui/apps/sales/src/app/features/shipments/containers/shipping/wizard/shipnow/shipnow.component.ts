import { Component, Input, OnInit } from '@angular/core';
import { NzButtonSize } from 'ng-zorro-antd/button/button.component';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'commerceq-admin-ui-shipnow',
  templateUrl: './shipnow.component.html',
  styleUrls: ['./shipnow.component.less'],
})
export class ShipnowComponent implements OnInit {
  size: NzButtonSize = 'large';
  selectedValue = null;
  //inputValue = '';
  demoValue = 3;
  productForm!:UntypedFormGroup;
  categoryFormGroup!: UntypedFormGroup;
  collectionList:any =[];
  @Input() shipmentsList: any;
  inputValue?: string;
  options: string[] = [];

  onInput(event: Event): void {
    const value = (event.target as HTMLInputElement).value;
    this.options = value ? [value, value + value, value + value + value] : [];
  }
  constructor(private fb: UntypedFormBuilder, private router:Router) {}
  ngOnInit(): void {
    this.productForm = this.fb.group({
      title: [null, [Validators.required]],
      category:[null, [Validators.required]],
      productTags:[null],
      collection:[null],
      enableProduct:[false],
      phoneNumberPrefix: ['+91'],
      phoneNumber: [null, [Validators.required]],
    });
  }
  getParentList(event: Event): void {
    // const value = (event.target as HTMLInputElement).value;
    // if (value && value.length > 2) {
    //   this.categoriesService.getParent(value).subscribe((res: any) => {
    //     this.parentList = [];
    //     if (res && res.length > 0) {
    //       this.parentList = res;
    //     }
    //   })
    // }
  }
  isVisible = false;
   title: string = 'Add Category';
   showModal(): void {
    this.categoryFormGroup.reset();
     this.isVisible = true;
   }
  submitForm(){

  }
  listProduct(){
    this.router.navigateByUrl('/fetchrates');
  }
}
