import { Selector } from '@ngxs/store';
import {
  ShipmentStateModel,
  ShipmentState,
} from './shipment.state';

export class ShipmentStateSelectors {
  @Selector([ShipmentState])
  static shipmentsList(state: ShipmentStateModel) {
    return state.shipmentsList;
  }
  @Selector([ShipmentState])
  static pageSize(state: ShipmentStateModel) {
    return state.paginationShipments.size;
  }
  @Selector([ShipmentState])
  static total(state: ShipmentStateModel) {
    return state.total;
  }
  @Selector([ShipmentState])
  static pageIndex(state: ShipmentStateModel) {
    return state.paginationShipments.page;
  }
  @Selector([ShipmentState])
  static loading(state: ShipmentStateModel) {
    return state.loading;
  }
  // @Selector([ShipmentState])
  // static shipmentsDetails(state: ShipmentStateModel) {
  //   return state.shipmentsDetails;
  // }
}