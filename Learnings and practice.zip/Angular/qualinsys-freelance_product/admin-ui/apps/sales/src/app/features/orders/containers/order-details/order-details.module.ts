import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OrderDetailsComponent } from './order-details.component';
import { OrderOverviewComponent } from './tabs/order-overview/order-overview.component';
import { ShippingComponent } from './tabs/shipping/shipping.component';
import { PaymentsRefundsComponent } from './tabs/payments-refunds/payments-refunds.component';
import { ItemsCancellationReturnsComponent } from './tabs/items-cancellation-returns/items-cancellation-returns.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';

import { AddPaymentsModalModule } from '../../../../../../../../libs/shared/src/lib/modals/add-payments-modal/add-payments-modal.module'

@NgModule({
  declarations: [
    OrderDetailsComponent,
    OrderOverviewComponent,
    ShippingComponent,
    PaymentsRefundsComponent,
    ItemsCancellationReturnsComponent,
  ],
  imports: [CommonModule,
    RouterModule.forChild([
      {
        path: '', component: OrderDetailsComponent,
      },
    ]),
    NzButtonModule,
    NzFormModule,
    NzDividerModule,
    NzDropDownModule,
    NzRadioModule,
    NzInputModule,
    NzDatePickerModule,
    NzSwitchModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzModalModule,
    AddPaymentsModalModule,
    FormsModule, 
    ReactiveFormsModule
  ]
})
export class OrderDetailsModule { }
