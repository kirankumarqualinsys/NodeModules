import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-create-pickup',
  templateUrl: './create-pickup.component.html',
  styleUrls: ['./create-pickup.component.less'],
})
export class CreatePickupComponent implements OnInit {
  @Input() shipmentsList: any;
  date = null;
  ngOnInit(): void {
   // throw new Error('Method not implemented.');
  }
  onChange(result: Date): void {
    console.log('onChange: ', result);
  }
}
