import { Component, Input, OnInit, TrackByFunction } from '@angular/core';
import { CancelShippedOrderItem, GetOrderDetails } from 'apps/sales/src/app/state/order.action';
import { Store } from '@ngxs/store';

@Component({
  selector: 'commerceq-admin-ui-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.less'],
})
export class ShippingComponent implements OnInit {
  @Input() orderDetails: any;
  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  showCancelModal: boolean = false;
  selectedItem: any;

  constructor(private store: Store) {}

  ngOnInit(): void {}

  showCancelItemmodal(item: any) {
    this.showCancelModal = true;
    this.selectedItem = item;
  }

  closeCancelItemModal() {
    this.showCancelModal = false;
  }

  cancelOrderItem() {
    this.store.dispatch([new CancelShippedOrderItem({id: this.selectedItem.id, status: 'CANCELLED'}), new GetOrderDetails(this.orderDetails.id)]);
    this.showCancelModal = false;
  }
}
