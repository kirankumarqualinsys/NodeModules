export class GetAbandonedCheckoutsList {
  static readonly type = '[AbandonedCheckouts] Get AbandonedCheckouts';
  constructor(public payload: any) { }
}

export class ChangeAbandonedCheckoutsPage {
  static readonly type = '[AbandonedCheckouts] Change AbandonedCheckouts Page';
  constructor(public readonly paylaod: number) { }
}

export class GetAbandonedCheckoutssWithFilters {
  static readonly type = '[AbandonedCheckouts] Get AbandonedCheckouts With Filters';
  constructor(public readonly paylaod: any, public readonly status: string) { }
}

export class GetAbandonedCheckoutDetails {
  static readonly type = '[AbandonedCheckouts] Get AbandonedCheckouts Details';
  constructor(public readonly orderId: any) { }
}
