import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { ChangeRefundsPage, GetRefundsList, GetRefundsWithFilters , UpdateRefundsDetails} from './refunds.action';
import { RefundsService } from '../../services/refunds.service';

export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}
export interface RefundsStateModel {
    refundsList: [];
    paginationRefunds: IPage;
    total: number;
    loading: boolean;
}
@State<RefundsStateModel>({
    name: 'refunds',
    defaults: {
        refundsList: [],
        paginationRefunds: { page: 1, size: 5 },
        total: 0,
        loading: false
    }
})
@Injectable()
export class RefundsState implements NgxsOnInit {


    constructor(private refundsService: RefundsService, private readonly store: Store) { }
    async ngxsOnInit() {
    }
    @Action(GetRefundsList)
    getRefundsList({ getState, patchState }: StateContext<RefundsStateModel>, action: GetRefundsList) {
        const { paginationRefunds } = getState();
        patchState({ loading: true })
        console.log(123);
        
        return this.refundsService.getRefunds(action.payload, paginationRefunds).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const refundsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        refundsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(ChangeRefundsPage)
    changeRefundsPage({ patchState, getState }: StateContext<RefundsStateModel>, action: ChangeRefundsPage) {
        patchState({ paginationRefunds: { ...getState().paginationRefunds, page: action.paylaod } })
    }
    
    @Action(GetRefundsWithFilters)
    getRefundsWithFilters({ getState, patchState }: StateContext<RefundsStateModel>, action: GetRefundsWithFilters) {
        const { paginationRefunds } = getState();
        patchState({ loading: true })
        return this.refundsService.getRefundsWithFilters(action.paylaod, paginationRefunds).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const refundsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        refundsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }

    // new one
    @Action(UpdateRefundsDetails)
    updateRefundsDetails({ getState, patchState }: StateContext<RefundsStateModel>, action: UpdateRefundsDetails) {
        const { paginationRefunds } = getState();
        patchState({ loading: true })
        console.log(123);
        
        return this.refundsService.putRefundDetails(action.payload, paginationRefunds).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const refundsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        refundsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
}