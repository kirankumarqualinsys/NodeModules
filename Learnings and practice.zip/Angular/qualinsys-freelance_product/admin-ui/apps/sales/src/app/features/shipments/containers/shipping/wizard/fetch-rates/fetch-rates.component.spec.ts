import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FetchRatesComponent } from './fetch-rates.component';

describe('FetchRatesComponent', () => {
  let component: FetchRatesComponent;
  let fixture: ComponentFixture<FetchRatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [FetchRatesComponent],
    }).compileComponents();

    fixture = TestBed.createComponent(FetchRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
