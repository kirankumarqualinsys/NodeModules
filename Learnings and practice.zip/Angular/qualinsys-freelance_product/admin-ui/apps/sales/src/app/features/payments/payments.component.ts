import { Component } from '@angular/core';
import { UntypedFormBuilder } from '@angular/forms';
import { ChangeDetectionStrategy, OnInit, TrackByFunction } from '@angular/core';
import { Select, Store } from '@ngxs/store';

import { Observable } from 'rxjs';
import { ChangePaymentsPage, GetPaymentsList, GetPaymentsWithFilters, } from '../state/payments.action';
import { PaymentsStateSelectors } from '../state/payments.selectors';


export interface Data {
  id: number;
  orderNumber: number;
  paymentNumber: number;
  displayAmount: number;
  paymentRefNumer: null;
  paymentDate: null;
}

@Component({
  selector: 'commerceq-admin-ui-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PaymentsComponent implements OnInit {
  constructor(private store: Store, private fb: UntypedFormBuilder) { }
  tabs = ["All", "Pending", "Completed", "Uncompleted", "Cancelled"];
  activetabIndex = 0;
  tabStatus: any = 'skip';
  paymentsFilterFields = {
    orderNumber: {
      type: "text",
      value: "",
      label: "Order Number",
      span: 6

    },
    paymentNumber: {
      type: "text",
      value: "",
      label: "Payment Number",
      span: 6
    },
    paymentRefNumber: {
      type: "text",
      value: "",
      label: "Payment Reference Number",
      span: 6
    },
    paymentDate: {
      type: "date",
      value: "",
      label: "Payment Date",
      span: 6
    }
  }
  paymentsList: any = [];
  isVisible = false;
  public paginationLimit = [10, 20, 50, 100]
  @Select(PaymentsStateSelectors.paymentsList)
  paymentsList$: Observable<any> | undefined;
  @Select((state: any) => state.payments.paginationPayments.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.payments.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.payments.paginationPayments.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.payments.loading)
  loading$: Observable<boolean> | undefined;
  async ngOnInit() {
    this.store.dispatch(new GetPaymentsList('skip'))
  }
  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = 'skip';
      this.store.dispatch([new ChangePaymentsPage(1), new GetPaymentsList('skip')]);
    } else {
      this.tabStatus = this.tabs[event];
      this.store.dispatch([new ChangePaymentsPage(1), new GetPaymentsList(this.tabStatus)]);
    }
  }
  onChange(result: Date): void {
    console.log('onChange: ', result);
  }


  trackByFn: TrackByFunction<any> = (index, item) => item.id;

  onChangePage(page: number): void {
    this.store.dispatch([new ChangePaymentsPage(page), new GetPaymentsList(this.tabStatus)])
  }


  showModal(): void {
    this.isVisible = true;
  }

  handleOk(): void {
    console.log('Button Ok clicked!');
    this.isVisible = false;
  }

  handleCancel(): void {
    console.log('Button cancel clicked!');
    this.isVisible = false;

  }
  filtersFormSubmit($event: any) {
    console.log($event, "event")
    this.store.dispatch(new GetPaymentsWithFilters($event))
  }

}