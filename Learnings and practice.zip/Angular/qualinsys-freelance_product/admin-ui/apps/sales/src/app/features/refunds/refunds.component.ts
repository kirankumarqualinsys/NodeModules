import { Component } from '@angular/core';
import {
  UntypedFormBuilder,
  UntypedFormGroup,
  Validators,
  FormBuilder
} from '@angular/forms';
import {
  ChangeDetectionStrategy,
  Input,
  OnInit,
  TrackByFunction,
} from '@angular/core';
import { Select, Store } from '@ngxs/store';

import { Observable, first } from 'rxjs';
import {
  ChangeRefundsPage,
  GetRefundsList,
  GetRefundsWithFilters,
  UpdateRefundsDetails,
} from '../state/refunds.action';
import { RefundsStateSelectors } from '../state/refunds.selectors';

export interface Data {
  id: number;
  orderNumber: number;
  refundNumber: number;
  refundDisplayAmount: number;
  refundRefNumer: null;
  refundInitiatedDate: null;
}
@Component({
  selector: 'commerceq-admin-ui-refunds',
  templateUrl: './refunds.component.html',
  styleUrls: ['./refunds.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RefundsComponent implements OnInit {
  constructor(private store: Store, private fb: UntypedFormBuilder) { }
  refundDetailsFormGroup!: UntypedFormGroup;
  tabs = ['All', 'Pending', 'Settled', 'Unsettled', 'Cancelled'];
  activetabIndex = 0;
  tabStatus: any = 'skip';
  paymentMode= [
    {
      label: "Select one",
      value: "",
    },
    {
      label: "Wallet",
      value: "WALLET ",
    },
    {
      label: "Payment gateways",
      value: "PAYMENT_GATEWAYS",
    },
    
  ];
  refundsFiltersField = {
    orderNumber: {
      type: 'text',
      value: '',
      label: 'Order Number',
      span: 6,
    },
    refundNumber: {
      type: 'text',
      value: '',
      label: 'Refund Number',
      span: 6,
    },
    refundRefNumber: {
      type: 'text',
      value: '',
      label: 'Refund Reference Number',
      span: 6,
    },
    refundInitiatedDate: {
      type: 'date',
      value: '',
      label: 'Refund Initiated Date',
      span: 6,
    },
  };

  // new one for refund details
  refundsDetailsField = {
    refundRefNumber: {
      type: 'text',
      value: '',
      label: 'Refund Reference Number',
      span: 24,
    },
    refundDate: {
      type: 'date',
      value: '',
      label: 'Refund Date',
      span: 24,
    },
    refundPaymentMode: {
      type: "select",
      value: "",
      label: "Refund Payment Mode",
      span: 24,
      options: [
        {
          label: "Select one",
          value: "",
        },
        {
          label: "Wallet",
          value: "WALLET",
        },
        {
          label: "Payment gateways",
          value: "PAYMENT_GATEWAYS",
        },
        
      ],
    },
  }
  showModal = false;
  refundsList: any = [];
  selectedRefund :any;
  public paginationLimit = [10, 20, 50, 100];
  @Select(RefundsStateSelectors.refundsList)
  refundsList$: Observable<any> | undefined;
  @Select((state: any) => state.refunds.paginationRefunds.size)
  pageSize$: Observable<any> | undefined;
  @Select((state: any) => state.refunds.total)
  total$: Observable<any> | undefined;
  @Select((state: any) => state.refunds.paginationRefunds.page)
  pageIndex$: Observable<any> | undefined;
  @Select((state: any) => state.refunds.loading)
  loading$: Observable<boolean> | undefined;

  trackByFn: TrackByFunction<any> = (index, item) => item.id;
  async ngOnInit() {
    this.store.dispatch(new GetRefundsList('skip'));
    this.refundDetailsFormGroup = this.fb.group({
      refundRefNumber: [null, [Validators.required]],
      refundDate: [null, [Validators.required]],
      refundPaymentMode: [null, [Validators.required]],
    })
   
  }

  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = 'skip';
      this.store.dispatch([
        new ChangeRefundsPage(1),
        new GetRefundsList('skip'),
      ]);
    } else {
      console.log(this.tabs[event]);
      this.tabStatus = this.tabs[event];
      this.store.dispatch([
        new ChangeRefundsPage(1),
        new GetRefundsList(this.tabStatus),
      ]);
    }
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }

  onChangePage(page: number): void {
    this.store.dispatch([
      new ChangeRefundsPage(page),
      new GetRefundsList(this.tabStatus),
    ]);
  }

  openModal(refund:any): void {
    this.selectedRefund = refund;
    this.showModal = true;
  }

  filtersFormSubmit($event: any) {
    this.store.dispatch(new GetRefundsWithFilters($event));
  }
  submitRefund() {
  }
  refundsDetailsFieldFormSubmit(event:any) {
  let  payload = {
    "refundId":  this.selectedRefund.id,
    "refundRefNumber": this.refundDetailsFormGroup.value.refundRefNumber,
    "refundDate": this.refundDetailsFormGroup.value.refundDate,
    "refundPaymentMode": this.refundDetailsFormGroup.value.refundPaymentMode,
    "notes": ""
    }
    if (this.refundDetailsFormGroup.valid) {
     this.store.dispatch([
      new UpdateRefundsDetails(payload),
      new GetRefundsList(this.tabStatus),      
    ]);
    this.Cancel();
    } else {
      Object.values(this.refundDetailsFormGroup.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }
  Cancel() {
    this.refundDetailsFormGroup.reset();
    this.showModal = false;

  }
}
