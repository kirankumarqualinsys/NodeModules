import { Selector } from '@ngxs/store';
import {
    RefundsStateModel,
    RefundsState,
} from './refunds.state';

export class RefundsStateSelectors {
  
    @Selector([RefundsState])
    static refundsList(state: RefundsStateModel) {
        return state.refundsList;
    }
    @Selector([RefundsState])
    static pageSize(state: RefundsStateModel) {
        return state.paginationRefunds.size;
    }
    @Selector([RefundsState])
    static total(state: RefundsStateModel) {
        return state.total;
    }
    @Selector([RefundsState])
    static pageIndex(state: RefundsStateModel) {
        return state.paginationRefunds.page;
    }
    @Selector([RefundsState])
    static loading(state: RefundsStateModel) {
        return state.loading;
    }
}