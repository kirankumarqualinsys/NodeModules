import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShipmentsComponent } from './shipments.component';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { ShipmentsListComponent } from './containers/shipments-list/shipments-list.component';
import { FiltersDynamicFormModule } from '../../../../../../libs/shared/src/lib/components/common/filters-dynamic-form/filters-dynamic-form.module';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NzDescriptionsModule } from 'ng-zorro-antd/descriptions';

@NgModule({
  declarations: [
    ShipmentsComponent, 
    ShipmentsListComponent,
    // ShippingDetailsComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      { path: '', component: ShipmentsComponent },
      {
        path: 'shipping/:id',
        loadChildren: () =>
          import('./containers/shipping/shipping.module').then(m => m.ShippingModule)
      },
      
    ]),
    NzDividerModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzDatePickerModule,
    NzButtonModule,
    NzInputModule,
    NzRadioModule,
    NzSelectModule,
    FiltersDynamicFormModule,
    NzDropDownModule,
    NzModalModule,
    NzAutocompleteModule,
    NzInputNumberModule,
    NzGridModule,
    NzCardModule,
    NzStepsModule,
    NzDescriptionsModule
  ],
  exports: [ShipmentsListComponent]
})
export class ShipmentsModule { }
