import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalesHomeComponent } from './sales-home.component';
import { RouterModule, Routes } from '@angular/router';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzSliderModule } from 'ng-zorro-antd/slider';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { NzDividerModule } from 'ng-zorro-antd/divider';

const routes: Routes = [
  {
    path: '',
    component: SalesHomeComponent,
    children: [
      {
        path: '',
        redirectTo: 'orders',
        pathMatch: 'full'
      },
      {
        path: 'orders',
        loadChildren: () =>
          import('../orders/orders.module').then(m => m.OrdersModule)
      },
      {
        path: 'payments',
        loadChildren: () =>
          import('../payments/payments.module').then(m => m.PaymentsModule)
      },
      {
        path: 'refunds',
        loadChildren: () =>
          import('../refunds/refunds.module').then(m => m.RefundsModule)
      },
      {
        path: 'shipments',
        loadChildren: () =>
          import('../shipments/shipments.module').then(m => m.ShipmentsModule)
      },
      {
        path: 'abandoned-checkouts',
        loadChildren: () =>
          import('../abandoned-checkouts/abandoned-checkouts.module').then(m => m.AbandonedCheckoutsModule)
      }
    ]
  }
];
@NgModule({
  declarations: [SalesHomeComponent],
  imports: [CommonModule,
    RouterModule.forChild(routes),
    NzLayoutModule,
    NzSliderModule,
    NzMenuModule,
    NzDividerModule
  ],
})
export class SalesHomeModule { }
