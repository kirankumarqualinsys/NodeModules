import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-sales-home',
  templateUrl: './sales-home.component.html',
  styleUrls: ['./sales-home.component.less'],
})
export class SalesHomeComponent implements OnInit {
  menuConfig: any;
  constructor() { }
  async ngOnInit() {
    this.setMenuItems();
  }
  async setMenuItems() {
    this.menuConfig = {
      items: [
        {
          key: 'orders',
          value: 'Orders'
        },
        {
          key: 'payments',
          value: 'Payments'
        },
        {
          key: 'refunds',
          value: 'Refunds'
        },
        {
          key: 'shipments',
          value: 'Shipments'
        },
        {
          key: 'abandoned-checkouts',
          value: 'Abandoned Checkouts'
        }
      ]
    }
  }
}