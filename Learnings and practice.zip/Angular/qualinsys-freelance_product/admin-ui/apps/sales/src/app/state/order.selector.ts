import { Selector } from '@ngxs/store';
import {
  OrderStateModel,
  OrderState,
} from './order.state';

export class OrderStateSelectors {
  @Selector([OrderState])
  static ordersList(state: OrderStateModel) {
    return state.ordersList;
  }
  @Selector([OrderState])
  static pageSize(state: OrderStateModel) {
    return state.paginationOrders.size;
  }
  @Selector([OrderState])
  static total(state: OrderStateModel) {
    return state.total;
  }
  @Selector([OrderState])
  static pageIndex(state: OrderStateModel) {
    return state.paginationOrders.page;
  }
  @Selector([OrderState])
  static loading(state: OrderStateModel) {
    return state.loading;
  }
  @Selector([OrderState])
  static orderDetails(state: OrderStateModel) {
    return state.orderDetails;
  }
}