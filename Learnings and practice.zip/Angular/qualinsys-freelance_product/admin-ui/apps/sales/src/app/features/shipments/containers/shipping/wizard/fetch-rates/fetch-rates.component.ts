import { Component, Input, OnInit } from '@angular/core';
import { NzButtonSize } from 'ng-zorro-antd/button/button.component';
import { UntypedFormBuilder, UntypedFormControl, UntypedFormGroup, Validators } from '@angular/forms';
//import { ActivatedRoute, Router } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'commerceq-admin-ui-fetch-rates',
  templateUrl: './fetch-rates.component.html',
  styleUrls: ['./fetch-rates.component.less'],
})
export class FetchRatesComponent implements OnInit {
  @Input() shipmentsList: any;
  Shipkarodata: Array<any>;
  Shiprocketdata: Array<any>;
  tabLabel ='createpickup';
  constructor(private fb: UntypedFormBuilder,  private router:Router, route: ActivatedRoute,) {
   // if (route.snapshot.params['/createpickup']) this.tabLabel = 'createpickup';
    
    this.Shipkarodata = [
      { services: 'Delivery COD', eta: '3days', rate: '$235' },
      { services: 'Delivery COD', eta: '5days', rate: '$239' }
  ];
  this.Shiprocketdata = [
    { services: 'DELIVERY (COD)', eta: '3days', rate: '$235' },
    { services: 'DTDC 2KG (COD)', eta: '5days', rate: '$239' },
    { services: 'AMAZON SHIPPING 2KG (COD)', eta: '2days', rate: '$639' },
    { services: 'EKART 2KG (COD)', eta: '6days', rate: '$439' },
    { services: 'EKART LOGISTICS SURFACE (COD)', eta: '3days', rate: '$339' },
    { services: 'DELIVERY SURFACE 5 KG (COD)', eta: '5days', rate: '$129' },
    { services: 'DELIVERY SURFACE (COD)', eta: '7days', rate: '$909' },
    { services: 'DELIVERY (COD)', eta: '2days', rate: '$239' }
 
];

  }
  ngOnInit(): void {
    
    this.router.navigate(['/createpickup']);
  }
  
  
}
