import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Select, Store } from '@ngxs/store';
import { GetShipmentsList } from 'apps/sales/src/app/state/shipment.action';
import { ShipmentStateSelectors } from 'apps/sales/src/app/state/shipment.selector';
//import { Observable } from 'rxjs';
import { merge, Observable, timer } from 'rxjs';
import { delay, finalize, map, scan } from 'rxjs/operators';
import { Router } from '@angular/router';
interface SyncStep {
  id: number;
  title: string;
  description: string;
  async: false;
  percentage: null;
}

interface AsyncStep {
  id: number;
  title: string;
  description: string;
  async: true;
  percentage: number;
}

type Step = SyncStep | AsyncStep;

function mockAsyncStep(): Observable<number> {
  const subStep1 = timer(600).pipe(map(() => 25));
  const subStep2 = subStep1.pipe(delay(600));
  const subStep3 = subStep2.pipe(delay(600));
  const subStep4 = subStep3.pipe(delay(600));
  return merge(subStep1, subStep2, subStep3, subStep4).pipe(scan((a, b) => a + b));
}

@Component({
  selector: 'commerceq-admin-ui-shipping',
  templateUrl: './shipping.component.html',
  styleUrls: ['./shipping.component.less'],
})
export class ShippingComponent implements OnInit {
  current = 0;
  selectedTab = 'shipnow';
  tabs = [
    { value: 'shipnow', displayValue: 'Ship Now' },
  // { value: 'fetch-rates', displayValue: 'Fetch Rates' },
  // { value: 'create-pickup', displayValue: 'Create Pickup' },
    // { value: 'items-cancellation-and-refunds', displayValue: 'Items Cancellation & Returns' }
  ];
  selectedTabIndex = 0;
 // selectedTab = 'shipnow';
  @Select(ShipmentStateSelectors.shipmentsList)
  shipmentsList$: Observable<any> | undefined
  constructor(private store: Store, private readonly route: ActivatedRoute, private router:Router) { }
  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if (id) {
      this.store.dispatch(new GetShipmentsList(id))
    }
  }
  selectTab(key: string, index: number) {
    this.selectedTab = key;
    this.selectedTabIndex = index;
  }
  
  pre(): void {
    this.current -= 1;
    this.changeContent();
    this.router.navigateByUrl('/fetchrates');
  }

  next(): void {
    this.current += 1;
    this.changeContent();
  }

  done(): void {
    console.log('done');
  }

  changeContent(): void {
    switch (this.current) {
      case 0: {
        this.selectedTab = 'First-content';
        break;
      }
      case 1: {
        this.selectedTab = 'Second-content';
        break;
      }
      case 2: {
        this.selectedTab = 'third-content';
        break;
      }
      default: {
        this.selectedTab = 'error';
      }
    }
  }

  
}

