import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-root',
  template: '<router-outlet></router-outlet>',
})
export class AppComponent {}
