import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext, Store } from '@ngxs/store';
import { take, tap } from 'rxjs';
import { PaymentsService } from '../../services/payments.service';
import { ChangePaymentsPage, GetPaymentsList,GetPaymentsDetails,GetPaymentsWithFilters } from './payments.action';


export interface IPage {
    size: number;
    page: number;
    filter?: string;
    filterParams?: { value: string[], key: string }[];
    sort?: { key: string, value: string }
}

export interface PaymentsStateModel {
    paymentsList: [];
    paginationPayments: IPage;
    total: number;
    loading: boolean;
    paymentsDetails:any;
}

@State<PaymentsStateModel>({
    name: 'payments',
    defaults: {
        paymentsList: [],
        paginationPayments: { page: 1, size: 5 },
        total: 0,
        loading: false,
        paymentsDetails: undefined,
    }
})

@Injectable()
export class PaymentsState implements NgxsOnInit {

    constructor(private paymentsService: PaymentsService, private readonly store: Store) { }
    
    async ngxsOnInit() {
    }
    @Action(GetPaymentsList)
    getPaymentsList({ getState, patchState }: StateContext<PaymentsStateModel>, action: GetPaymentsList) {
        const { paginationPayments } = getState();
        patchState({ loading: true })
        console.log(123);
        
        return this.paymentsService.getPayments(action.payload, paginationPayments).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const paymentsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        paymentsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }

    @Action(ChangePaymentsPage)
    ChangePaymentsPage({ patchState, getState }: StateContext<PaymentsStateModel>, action: ChangePaymentsPage) {
        patchState({ paginationPayments: { ...getState().paginationPayments, page: action.paylaod } })
    }

    @Action(GetPaymentsWithFilters)
    getPaymentsWithFilters({ getState, patchState }: StateContext<PaymentsStateModel>, action: GetPaymentsWithFilters) {
        const { paginationPayments } = getState();
        patchState({ loading: true })
        return this.paymentsService.getPaymentsWithFilters(action.paylaod, paginationPayments).pipe(
            take(1),
            tap((result: any) => {
                if (result && result.content) {
                    const paymentsList = result.content;
                    const total = result.totalElements;
                    patchState({
                        paymentsList,
                        total,
                        loading: false
                    });
                }
            })
        );
    }
    @Action(GetPaymentsDetails)
    getPaymentsDetails({ patchState }: StateContext<PaymentsStateModel>, action: GetPaymentsDetails) {
        patchState({ loading: true })
        return this.paymentsService.getPaymentsDetails(action.id).pipe(
            take(1),
            tap((result: any) => {
                if (result) {
                    const paymentsDetails = result;
                    patchState({
                        paymentsDetails,
                        loading: false
                    });
                }
            })
        );
    }

}