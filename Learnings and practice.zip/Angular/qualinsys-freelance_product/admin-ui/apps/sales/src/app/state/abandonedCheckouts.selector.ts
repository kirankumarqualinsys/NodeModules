import { Selector } from '@ngxs/store';
import {
  AbandonedCheckoutStateModel,
  AbandonedCheckoutState,
} from './abandonedCheckouts.state';

export class AbandonedCheckoutStateSelectors {
  @Selector([AbandonedCheckoutState])
  static abandonedCheckoutList(state: AbandonedCheckoutStateModel) {
    console.log(state ,'list');
    return state.abandonedCheckoutsList;
  }
  @Selector([AbandonedCheckoutState])
  static pageSize(state: AbandonedCheckoutStateModel) {
    return state.paginationAbandonedCheckouts.size;
  }
  @Selector([AbandonedCheckoutState])
  static total(state: AbandonedCheckoutStateModel) {
    return state.total;
  }
  @Selector([AbandonedCheckoutState])
  static pageIndex(state: AbandonedCheckoutStateModel) {
    return state.paginationAbandonedCheckouts.page;
  }
  @Selector([AbandonedCheckoutState])
  static loading(state: AbandonedCheckoutStateModel) {
    return state.loading;
  }
  @Selector([AbandonedCheckoutState])
  static orderDetails(state: AbandonedCheckoutStateModel) {
    return state.abandonedCheckoutDetails;
  }
}