import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../state/order.state';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }

  getOrders(status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/search`;
    const data = {
      doNotIncludeOrderStatuses: status === 'skip' ? ["PENDING"] : null,
      orderStatus: status !== 'skip' ? status.toUpperCase() : '',
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }

  getOrdersWithFilters(payload: any, status: string, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/search`;
    const data = {
      ...payload,
      doNotIncludeOrderStatuses: status === 'skip' ? ["PENDING"] : null,
      orderStatus: status !== 'skip' ? status.toUpperCase() : '',
      page: pagination.page - 1,
      size: pagination.size
    }
    return this.http.post(url, data)
  }

  getOrderDetails(orderId: string): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/${orderId}`;
    return this.http.get(url);
  }

  getCancelOrderReasonTypes(): Observable<any> {
    const url = `${this.environment.apiUrl}/masterdata/api/master-data/order-cancel-reason-types`;
    return this.http.get(url);
  }
  
  cancelOrder(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/${payload?.orderNumber}/actions/decline`;
    return this.http.put(url, payload);
  }

  cancelOrderItem(paylaod: any): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/orders/item/${paylaod.id}/actions/cancel`;
    return this.http.put(url, paylaod);
  }

  uploadOrderInvoice(payload: any, data: any): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/v1/97932177/invoices/${payload.invoiceNumber}/${payload.orderNumber}`;
    return this.http.post(url, data);
  }

  cancelShippingItem(payload: any): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/shipments/${payload.id}/status/${payload.status}`;
    return this.http.put(url, {});
  }
}
