import { Component, OnInit } from '@angular/core';
import { Store } from '@ngxs/store';

import {
  ChangeShipmentPage,
  GetShipmentsList,
  GetShipmentsWithFilters,
} from '../../state/shipment.action';
@Component({
  selector: 'commerceq-admin-ui-shipments',
  templateUrl: './shipments.component.html',
  styleUrls: ['./shipments.component.less'],
})
export class ShipmentsComponent implements OnInit {
  tabs = [
    'All',
    'Pending',
    'Processing',
    'Ready To Ship',
    'Shipped',
    'Delivered',
    'Cancelled',
  ];
  activetabIndex = 0;
  tabStatus = 'skip';
  shipmentFilterFields = {
    orderNumber: {
      type: 'text',
      value: '',
      label: 'Order Number',
      span: '6',
    },
    shipmentNumber: {
      type: 'text',
      value: '',
      label: 'Shipment Number',
      span: '6',
    },
    trackingNumber: {
      type: 'text',
      value: '',
      label: 'Tracking Number',
      span: '6',
    },
    shipmentDate: {
      type: 'date',
      value: '',
      label: 'Shipping Date',
      span: '6',
    },
  };
  constructor(private store: Store) { }
  async ngOnInit() {
    this.store.dispatch(new GetShipmentsList('skip'));
  }
  onSelectTab(event: number) {
    this.activetabIndex = event;
    if (this.activetabIndex === 0) {
      this.tabStatus = 'skip';
      this.store.dispatch([
        new ChangeShipmentPage(1),
        new GetShipmentsList('skip'),
      ]);
    } else {
      console.log(this.tabs[event]);
      this.tabStatus = this.tabs[event];
      this.store.dispatch([
        new ChangeShipmentPage(1),
        new GetShipmentsList(this.tabStatus.replaceAll(' ', '_')),
      ]);
    }
  }

  onChange(result: Date): void {
    console.log('onChange: ', result);
  }

  filtersFormSubmit($event: any) {
    console.log($event, 'event');
    this.store.dispatch(new GetShipmentsWithFilters($event));
  }
}
