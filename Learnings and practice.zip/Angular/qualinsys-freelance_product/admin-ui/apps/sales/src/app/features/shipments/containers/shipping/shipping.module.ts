import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShippingComponent } from './shipping.component'
import { NzDividerModule } from 'ng-zorro-antd/divider';
import { NzTabsModule } from 'ng-zorro-antd/tabs';
import { NzTableModule } from 'ng-zorro-antd/table';
import { NzPaginationModule } from 'ng-zorro-antd/pagination';
import { NzSwitchModule } from 'ng-zorro-antd/switch';
import { NzFormModule } from 'ng-zorro-antd/form';
import { NzDatePickerModule } from 'ng-zorro-antd/date-picker';
import { NzButtonModule } from 'ng-zorro-antd/button';
import { NzInputModule } from 'ng-zorro-antd/input';
import { NzRadioModule } from 'ng-zorro-antd/radio';
import { NzSelectModule } from 'ng-zorro-antd/select';
import { NzDropDownModule } from 'ng-zorro-antd/dropdown';
import { NzModalModule } from 'ng-zorro-antd/modal';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzCardModule } from 'ng-zorro-antd/card';
import { NzStepsModule } from 'ng-zorro-antd/steps';
import { NzAutocompleteModule } from 'ng-zorro-antd/auto-complete';
import { CreatePickupComponent } from './wizard/create-pickup/create-pickup.component';
import { ShipnowComponent } from './wizard/shipnow/shipnow.component';
import { FetchRatesComponent } from './wizard/fetch-rates/fetch-rates.component';
import { NzInputNumberModule } from 'ng-zorro-antd/input-number';
import { NzDescriptionsModule } from 'ng-zorro-antd/descriptions';


@NgModule({
  declarations: [
    ShippingComponent,
    CreatePickupComponent,
    ShipnowComponent,
    FetchRatesComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild([
      { path: '', component: ShippingComponent },
      { path: 'fetchrates', component: FetchRatesComponent },
      { path: 'createpickup', component: CreatePickupComponent }, 
      // { path: '',   redirectTo: '/createpickup', pathMatch: 'full' },
      
      
    ]),
    NzDividerModule,
    NzTabsModule,
    NzTableModule,
    NzPaginationModule,
    NzSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    NzFormModule,
    NzDatePickerModule,
    NzButtonModule,
    NzInputModule,
    NzRadioModule,
    NzSelectModule,
    NzDropDownModule,
    NzModalModule,
    NzAutocompleteModule,
    NzInputNumberModule,
    NzGridModule,
    NzCardModule,
    NzStepsModule,
    NzDescriptionsModule
  ],

})

export class ShippingModule { }
