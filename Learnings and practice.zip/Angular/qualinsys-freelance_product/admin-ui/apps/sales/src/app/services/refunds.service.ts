import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { EnvironmentService } from 'libs/shared/src/lib/services/environment.service';
import { Observable } from 'rxjs';
import { IPage } from '../features/state/refunds.state';

@Injectable({
  providedIn: 'root'
})
export class RefundsService {

  constructor(private readonly http: HttpClient,
    private readonly environment: EnvironmentService) { }
  getRefunds(status: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/refunds/search`;
    
    const data = {
      page: pagination.page - 1,
      size: pagination.size
    }
    if (status !== 'skip') {
      Object.assign(data, { 'refundStatus': status.toUpperCase() })
    }
    return this.http.post(url, data )
  }
  getRefundsWithFilters(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/refunds/search`;
    const data: any = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }

    return this.http.post(url, data)
  }
//   new
  putRefundDetails(payload: any, pagination: IPage): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/refunds/${payload.refundId}/refunded`;
    const data: any = {
      ...payload,
      page: pagination.page - 1,
      size: pagination.size
    }

    return this.http.put(url, data)
  }
  getRefundsDetails(id: number): Observable<any> {
    const url = `${this.environment.apiUrl}/order/api/97932177/refunds/search${id}`;
    return this.http.get(url)
  }
  
}
