module.exports = {
  name: 'host',
  remotes: ['dashboard', 'crm', 'catalog', 'sales', 'settings'],
};
