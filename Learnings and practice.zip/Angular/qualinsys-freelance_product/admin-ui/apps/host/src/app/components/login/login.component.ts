import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Store } from "@ngxs/store";
import { UserLogin } from '../../state/core.action';
import { CoreService } from 'libs/shared/src/lib/services/core.service';


@Component({
  selector: 'commerceq-admin-ui-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {
  validateForm!: UntypedFormGroup;

  submitForm(): void {
    if (this.validateForm.valid) {
      const body = {
        "username":this.validateForm.controls['userName'].value,
        "password":this.validateForm.controls['password'].value,
        "tenantId":this.validateForm.controls['tenantId'].value
      }
     
      this.store.dispatch(new UserLogin(body))
      this.coreService.login_storeid(body).subscribe((res: any) => {
        console.log('kklklkl;k', res);
        sessionStorage.setItem('storeID', res);
       })


    } else {
      Object.values(this.validateForm.controls).forEach(control => {
        if (control.invalid) {
          control.markAsDirty();
          control.updateValueAndValidity({ onlySelf: true });
        }
      });
    }
  }

  constructor(private fb: UntypedFormBuilder,private store: Store , private coreService: CoreService) {}

  ngOnInit(): void {
    this.validateForm = this.fb.group({
      userName: [null, [Validators.required]],
      password: [null, [Validators.required]],
      tenantId:[null,[Validators.required]],
      remember: [true]
    });
  }
}
