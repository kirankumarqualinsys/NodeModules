import { Injectable } from '@angular/core';
import { Action, NgxsOnInit, State, StateContext } from '@ngxs/store';
import { CoreService } from '../../../../../libs/shared/src/lib/services/core.service';
import { tap } from 'rxjs';
import { UserLogin } from './core.action';
import { Router } from '@angular/router';

export class CoreStateModel {
  userDetails: any;
}

@State<CoreStateModel>({
  name: 'core',
  defaults: {
    userDetails: undefined
  },
})
@Injectable()
export class CoreState implements NgxsOnInit {
  constructor(
    private readonly coreService: CoreService,
    private readonly router: Router
  ) { }

  async ngxsOnInit() { }

  @Action(UserLogin)
  userLogin({ patchState }: StateContext<CoreStateModel>, action: UserLogin) {
    return this.coreService.login(action.data).pipe(
      tap((res: any) => {
        const userDetails = JSON.parse(res.data.token);
        sessionStorage.setItem('accessToken', userDetails.access_token);
        sessionStorage.setItem('orgId', userDetails.orgId)
        patchState({
          userDetails
        });
        if (res?.status === "success") {
          this.router.navigate(['dashboard', 'home'])
        }

      })
    )
  }
  
}
