import { LayoutComponent } from './common/layout/layout.component';
import { LoginComponent } from './components/login/login.component';
import { Route } from '@angular/router';


export const appRoutes: Route[] = [
  {
    path: 'login',
    component: LoginComponent,
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('dashboard/Module').then((m) => m.AppModule),
      },
      {
        path: 'crm',
        loadChildren: () =>
          import('crm/Module').then((m) => m.AppModule),
      },
      {
        path: 'catalog',
        loadChildren: () =>
          import('catalog/Module').then((m) => m.AppModule),
      },
      {
        path: 'sales',
        loadChildren: () =>
          import('sales/Module').then((m) => m.AppModule),
      },

      {
        path:'settings',
        loadChildren: () =>
          import('settings/Module').then((m) => m.AppModule),
      }
    ],
  },
];
