// import { LoginUser } from "../models/user.model";


export class UserLogin {
  static readonly type = 'User Login';
  constructor(public readonly data:any){}
}