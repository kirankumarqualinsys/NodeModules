import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NzGridModule } from 'ng-zorro-antd/grid';
import { NzLayoutModule } from 'ng-zorro-antd/layout';
import { NzMenuModule } from 'ng-zorro-antd/menu';
import { RouterModule } from '@angular/router';

import { LayoutComponent } from './layout/layout.component';
import { LayoutNavbarComponent } from './layout-navbar/layout-navbar.component';

@NgModule({
  declarations: [LayoutNavbarComponent, LayoutComponent],
  imports: [CommonModule, RouterModule, NzGridModule, NzMenuModule, NzLayoutModule],
  exports: [LayoutNavbarComponent, LayoutComponent],
  providers: [],
})
export class CommonDashboardModule { }
