import { Component } from '@angular/core';

@Component({
  selector: 'commerceq-admin-ui-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.less'],
})
export class LayoutComponent {}
