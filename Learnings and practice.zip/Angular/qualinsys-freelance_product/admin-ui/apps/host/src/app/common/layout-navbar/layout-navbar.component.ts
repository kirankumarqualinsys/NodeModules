import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'commerceq-admin-ui-layout-navbar',
  templateUrl: './layout-navbar.component.html',
  styleUrls: ['./layout-navbar.component.less']
})
export class LayoutNavbarComponent {
  constructor(private router:Router){}
  signOut(){
    sessionStorage.clear();
    this.router.navigateByUrl('/login');
  }
}
