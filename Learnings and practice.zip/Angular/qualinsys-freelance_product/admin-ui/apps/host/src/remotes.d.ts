declare module 'dashboard/Module';
declare module 'crm/Module';
declare module 'catalog/Module';
declare module 'sales/Module';
declare module 'settings/Module';
